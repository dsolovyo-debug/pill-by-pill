# Pill by Pill v5.26: architecture

A static site (deployed by dropping the zip on Netlify) plus an optional FastAPI server that reads the same files.

## Layout

```
site/                    what gets deployed (the Netlify zip is this folder)
  index.html             shell, 800 bytes; loads css/ and js/app.js
  js/app.js              hash router, start page, funding page
  js/layout.js           page hierarchy (page()), the two environment shells, the six roles
  js/explore.js          Simple environment pages
  js/reference.js        In-depth environment pages
  js/molecule.js         2D skeletal drawing (SVG), 3D model (canvas), sequence view
  js/binding.js          binding-site animation (canvas) and mechanism schematics (SVG + CSS keyframes)
  js/simulators.js       three explorers above data sets (gene variants, interactions, release profiles); text in data/simulators.json
  js/data.js             fetch + cache of JSON, drug index, search
  js/drugfacts.js        wording helpers (no facts live here)
  js/money.js            monetization cards, driven by config/monetization.json
  js/search.js, ui.js    type-ahead; escaping html`` template, links, storage
  css/base.css           shared components;  explore.css and reference.css are scoped by body[data-env]
  config/monetization.json   one on/off switch and one link per scheme
  data/drug_index.json   every medicine, compact (search and browse)
  data/drug_aliases.json other names -> medicine
  data/drugs/<id>.json   one file per medicine, loaded when its page opens
  data/topics.json, data/topics/<key>.json   33 curated data sets and how to show them
  data/how_made.json, data/quiz.json, data/catalogue_stats.json
  mol/<id>.json          2D layout and 3D model for one structure, loaded when drawn
  bind/<id>.json         drug, pocket residues and contacts cut from an experimental structure, loaded by the animation
  legacy/index.html      v4.0.3 interactive labs, kept until they are ported (see Debt)
pipeline/                rebuilds everything under site/data and site/mol from public sources (sh pipeline/run_all.sh)
tests/                   test_data.py (sources, consistency), test_site.py (headless Chromium), test_app.py (server parity)
app.py                   FastAPI: serves site/ and /api/* from the same JSON files
```

## Routes and page hierarchy

`home -> path landing -> topic or medicine page -> deep-dive`. Every page is rendered by `page()` in layout.js with the same parts:
breadcrumb, title, key facts above the fold, short body, deep-dive links.

| Level | Simple (`#/explore`) | In-depth (`#/ref`) |
| --- | --- | --- |
| home | `#/` (choose a path) | `#/` |
| landing | `#/explore` student, `/teach`, `/history` | `#/ref/clinician`, `/chemist`, `/industry` |
| page | `/medicines`, `/medicine/<id>`, `/topic/<key>`, `/stories`, `/made`, `/quiz` | `/drugs`, `/drug/<id>`, `/topics`, `/topic/<key>`, `/data` |
| deep-dive | `/medicine/<id>/molecule`, `/works`, `/made`, `/topic/<key>/all` | `/drug/<id>/structure`, `/binding`, `/approvals`, `/uses`, `/names`, `/topic/<key>/<row>` |

The two environments share data and molecule code only. Shell, navigation, CSS, vocabulary and page modules are separate.

## Data flow

1. `fetch_sources.py`: ChEMBL approved drugs, mechanisms, indications, warnings, ATC; the full Drugs@FDA file.
   `fetch_ema.py`: EMA's nightly table of centrally evaluated human medicines (status, dates, holder, flags, page link).
2. `build_catalogue.py`: one medicine per ChEMBL parent molecule, Drugs@FDA applications and EMA products filed under their ingredients
   (substances found only in EMA's table become their own entries), curated v4 notes attached.
3. `crosscheck_pubchem.py`: PubChem CID by InChIKey; structures for FDA-only names.
3b. `fetch_manufacturing.py`: which processes PubChem's manufacturing notes mention, per compound (keywords only; the notes are linked, not copied).
    `fetch_structure_index.py` + `fetch_binding.py`: binding sites (see below). `build_catalogue.py` is then run again to merge both.
    `fetch_oligo_sequences.py`: oligonucleotide strands and modification codes from FDA's substance registry (GSRS). Sequences are
    never typed by hand: a hand-typed list reviewed in v5.4 had 4 of 22 sequences wrong.
4. `render_molecules.py`: RDKit 2D layout and computed 3D model per structure.
5. `build_topics.py`: curated v4 data sets -> topic files; rows without a source link are dropped.

Rule: every block written by the pipeline carries the URL of its source record, and the tests fail if one is missing.

## Binding sites

For a drug with a structure and a ChEMBL mechanism target: its PDB ligand code is found by InChIKey, PDBe search returns entries that
contain both that ligand and the target protein (UniProt accession), the best-resolution entry is downloaded from files.rcsb.org, and
gemmi cuts out the drug and the residues within 4 A. Contacts are distance rules (polar 3.5 A, non-polar 4.0 A, metal 2.8 A), stated as
such on the page. `binding.js` animates the drug moving along the pocket's open direction into its deposited position, then reveals the
contacts one at a time; only the end state is data. Drugs without such an entry get `schematic()`: a symbolic picture chosen by ChEMBL
action type (block, activate, bind, silence, cut, replace), labelled as a schematic.

When a small molecule has no structure in its own target, `fetch_binding_related.py` accepts one in the same gene of another organism or
strain (never another family member); the summary then has `kind: "related"` and a `related` block, and both environments label it.
Peptide medicines too short or too modified for the 30-residue rule go through `fetch_binding_peptides.py`: a chain counts only if it is
identical to an unmodified peptide, or is named after the medicine and differs only at modified residues.
Antibody and protein medicines (`fetch_binding_biologics.py`) use the same output shape: the "ligand" is the medicine's interface
residues (with `owner` and `labels`), found in an entry that holds the target and a chain tied to the medicine by a 30-residue sequence
match against ChEMBL (or, for antibodies without a ChEMBL sequence, by PDBe's chain name). `binding.js` can save one loop as a video
with the browser's MediaRecorder; nothing is uploaded.

## Explorers

`data/simulators.json` is curated: each gene-variant and interaction statement paraphrases one FDA label (read through openFDA) and
carries its DailyMed link; a figure appears only if that label states it. These two explorers render in the In-depth environment only.
The release-profile curve is a one-compartment illustration with made-up constants and is labelled as such.

## Monetization

`config/monetization.json` lists schemes with `on`, `roles` and a link. `money.js` shows a scheme only when it is on and has a link
(or preview mode is on), never for the student role, and labels affiliate links "Paid link" with `rel="sponsored"`.
Landing pages and the funding page call `moneyFor(role)`; drug and data pages do not.
`legal_hold` on a scheme keeps it off even in preview; `paid_links_hold` keeps book links unpaid. Both are listed on the funding page.

## Debt

- `legacy/index.html` is the 770 KB v4 page. Its simulators (MoA engine, PGx, dosing, formulation) are not ported; topic pages link to it.
- Simple-page wording for mechanisms is template-based (`drugfacts.js`), so some sentences read stiffly.
- Approval data covers the US, the EU's centralised procedure, Canada and Japan (since April 2004); national licences in individual EU countries and other countries' registers are not covered.

## Book lists
`config/monetization.json` → `schemes.bookshop.items`: each book lists the `roles` it is shown to and a `record` link where its title,
author, publisher and year can be checked; `js/money.js` hides a book without one. Lists differ by role and are never shown to students.

## Peptide sequences
ChEMBL's letter strings for peptides are not reliable on their own (some are stored C-to-N, some drop modified residues). Order of trust:
FDA GSRS (`fetch_peptide_sequences.py`, with modification sites) > ChEMBL HELM notation > ChEMBL biocomponent string.
`sequence.registry_unmodified` is true only when GSRS lists no modification; the peptide matcher needs that (or a plain HELM) before it will
tie a chain to a medicine by letters alone. Medicines that share letters (semaglutide/liraglutide, insulin detemir/degludec) are told apart by the modification sites.

## Paid book links
`schemes.bookshop.affiliate_id` + a book's `isbn` give `https://bookshop.org/a/<id>/<isbn>`, labelled "Paid link", `rel="sponsored"`, never on student pages.
Add `"paid_links_hold": "reason"` to switch all book links back to unpaid search links.

## PDBe search: case matters
PDBe's Solr `title` and `molecule_name` fields are case-sensitive strings, so a wildcard on `semaglutide` does not find
"Crystal structure of Semaglutide ...". `fetch_binding_biologics.name_clause()` searches lower-case, capitalised and upper-case
forms; both protein matchers use it. (Until v5.12 every entry that capitalised the medicine's name was missed.)

## Accessibility and phone width
`tests/test_site.py` runs axe-core (vendored in `tests/vendor`, MPL-2.0) on 25 page types at 1280 px and 390 px in light mode and at
1280 px in dark mode, and checks at 390 px that no page scrolls sideways, nothing is cut off at the edge, and non-inline links and
buttons are at least 24 px tall. White panels (molecule drawings, schematics) keep light-mode text colours in dark mode.
This is an emulated phone width in Chromium, not a check on a real phone.

## Canada and Japan
`fetch_canada.py` downloads five tables from Health Canada's Drug Product Database API (Open Government Licence – Canada; the
attribution sentence is shown under every Canadian table). Only the bracketed substance in names like "MAGNESIUM (MAGNESIUM OXIDE)"
is matched, and salt-stripping never stops at a bare metal ("ZINC GLUCONATE" does not become "ZINC").
`read_pmda_list.py` reads PMDA's "List of Approved Drugs" PDF, saved by hand because PMDA's site policy does not permit automated
downloads. PMDA content is under the Public Data License 1.0; pages cite it as "Created by editing ...". Only facts are kept
(dates, products, applicants, new-active-ingredient and orphan flags). New active ingredients that no other source lists become
PMDA-only entries, unless the name is one letter away from a listed name, combines listed medicines, or shares a brand with one
(those are counted in `catalogue_stats.json` and set aside). Canadian and Japanese records are attached, never used to create
Canadian entries; Japan's new-active-ingredient date counts towards "first approved".
`fetch_extra_chembl.py` looks the EMA-only and PMDA-only entries up in ChEMBL by exact name (preferred name, then synonym; one
parent molecule or nothing). Two outcomes: if that ChEMBL molecule is already in the catalogue (EMA or PMDA used a name ChEMBL
lists as a synonym), the EU or Japanese record is filed under that medicine and the pair is listed in
`catalogue_stats.filed_by_chembl_identity` for review; otherwise the entry keeps `chembl_id` empty and carries `chembl_ref`, with
the structure, type and mechanisms from ChEMBL, and every page says ChEMBL records an earlier phase, not the approval. Answers
are cached in raw/extra_chembl_cache.json (a failed request is never cached as "no match"), four requests at a time. It also
tops up raw/pubchem.json for those structures. Order: build_catalogue -> fetch_extra_chembl -> build_catalogue -> fetch_binding
(new structures only) -> build_catalogue.

EMA's substance column often gives the active moiety where Drugs@FDA gives the substance ("isavuconazole" for Cresemba,
"isavuconazonium sulfate" in the US). When EMA's product name is a US brand of exactly one medicine whose name starts with the
same six letters, every EMA product with that substance name is filed under that medicine (decided over all products before the
main pass); the pairs are listed in `catalogue_stats.filed_by_shared_brand` and on the Data sources page. A medicine only EMA or
PMDA lists, whose name is the start of another entry's name ("Mometasone" and "Mometasone Furoate"), gets `see_also` links both
ways; nothing is claimed about how the two are related.

## Name handling and its tests
Salt words, metal names, WHO stems, conjugate payload words and Japanese name cleaning live in `pipeline/names.py` (pure
functions, no files). `tests/test_pipeline.py` checks them and the PMDA PDF parser offline, using strings that once went wrong:
"ZINC GLUCONATE", "brentuximab vedotin", "anamorelin", "SILODOSHIN", doubled bold letters, glyph-id parentheses, numbered brands.

## Dates across regions
`drugfacts.worldTimeline()` lists the first US, EU, Japan and Canada dates for one medicine and says what each date is (they measure
different things; Canada's is first sale). `catalogue_stats.region_timing` compares the US with each other region, counting only
medicines new to both since 2005. Search aliases include EU product names and Japanese and Canadian brands of single-ingredient
products (a combination's brand is never given to one of its ingredients).

## Origin stories (v5.18)
`pipeline/origin_stories.json` holds short "where it comes from" notes for single medicines (9 so far: lovastatin, cyclosporine,
ivermectin, sirolimus, vancomycin, oseltamivir, captopril, exenatide, ziconotide). Each has a category, a Simple text, an In-depth
text and the https sources every statement was taken from; `build_catalogue.py` attaches it as `origin` and stops if the medicine
is not in the catalogue or a source link is missing. Shown on `#/explore/medicine/<id>/made` and `#/ref/drug/<id>/structure`.
The texts were drafted by Gemini (v5.18 spec, 04 Docs) and checked against their sources by Claude on 2026-11-19; statements no
source supported (Borneo, Norway, "defend its territory", amino-acid counts not in the cited text) were removed. The sources
describe the organism, the discovery or the chemistry, not a manufacturer's current process, and the pages say so.

## EMA-only types from ATC codes (v5.18)
`names.classify_ema_type` reads, in order: J07 and the word "vaccine"; J06B and "immunoglobulin"; the whole ATC groups V09/V10
(new type Radiopharmaceutical, code `rp`) and V01 (new type Allergen extract, code `al`); conjugate payload words; WHO INN stems in
names of at most three words; and last a list of single ATC codes whose substance is a protein or enzyme (B02BD, B05AA, A16AB,
code by code). Those three groups are mixed (B02BD15-18 and A16AB21/26/29 are gene or cell therapies, B05AA03-07 are
fluorocarbons, dextran, gelatin and starch), so whole-group rules would mistype them; a code not on the list stays Unknown.
L01XL (antineoplastic cell and gene therapies) is not used: it does not say which of the two a product is.
On the 2026-11-19 EMA table these rules typed 5 of the 43 EU-only entries that were still Unknown and re-typed 3 radiolabelled
products (edotreotide and etarfolatide from Protein, iodine (131I) omburtamab from Antibody) as radiopharmaceuticals.
The new types need entries in `site/js/data.js` TYPE_NAMES and `site/data/how_made.json` (both added).

## v5.24: WHO Essential Medicines List, families, comparison, covalent binding (from Gemini's v5.19-v5.24 patches)
Gemini's six patch files were reviewed and folded in by hand rather than run, because several assumed data fields this
catalogue does not have (a top-level how_made key, `d.ema`, `first_year` inside regional records, EMLc and core/complementary
flags that WHO's export does not give).
- `fetch_who_eml.py` reads WHO's eEML page (https://list.essentialmeds.org/): one block per listed medicine with its eEML page,
  sections, combination parts and "(as ...)" salt forms. build_catalogue.py matches the names the same way as EMA's; class entries
  ("Insulin (analogue, ...)"), vaccines, immunoglobulins and blood products are never matched to one medicine, and unmatched names
  are listed in `catalogue_stats.eml_unmatched`. Medicines get `who_eml` and flag bit 1024 (`eml`). Licence CC BY 3.0 IGO; the
  attribution and WHO's note that the 2025 PDF lists are binding are shown wherever the record is. raw/who_eml.csv is the same data
  for people to read.
- Origin stories: 24 of Gemini's 26 new stories kept after checking every statement against the full text (Europe PMC REST
  fullTextXML, read from the shell) or, where only that was available, the abstract (labelled "(abstract)"). Removed: claims not
  in the sources (e.g. "Madagascar periwinkle", "14-membered", "over 150 analogues", Novolin 1991, cisplatin's history) and
  sources that did not exist in Europe PMC (PMC13308793, PMC3877807) or did not support the text. Held back with reasons in
  `origin_stories.json["held_back"]`: CISPLATIN, ARTEMISININ.
- Quiz: 50 questions (8 added, checked the same way); answer order is shuffled on screen (36 of 42 old questions had the right
  answer first).
- `build_family_trees.py`: families share the USAN stem ChEMBL records and the same first mechanism target; members in order of
  the catalogue's first approval year; the earliest is "earliest in these records", not "first in class". Pages: #/ref/families
  (search, ?f=<id>) and #/ref/compare/<a>/<b> (picker at #/ref/compare), both linked from each drug's overview.
- `fetch_binding_covalent.py`: for small molecules with no binding site, finds the PDB ligand code of the reacted form (name or
  research-code search on PDBe, then a common-substructure check: at least 75% of the medicine's heavy atoms, ligand 60-140% of
  its size, bond orders ignored), takes the best-resolution entry of the target with that code, requires a covale link to an
  amino acid of a target chain of 60+ residues and that most contacted residues are on that chain (8UDR, a KRAS peptide in an
  MHC complex, was rejected by this rule), and marks the bond as a "covalent" contact. Single-protein targets only.
- The FDA Drug Shortages link (In-depth "Uses and safety", US medicines) points to FDA's own search; nothing is copied.

## v5.25: ready to promote (real page addresses, link previews, sharing); paid book links on hold
- Paid book links are on hold (`paid_links_hold` in config/monetization.json, Dmitry 2026-11-20, while the WHO ATC licence
  question is open). The book shelves still show on non-student pages, with ordinary Bookshop.org links; the shelf and the
  funding page say the site earns nothing from them. Removing the hold brings back ISBN affiliate links, "Paid link" labels
  and rel="sponsored" (still tested with the hold lifted in a test override).
- `build_static_pages.py` writes one real page per medicine at /medicine/<id>/ (plus /medicines/ A to Z, the start page and
  404.html) from the drug files: title, description, canonical link, Open Graph and Twitter tags, schema.org JSON-LD
  (MedicalWebPage about a Drug, with breadcrumbs) and the main facts with their source links in plain HTML. Each page has
  `<base href="/">` and loads js/app.js, which opens the same view as #/explore/medicine/<id> (app.js `pathRoute`). Hash
  links on those pages go to the site root, which is intended; in-page anchors (the skip link) are not treated as routes.
  It also writes sitemap.xml, robots.txt, feed.xml (Atom, the 40 most recent first approvals in the US, EU or Japan
  records; Canada's first-sale dates are left out), manifest.webmanifest and Netlify `_headers` (security headers; cache
  times for data, molecules, binding sites, images and fonts).
- The public address is config/site.json `base_url` (https://pillbypill.netlify.app until a custom domain is chosen).
  Search Console and Bing verification tokens go in the same file; the build adds the meta tags.
- `make_brand_images.py` draws img/og-card.png (1200x630, the picture link previews show), icons and favicon.svg from the
  site's own fonts and three real structures from the catalogue.
- js/share.js: a share-and-cite panel on each medicine page. Simple pages: copy link, the device's share sheet and a
  citation. In-depth pages add plain links to email, X, Facebook, LinkedIn, Reddit and WhatsApp; no network scripts are
  loaded and nothing is sent until the reader clicks. New pages: #/privacy (no cookies, analytics or ads; what local
  storage keeps) and #/share (one-line description, link code, share picture, feed).

## v5.26: 60 origin stories, one start-page grid, retry on a dropped connection, no dead end on "How it's made"
- `pipeline/origin_stories.json`: 27 stories drafted by Gemini (batches 5 and 6) were checked against their sources before going in (full text
  from NCBI eutils `efetch` or Europe PMC, the abstract where the publisher withholds the text, NobelPrize.org); most were corrected and five
  cited papers were about something else, so they were dropped. A story may carry its own `checked` date, which `build_catalogue.py` keeps.
  Nothing is held back any more (cisplatin has a readable source; artemisinin's story is on artesunate's page).
- Start page (`js/app.js` `start()`): the six roles in one `.lens-grid` under "How are you exploring today?" (Dmitry's Option 2); the switcher
  reads "Reference →" / "← Explore". Cards use `--paper`, so they follow dark mode.
- `data.getJSON` tries once more after 400 ms when `fetch` itself fails, and marks the error `network`; the router then shows
  "Connection interrupted" with a Try again button. A missing file or bad JSON still shows "We couldn't find that page".
- Simple "How it's made" page of a medicine without a discovery story: "What the records say" (oldest date by region and what it is, first US
  generic, family from `family_trees.json`, WHO list), built in `explore.js` from fields the page already has. Gemini's
  `build_drug_histories.py` / `fetch_drug_histories.py` were not taken: they copied the same dates into every drug file with new wording
  (some of it wrong, e.g. generic counts "across N sponsors" used all sponsors) and added Europe PMC papers matched only by title words as sources.
- `pipeline/run_all.sh`: the PubChem cross-check now runs before `fetch_extra_chembl.py` and is skipped only when `raw/pubchem.json` has the
  `crosscheck` marker. Before, the top-up written by `fetch_extra_chembl.py` made a fresh build skip the cross-check entirely, and every page
  said "Not found in PubChem by InChIKey".
- `config/site.json`: Google Search Console verification token.
