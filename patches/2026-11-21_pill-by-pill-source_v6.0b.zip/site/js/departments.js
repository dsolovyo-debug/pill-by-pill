// Pharmaceutical Encyclopedia: Departments & Routes of Administration (v6.0b)
// Supports both Explore (#/explore/how-drugs-are-built, #/explore/departments/<id>)
// and Reference (#/ref/departments, #/ref/departments/<id>, #/ref/routes).
import { html } from "./ui.js";
import * as data from "./data.js";
import { page } from "./layout.js";

const EXP_HOME = ["Home", "#/explore"];
const REF_HOME = ["Overview", "#/ref"];

export const departmentsData = () => data.getJSON("data/departments.json");

function sourceLinks(sources = [], checked) {
  if (!sources.length) return "";
  return html`<p class="muted small">Sources: ${sources.map((s, i) =>
    html`${i ? " · " : ""}<a href="${s.url}" target="_blank" rel="noopener">${s.label}</a>`)}${checked ? ` (checked ${checked})` : ""}.</p>`;
}

export async function departmentsExplorePage(deptId = null) {
  const doc = await departmentsData();
  if (!deptId) {
    const cards = doc.departments.map((d) => html`
      <section class="x-panel">
        <h2>${d.icon} <a href="#/explore/departments/${d.id}">${d.name}</a></h2>
        <p class="who">${d.stage_range}</p>
        <p>${d.plain_summary}</p>
        <p><a href="#/explore/departments/${d.id}">Explore this department →</a></p>
      </section>`);
    return {
      html: page({
        trail: [EXP_HOME, ["How drugs are built"]],
        title: "Inside a Pharmaceutical Company",
        lede: "How a molecule travels from an early lab idea to a safe, tested medicine on a pharmacy shelf—department by department.",
        body: html`${cards}`,
        more: [{ title: "Technical Reference View", text: "CQAs, ICH guidelines, and routes of administration.", href: "#/ref/departments" }],
      }),
    };
  }

  const dept = doc.departments.find((d) => d.id === deptId);
  if (!dept) throw new Error(`Department not found: ${deptId}`);
  const body = html`
    <section class="x-panel"><h2>What this team does</h2><p>${dept.plain_summary}</p></section>
    <section class="x-panel"><h2>Step by step</h2>
      <ul class="plain">${dept.workflows.map((w) => html`<li><b>${w.step}:</b> ${w.plain}</li>`)}</ul>
      ${sourceLinks(dept.regulatory_anchors, doc.checked)}
    </section>
    ${dept.id === "formulation" ? html`<section class="x-panel"><h2>How medicines enter the body</h2>
      <ul class="plain">${doc.routes.map((r) => html`<li><b>${r.name}:</b> ${r.plain_summary}</li>`)}</ul></section>` : ""}`;
  return {
    html: page({
      level: "deep",
      trail: [EXP_HOME, ["How drugs are built", "#/explore/how-drugs-are-built"], [dept.name]],
      kicker: dept.stage_range,
      title: `${dept.icon} ${dept.name}`,
      body,
      more: [{ title: "Technical Reference View", text: "CQAs, ICH standards, and equipment specs.", href: `#/ref/departments/${dept.id}` }],
    }),
  };
}

export async function departmentsRefPage(deptId = null) {
  const doc = await departmentsData();
  if (!deptId) {
    const rows = doc.departments.map((d) => html`<tr>
      <td><a href="#/ref/departments/${d.id}"><b>${d.icon} ${d.name}</b></a></td>
      <td>${d.stage_range}</td>
      <td>${d.workflows.length} core workflows</td>
      <td>${d.equipment_ids.length} linked hardware classes</td>
    </tr>`);
    const body = html`
      <div class="tbl-wrap" tabindex="0" role="region" aria-label="Pharmaceutical departments">
        <table class="tbl"><thead><tr><th>Department</th><th>Lifecycle Stage</th><th>Workflows</th><th>Equipment</th></tr></thead>
        <tbody>${rows}</tbody></table>
      </div>
      <p><a class="btn" href="#/ref/routes">Explore Routes of Administration</a> <a class="btn" href="#/ref/equipment">Equipment Market &amp; Specs</a></p>
      <p class="muted small">Updated ${doc.checked}. Connects regulatory filings to R&amp;D, CMC formulation, analytical QC, and commercial manufacturing.</p>`;
    return {
      html: page({
        trail: [REF_HOME, ["Departments"]],
        title: "Pharmaceutical Encyclopedia — Departments",
        lede: "End-to-end CMC, analytical, discovery, and manufacturing workflows linked to ICH/FDA guidance and hardware specifications.",
        body,
      }),
    };
  }

  const dept = doc.departments.find((d) => d.id === deptId);
  if (!dept) throw new Error(`Department not found: ${deptId}`);
  const body = html`
    <p>${dept.technical_summary}</p>
    <h2>Core Technical Workflows</h2>
    <div class="tbl-wrap" tabindex="0" role="region" aria-label="Department workflows">
      <table class="tbl"><thead><tr><th>Stage / Workflow</th><th>Technical Scope &amp; Standards</th></tr></thead>
      <tbody>${dept.workflows.map((w) => html`<tr><th scope="row">${w.step}</th><td>${w.expert}</td></tr>`)}</tbody></table>
    </div>
    <h2>Linked Equipment Categories</h2>
    <p>${dept.equipment_ids.map((eid, i) => html`${i ? " · " : ""}<a href="#/ref/equipment?dept=${dept.id}#${eid}">${eid}</a>`)}</p>
    ${sourceLinks(dept.regulatory_anchors, doc.checked)}`;

  return {
    html: page({
      trail: [REF_HOME, ["Departments", "#/ref/departments"], [dept.name]],
      kicker: dept.stage_range,
      title: `${dept.icon} ${dept.name}`,
      body,
      more: dept.related_links || [],
    }),
  };
}

export async function routesRefPage() {
  const doc = await departmentsData();
  const body = html`
    <div class="tbl-wrap" tabindex="0" role="region" aria-label="Routes of administration">
      <table class="tbl"><thead><tr><th>Route / Delivery System</th><th>Formulation Rationale</th><th>Critical Quality Attributes (CQAs)</th><th>Catalogue</th></tr></thead>
      <tbody>${doc.routes.map((r) => html`<tr>
        <th scope="row">${r.name}</th>
        <td>${r.technical_rationale}</td>
        <td><ul class="plain">${r.cqas.map((c) => html`<li>${c}</li>`)}</ul></td>
        <td><a href="${r.catalogue_filter}">Browse medicines →</a></td>
      </tr>`)}</tbody></table>
    </div>
    <p class="muted small">Updated ${doc.checked}. Every route links to FDA/ICH quality guidance and the corresponding hardware in <a href="#/ref/equipment">Equipment Market</a>.</p>`;
  return {
    html: page({
      trail: [REF_HOME, ["Departments", "#/ref/departments"], ["Routes of Administration"]],
      title: "Formulation & Routes of Administration",
      lede: "How dosage forms and delivery systems are engineered to match each molecule's stability, bioavailability, and clinical use.",
      body,
      more: [
        { title: "Formulation Development Department", text: "Preformulation, scale-up, and container-closure integrity.", href: "#/ref/departments/formulation" },
        { title: "Analytical Development & QC", text: "Dissolution, HPLC/UPLC, stability, and impurity profiling.", href: "#/ref/departments/analytical" },
      ],
    }),
  };
}
