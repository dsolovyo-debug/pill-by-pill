// Entry point: hash router and the start page. Routes look like  #/explore/medicine/aspirin/molecule  or  #/ref/drugs?type=sm
//   #/                         start: choose a path
//   #/explore/...              Simple environment   (js/explore.js)
//   #/ref/...                  In-depth environment (js/reference.js)
//   #/fund                     how the site is funded (shared)
//   #/privacy, #/share         privacy note; how to link to and share the site
//   /medicine/<id>/, /medicines/  real pages built by pipeline/build_static_pages.py; they open the same views
import { html, num, store } from "./ui.js";
import * as data from "./data.js";
import { page, ROLES, exploreShell, refShell } from "./layout.js";
import * as explore from "./explore.js";
import * as reference from "./reference.js";
import * as departments from "./departments.js";
import { config, moneyFor, setPreview, heldSchemes, PAYING_ROLES } from "./money.js";
import { wireSearch } from "./search.js";

const app = document.getElementById("app");
const state = { role: store.get("role") || null, cleanup: null };

function setRole(role) { state.role = role; store.set("role", role); }

async function start() {
  const st = await data.stats();
  const cards = Object.entries(ROLES).map(([key, r]) =>
    html`<a class="role lens-card lens-${r.env}" href="${r.path}" data-role="${key}"><span aria-hidden="true">${r.icon}</span><b>${r.name}</b><i>${r.line}</i></a>`);
  return { env: "start", html: html`<div class="shell shell-start"><main id="main" tabindex="-1">
    <header class="start-head"><p class="logo big">Pill <span>by</span> Pill</p><h1>The story of the world's medicines.</h1>
      <p class="lede">${num(st.total)} medicines, each with its sources. How are you exploring today?</p></header>
    <section class="lens-grid" aria-label="Choose your lens">${cards}</section>
    <footer class="foot"><p>For learning, not medical advice. <a href="#/ref/data">Sources</a> · <a href="#/fund">How this site is funded</a> · <a href="#/privacy">Privacy</a> · <a href="#/share">Share Pill by Pill</a> · <a href="/medicines/">All medicines A to Z</a></p></footer></main></div>` };
}

async function fund(query) {
  if (query.get("preview")) setPreview(true);
  const cfg = await config();
  const blocks = await Promise.all(PAYING_ROLES.map(async (r) => [r, await moneyFor(r)]));
  const body = html`<section class="x-panel"><h2>The rules</h2><ul class="plain">
      <li>${cfg.policy.statement}</li><li>No adverts and no tracking. Nothing on this site loads from an advertising or analytics company.</li>
      <li>Student pages never show anything for sale.</li><li>Links that earn the site money are marked “Paid link” right beside the link.</li><li>Book links marked “Paid link” are Bookshop.org affiliate links: if you buy a book through one, Bookshop.org pays this site a commission. The price you pay is the same.</li>
      <li>Anything paid is sold and delivered by the shop named on the button, not by this site.</li></ul></section>
    ${blocks.some(([, b]) => String(b)) ? blocks.filter(([, b]) => String(b)).map(([r, b]) => html`<section><h2>What ${ROLES[r].name.toLowerCase()} pages show</h2>${b}</section>`)
      : html`<section class="x-panel"><h2>Right now</h2><p>No support or shop links are connected yet, so the site currently earns nothing.</p></section>`}`;
  const held = await heldSchemes();
  const heldBlock = held.length ? html`<section class="x-panel"><h2>Not offered yet</h2><p>These are set aside until a legal question is settled:</p>
    <ul class="plain">${held.map(([title, why]) => html`<li><b>${title}.</b> <span class="held">${why}</span></li>`)}</ul></section>` : "";
  const inner = page({ trail: [["Start", "#/"], ["Funding"]], title: "How this site is funded", lede: "Free to read, with no adverts. Here is exactly where money can come from.", body: html`${body}${heldBlock}` });
  return { env: state.role && ROLES[state.role].env === "ref" ? "ref" : "explore", html: inner, current: "#/fund" };
}

async function privacy() {
  const body = html`<section class="x-panel"><ul class="plain">
      <li>No accounts, no sign-up, no forms. The site does not ask for or receive your name, email or anything else about you.</li>
      <li>No cookies, no analytics and no advertising. Nothing on these pages loads from an advertising, analytics or social-media company.</li>
      <li>Your choices stay on your device: the path you picked (Simple or In-depth, and your role) and your best quiz score are kept in your browser's local storage. Clear your browser's site data to remove them.</li>
      <li>The share buttons are plain links. Nothing is sent to a social network unless you click one, and then you are on that network's site, under its own privacy policy.</li>
      <li>Links to other sites (FDA, EMA, WHO, ChEMBL, the Protein Data Bank, Bookshop.org and others) take you to them; their own privacy policies apply there.</li>
      <li>The site is served by its web host, which, like any web server, handles your device's address to deliver the pages. This site does not collect or look at visitor logs.</li></ul></section>`;
  return { env: state.role && ROLES[state.role].env === "ref" ? "ref" : "explore", current: "#/privacy",
    html: page({ trail: [["Start", "#/"], ["Privacy"]], title: "Privacy", lede: "Short version: this site does not track you.", body }) };
}

async function sharePage() {
  const cfg = await import("./share.js").then((m) => m.site());
  const base = (cfg.base_url || location.origin).replace(/\/$/, "") + "/";
  const snippet = `<a href="${base}">Pill by Pill: the story of the world's medicines</a>`;
  const body = html`<section class="x-panel"><h2>In one sentence</h2>
      <p>Pill by Pill is a free site about the world's approved medicines: what each one is, how it works, where it came from and when it was approved in the US, Europe, Canada and Japan, with a source link for every fact. It has a Simple side for students and an In-depth side for professionals, and no adverts or tracking.</p></section>
    <section class="x-panel"><h2>Link to it</h2><p class="wrap">Address: <a href="${base}">${base}</a>. Every medicine has its own page, for example <a href="${base}medicine/aspirin/">${base}medicine/aspirin/</a>.</p>
      <p>For a class page or blog, copy this link:</p><pre class="snippet">${snippet}</pre>
      <p><button type="button" class="btn small" id="copy-snippet">Copy the link code</button> <span class="muted small" id="snippet-status" aria-live="polite"></span></p></section>
    <section class="x-panel"><h2>Picture for posts and slides</h2><p><img src="img/og-card.png" alt="Pill by Pill: the story of the world's medicines" width="600" height="315" class="og-preview"></p>
      <p>Free to use when you link to the site. This is also the picture social networks show when someone shares a link.</p></section>
    <section class="x-panel"><h2>Follow new approvals</h2><p>A feed of the most recently approved medicines in the catalogue, updated each time the site is rebuilt: <a href="feed.xml">feed.xml</a> (open it in any feed reader).</p></section>`;
  return { env: "explore", current: "#/share", html: page({ trail: [["Start", "#/"], ["Share Pill by Pill"]], title: "Share Pill by Pill", lede: "For teachers, librarians, bloggers and anyone who wants to pass it on.", body }),
    mount(root) {
      root.querySelector("#copy-snippet").addEventListener("click", async () => {
        const st = root.querySelector("#snippet-status");
        try { await navigator.clipboard.writeText(snippet); st.textContent = "Copied."; } catch (e) { st.textContent = "Select the text above and copy it."; }
      });
    } };
}

/** Turn the hash into { env, html, mount, current }. */
async function resolve(parts, query) {
  const [area, a, b, c] = parts;
  if (!area) return start();
  if (area === "fund") return fund(query);
  if (area === "privacy") return privacy();
  if (area === "share") return sharePage();
  if (area === "explore") {
    const wrap = (r, current) => ({ env: "explore", current, ...r });
    if (!a) { setRole("student"); return wrap(await explore.home(), "#/explore"); }
    if (a === "teach") { setRole("teacher"); return wrap(await explore.teach()); }
    if (a === "history") { setRole("history"); return wrap(await explore.history()); }
    if (a === "medicines") return wrap(await explore.medicines(query), "#/explore/medicines");
    if (a === "medicine" && b) return wrap(await explore.medicine(b, c), "#/explore/medicines");
    if (a === "stories") return wrap(await explore.stories(), "#/explore/stories");
    if (a === "topic" && b) return wrap(await explore.topic(b, c), "#/explore/stories");
    if (a === "made") return wrap(await explore.made(), "#/explore/made");
    if (a === "how-drugs-are-built") return wrap(await departments.departmentsExplorePage(), "#/explore/how-drugs-are-built");
    if (a === "departments" && b) return wrap(await departments.departmentsExplorePage(b), "#/explore/how-drugs-are-built");
    if (a === "quiz") return wrap(await explore.quizPage(), "#/explore/quiz");
  }
  if (area === "ref") {
    const wrap = (r, current) => ({ env: "ref", current, ...r });
    const proRole = ["clinician", "chemist", "industry"].includes(state.role) ? state.role : null;
    if (!a) return wrap(await reference.overview(), "#/ref");
    if (["clinician", "chemist", "industry"].includes(a)) { setRole(a); return wrap(await reference.landing(a)); }
    if (a === "drugs") return wrap(await reference.drugs(query), "#/ref/drugs");
    if (a === "drug" && b) return wrap(await reference.drugPage(b, c), "#/ref/drugs");
    if (a === "topics") return wrap(await reference.topicsPage(proRole), "#/ref/topics");
    if (a === "topic" && b) return wrap(await reference.topic(b, c != null ? Number(c) : null), "#/ref/topics");
    if (a === "data") return wrap(await reference.dataPage(), "#/ref/data");
    if (a === "families") return wrap(await reference.familiesPage(query), "#/ref/families");
    if (a === "compare") return wrap(await reference.comparePage(b, c), "#/ref/compare");
    if (a === "departments") return wrap(await departments.departmentsRefPage(b || null), "#/ref/departments");
    if (a === "routes") return wrap(await departments.routesRefPage(), "#/ref/routes");
  }
  throw new Error("Page not found");
}

/** Real page addresses (for search engines and link previews) open the same views as the #/ routes. */
function pathRoute() {
  const m = location.pathname.match(/^\/medicine\/([^/]+)\/?$/);
  if (m) return `explore/medicine/${m[1]}`;
  if (/^\/medicines\/?$/.test(location.pathname)) return "explore/medicines";
  return "";
}

async function route() {
  if (location.hash && !location.hash.startsWith("#/") && app.dataset.ready !== undefined && app.dataset.ready !== "") {
    document.getElementById(location.hash.slice(1))?.focus();       // an in-page anchor such as the skip link: not a route
    return;
  }
  const [path, qs] = (location.hash.startsWith("#/") ? location.hash.replace(/^#\/?/, "") : pathRoute()).split("?");
  const parts = path.split("/").filter(Boolean).map(decodeURIComponent);
  if (typeof state.cleanup === "function") state.cleanup();
  state.cleanup = null;
  let view;
  try {
    view = await resolve(parts, new URLSearchParams(qs || ""));
  } catch (e) {
    const env = parts[0] === "ref" ? "ref" : "explore";
    const isNet = Boolean(e && e.network);        // set by data.getJSON when the connection, not the page, failed
    view = isNet
      ? { env, html: page({ title: "Connection interrupted", lede: "Your connection dropped while loading this page's data.",
          body: html`<p><button type="button" class="btn" id="retry-route">Try again</button> <a class="btn" href="#/">Go to the start</a></p><p class="muted small">${e.message}</p>` }),
          mount(root) { root.querySelector("#retry-route")?.addEventListener("click", () => route()); } }
      : { env, html: page({ title: "We couldn't find that page", lede: "The link may be old, or the data file did not load.",
          body: html`<p><a class="btn" href="#/">Go to the start</a></p><p class="muted">${e.message}</p>` }) };
  }
  document.body.dataset.env = view.env;
  const role = view.env === "ref" && ["clinician", "chemist", "industry"].includes(state.role) ? state.role : null;
  app.innerHTML = view.env === "explore" ? exploreShell(view.html, view.current) : view.env === "ref" ? refShell(view.html, view.current, role) : view.html;
  document.title = (app.querySelector("h1")?.textContent.trim() || "Pill by Pill") + " · Pill by Pill";
  const refInput = app.querySelector("#r-q");
  if (refInput) wireSearch(refInput, app.querySelector("#r-suggest"), (d) => `#/ref/drug/${d.id}`);
  if (view.mount) state.cleanup = view.mount(app) || null;
  window.scrollTo(0, 0);
  app.querySelector("#main")?.focus({ preventScroll: true });
  app.dataset.ready = location.hash.startsWith("#/") ? location.hash : pathRoute() ? location.pathname : "#/";   // the tests wait on this
}

addEventListener("hashchange", route);
route();
