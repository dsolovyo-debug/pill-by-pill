"""Pipeline step: drug products in Canada, from Health Canada's Drug Product Database (DPD).

The DPD lists every drug product that has a Drug Identification Number (DIN) in Canada: approved, marketed, dormant or
cancelled, with its active ingredients, current status, the date it was first marketed, its company and its ATC code.
Its public API returns each table in full, so this step downloads five of them and keeps human and radiopharmaceutical
products (not veterinary drugs or disinfectants). Products whose only schedule is "Homeopathic" are left out: they are
not medicines in the sense this catalogue uses, and their ingredient names (sulfur, arnica) would match by accident.
Data: Open Government Licence - Canada (https://open.canada.ca/en/open-government-licence-canada).
Writes raw/canada_dpd.json. Needs health-products.canada.ca.
Usage: python3 pipeline/fetch_canada.py <raw dir>
"""
import collections, datetime, json, pathlib, sys, time, urllib.request

RAW = pathlib.Path(sys.argv[1])
API = "https://health-products.canada.ca/api/drug/"
TABLES = ("drugproduct", "activeingredient", "status", "therapeuticclass", "schedule")


def table(name):
    for attempt in range(3):
        try:
            with urllib.request.urlopen(f"{API}{name}/?lang=en&type=json", timeout=600) as r:
                return json.loads(r.read())
        except Exception as e:
            print("retry", name, e, flush=True)
            time.sleep(10 * (attempt + 1))
    sys.exit(f"could not download {name}")


def main():
    t = {name: table(name) for name in TABLES}
    by_code = collections.defaultdict(lambda: {"ingredients": [], "schedules": [], "atc": []})
    for a in t["activeingredient"]:
        by_code[a["drug_code"]]["ingredients"].append(a["ingredient_name"].strip())
    for s in t["schedule"]:
        if s["schedule_name"]:
            by_code[s["drug_code"]]["schedules"].append(s["schedule_name"])
    for c in t["therapeuticclass"]:
        if c["tc_atc_number"]:
            by_code[c["drug_code"]]["atc"].append(c["tc_atc_number"])
    status = {s["drug_code"]: s for s in t["status"]}
    products, skipped = [], collections.Counter()
    for p in t["drugproduct"]:
        extra = by_code.get(p["drug_code"], {"ingredients": [], "schedules": [], "atc": []})
        if p["class_name"] not in ("Human", "Radiopharmaceutical"):
            skipped[p["class_name"]] += 1
            continue
        if extra["schedules"] and set(extra["schedules"]) == {"HOMEOPATHIC"}:
            skipped["Homeopathic"] += 1
            continue
        st = status.get(p["drug_code"], {})
        products.append({"code": p["drug_code"], "din": p["drug_identification_number"], "brand": p["brand_name"].strip(), "company": p["company_name"].strip(),
                         "class": p["class_name"], "status": st.get("status"), "status_date": st.get("history_date"),
                         "first_marketed": st.get("original_market_date"), "ingredients": sorted(set(extra["ingredients"])),
                         "schedules": sorted(set(extra["schedules"])), "atc": sorted(set(extra["atc"]))})
    out = {"source": "Health Canada Drug Product Database", "api": API, "fetched_on": datetime.date.today().isoformat(),
           "product_url": "https://health-products.canada.ca/dpd-bdpp/info?lang=eng&code={code}",
           "licence": "https://open.canada.ca/en/open-government-licence-canada", "products": products}
    (RAW / "canada_dpd.json").write_text(json.dumps(out, separators=(",", ":")))
    print("human and radiopharmaceutical products:", len(products), "left out:", dict(skipped))


if __name__ == "__main__":
    main()
