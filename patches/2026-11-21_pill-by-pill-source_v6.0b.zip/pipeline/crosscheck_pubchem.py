"""Step 3 of the data pipeline: cross-check structures against PubChem.

For every ChEMBL structure, ask PubChem (PUG REST) whether it holds a compound with the same InChIKey and record its CID.
For Drugs@FDA ingredients that ChEMBL does not list, look the name up in PubChem to get a structure.
Writes raw/pubchem.json. PubChem asks for at most 5 requests per second; this stays well under.
Usage: python3 pipeline/crosscheck_pubchem.py <raw dir> <data dir>
"""
import json, pathlib, sys, time, urllib.parse, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
PUG = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"


def call(path, post=None):
    for attempt in range(4):
        try:
            data = urllib.parse.urlencode(post).encode() if post else None
            with urllib.request.urlopen(urllib.request.Request(PUG + path, data=data), timeout=90) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            time.sleep(2 * (attempt + 1))
        except Exception:
            time.sleep(2 * (attempt + 1))
    return None


def main():
    # v5.26: keep what fetch_extra_chembl.py already added to the file, and mark a full run; before this, a fresh build found the
    # file written by that top-up, so run_all.sh skipped the cross-check and every page said "Not found in PubChem by InChIKey"
    old_file = RAW / "pubchem.json"
    prev = json.loads(old_file.read_text()) if old_file.exists() else {}
    out = {"by_inchikey": dict(prev.get("by_inchikey", {})), "by_name": {}, "checked_inchikeys": prev.get("checked_inchikeys", [])}
    keys, names = [], []
    for f in sorted((DATA / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        s = d.get("structure")
        if s and s["source"] == "ChEMBL":
            keys.append(s["inchikey"])
        elif not d.get("chembl_id") and not d.get("sequence"):
            names.append(d["name"].upper())
    for i in range(0, len(keys), 100):
        res = call("inchikey/property/InChIKey/JSON", {"inchikey": ",".join(keys[i:i + 100])})
        for p in (res or {}).get("PropertyTable", {}).get("Properties", []):
            cur = out["by_inchikey"].get(p["InChIKey"])
            out["by_inchikey"][p["InChIKey"]] = min(cur, p["CID"]) if cur else p["CID"]
        print("inchikey", min(i + 100, len(keys)), "/", len(keys), "matched", len(out["by_inchikey"]), flush=True)
        time.sleep(0.4)
    for n in names:
        res = call(f"name/{urllib.parse.quote(n)}/property/InChIKey,SMILES,MolecularFormula,MolecularWeight/JSON")
        props = (res or {}).get("PropertyTable", {}).get("Properties", [])
        if props and props[0].get("SMILES"):
            p = props[0]
            out["by_name"][n] = {"cid": p["CID"], "smiles": p["SMILES"], "inchikey": p["InChIKey"],
                                 "formula": p.get("MolecularFormula"), "weight": p.get("MolecularWeight")}
        time.sleep(0.25)
    print("name lookups", len(names), "matched", len(out["by_name"]))
    out["crosscheck"] = time.strftime("%Y-%m-%d")
    (RAW / "pubchem.json").write_text(json.dumps(out))


if __name__ == "__main__":
    main()
