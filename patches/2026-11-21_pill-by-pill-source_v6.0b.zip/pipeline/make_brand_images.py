"""Pipeline step: the pictures used when the site is shared or bookmarked.

  img/og-card.png        1200 x 630, shown by social networks and chat apps for every page (Open Graph / Twitter card)
  img/icon-192.png, img/icon-512.png, img/apple-touch-icon.png, favicon.svg   home-screen and tab icons
The molecules drawn on the card are three medicines from the catalogue (imatinib, penicillin G and aspirin), drawn by RDKit
from the SMILES in their drug files, so the picture shows real structures.
Fonts: the site's own Bricolage Grotesque and Atkinson Hyperlegible (SIL Open Font License), converted from woff2 with
fontTools (needs: pip install fonttools brotli pillow rdkit).
Usage: python3 pipeline/make_brand_images.py <site dir>
"""
import io, json, pathlib, sys, tempfile

from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont
from rdkit import Chem
from rdkit.Chem.Draw import rdMolDraw2D

SITE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site")
INK, ACCENT, PAPER, SOFT = (27, 36, 64), (204, 47, 90), (255, 255, 255), (246, 247, 251)


def font(name, size, tmp):
    ttf = pathlib.Path(tmp) / f"{name}.ttf"
    if not ttf.exists():
        f = TTFont(SITE / "fonts" / f"{name}.woff2")
        f.flavor = None
        f.save(ttf)
    return ImageFont.truetype(str(ttf), size)


def molecule(smiles, w, h):
    mol = Chem.MolFromSmiles(smiles)
    d = rdMolDraw2D.MolDraw2DCairo(w, h)
    o = d.drawOptions()
    o.clearBackground = False
    o.bondLineWidth = 3
    o.useBWAtomPalette()
    o.setBackgroundColour((0, 0, 0, 0))
    d.DrawMolecule(mol)
    d.FinishDrawing()
    img = Image.open(io.BytesIO(d.GetDrawingText())).convert("RGBA")
    # recolour the black drawing to white for the dark card
    px = [(255, 255, 255, a if r < 128 else 0) for r, g, b, a in (img.get_flattened_data() if hasattr(img, 'get_flattened_data') else img.getdata())]
    img.putdata(px)
    return img


def main():
    (SITE / "img").mkdir(exist_ok=True)
    smiles = {k: json.loads((SITE / "data" / "drugs" / f"{k}.json").read_text())["structure"]["smiles"] for k in ("aspirin", "penicillin-g", "imatinib")}
    stats = json.loads((SITE / "data" / "catalogue_stats.json").read_text())
    with tempfile.TemporaryDirectory() as tmp:
        card = Image.new("RGBA", (1200, 630), INK + (255,))
        draw = ImageDraw.Draw(card)
        for (k, x, y, w, h, alpha) in (("imatinib", 640, 30, 560, 320, 70), ("penicillin-g", 840, 340, 350, 250, 90), ("aspirin", 590, 445, 230, 160, 110)):
            m = molecule(smiles[k], w, h)
            a = m.getchannel("A").point(lambda v, al=alpha: v * al // 255)
            m.putalpha(a)
            card.alpha_composite(m, (x, y))
        logo = font("bricolage-grotesque-latin-800-normal", 92, tmp)
        draw.text((70, 150), "Pill ", font=logo, fill=PAPER)
        wpill = draw.textlength("Pill ", font=logo)
        draw.text((70 + wpill, 150), "by ", font=logo, fill=ACCENT)
        wby = draw.textlength("by ", font=logo)
        draw.text((70 + wpill + wby, 150), "Pill", font=logo, fill=PAPER)
        sub = font("atkinson-hyperlegible-latin-700-normal", 44, tmp)
        draw.text((72, 285), "The story of the world's medicines", font=sub, fill=PAPER)
        body = font("atkinson-hyperlegible-latin-400-normal", 30, tmp)
        draw.text((72, 360), f"{stats['total']:,} medicines: molecule, story, approvals.", font=body, fill=(220, 224, 236))
        draw.text((72, 404), "A source link for every fact. Free, no ads.", font=body, fill=(220, 224, 236))
        draw.rectangle((0, 610, 1200, 630), fill=ACCENT)
        card.convert("RGB").save(SITE / "img" / "og-card.png", optimize=True)
        # icons: the logo's "P" with the accent dot
        for size, name in ((512, "icon-512.png"), (192, "icon-192.png"), (180, "apple-touch-icon.png")):
            ic = Image.new("RGB", (size, size), INK)
            d = ImageDraw.Draw(ic)
            f = font("bricolage-grotesque-latin-800-normal", int(size * 0.62), tmp)
            tw = d.textlength("P", font=f)
            d.text(((size - tw) / 2 - size * 0.06, size * 0.08), "P", font=f, fill=PAPER)
            r = size * 0.11
            d.ellipse((size * 0.66 - r, size * 0.70 - r, size * 0.66 + r, size * 0.70 + r), fill=ACCENT)
            ic.save(SITE / "img" / name, optimize=True)
    (SITE / "favicon.svg").write_text(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#1b2440"/>'
        '<text x="27" y="47" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="42" fill="#fff" text-anchor="middle">P</text>'
        '<circle cx="45" cy="45" r="7" fill="#cc2f5a"/></svg>\n', encoding="utf-8")
    print("wrote img/og-card.png, icons and favicon.svg")


if __name__ == "__main__":
    main()
