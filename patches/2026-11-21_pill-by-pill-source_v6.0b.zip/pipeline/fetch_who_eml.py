"""Pipeline step: the WHO Model List of Essential Medicines, from WHO's electronic list (eEML).

Reads https://list.essentialmeds.org/ (the current list: one block per medicine, with its eEML page and the list sections it
appears in) and keeps, for each medicine: its name as WHO writes it, its eEML page, its sections, and the parts of a
fixed-dose combination ("abacavir + lamivudine"). The page lists the medicines WHO currently lists; the eEML caveats page says
the 2025 EML and EMLc PDFs are the binding versions, so the site links to both.
Licence: CC BY 3.0 IGO (https://list.essentialmeds.org/licencing). Not for use with advertising or promotion of commercial
products, no WHO logo, attribution required.
Writes raw/who_eml.json and raw/who_eml.csv (the same rows, for people to read). build_catalogue.py matches the names.
Usage: python3 pipeline/fetch_who_eml.py <raw dir> [saved page.html]
"""
import csv, datetime, html, json, pathlib, re, sys, urllib.request

RAW = pathlib.Path(sys.argv[1])
PAGE = "https://list.essentialmeds.org/"
LICENCE = "https://list.essentialmeds.org/licencing"
ATTRIBUTION = "WHO electronic Essential Medicines List (eEML), World Health Organization, 2020. https://list.essentialmeds.org/ (beta version 1.0). Licence: CC BY 3.0 IGO."   # wording required by the licensing page
EML_2025 = "https://iris.who.int/handle/10665/382243"
EMLC_2025 = "https://iris.who.int/handle/10665/382242"


def text(fragment):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", fragment))).strip()


def parse(page):
    """One record per medicine block: <h5 class="medicine-name" title="..."> ... <a href=".../medicines/N"> then its sections."""
    starts = [m.start() for m in re.finditer(r'<h5 class="medicine-name"', page)]
    out = []
    for i, s in enumerate(starts):
        block = page[s:starts[i + 1] if i + 1 < len(starts) else len(page)]
        name = html.unescape(re.search(r'title="([^"]*)"', block).group(1)).strip()
        link = re.search(r'href="(https://list\.essentialmeds\.org/medicines/\d+)"', block)
        sections = list(dict.fromkeys(text(x) for x in re.findall(r'<div class="section-name">(.*?)</div>', block, re.S)))
        parts = [p.strip() for p in re.split(r"\s+\+\s+", name) if p.strip()]
        forms = [text(x) for x in re.findall(r"<li>(.*?)</li>", block, re.S)]
        as_forms = sorted({m.strip() for f in forms for m in re.findall(r"\(as ([a-z][a-z ]+?)\)", f)})      # "(as etexilate mesilate)"
        out.append({"name": name, "url": link.group(1) if link else PAGE, "sections": sections, "parts": parts, "combination": len(parts) > 1,
                    "as_forms": as_forms})
    return out


def main():
    if len(sys.argv) > 2:
        page = pathlib.Path(sys.argv[2]).read_text(encoding="utf-8")
    else:
        req = urllib.request.Request(PAGE, headers={"User-Agent": "PillByPill-build (educational; contact via site)"})
        with urllib.request.urlopen(req, timeout=120) as r:
            page = r.read().decode("utf-8")
    medicines = parse(page)
    if len(medicines) < 400:
        raise SystemExit(f"only {len(medicines)} medicines read from the eEML page; the page layout may have changed")
    today = datetime.date.today().isoformat()
    (RAW / "who_eml.json").write_text(json.dumps({
        "source": "WHO electronic Essential Medicines List (eEML)", "page": PAGE, "checked": today, "licence": "CC BY 3.0 IGO",
        "licence_url": LICENCE, "attribution": ATTRIBUTION, "binding_versions": {"EML 2025": EML_2025, "EMLc 2025": EMLC_2025},
        "medicines": medicines}, indent=1, ensure_ascii=False), encoding="utf-8")
    with open(RAW / "who_eml.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["medicine", "eeml_url", "sections", "combination_parts", "checked", "source"])
        for m in medicines:
            w.writerow([m["name"], m["url"], "; ".join(m["sections"]), " + ".join(m["parts"]) if m["combination"] else "", today, ATTRIBUTION])
    print("eEML medicines:", len(medicines), "of which combinations:", sum(m["combination"] for m in medicines))


if __name__ == "__main__":
    main()
