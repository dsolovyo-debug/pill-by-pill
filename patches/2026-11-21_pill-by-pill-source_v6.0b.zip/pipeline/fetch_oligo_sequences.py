"""Pipeline step: strand sequences of oligonucleotide medicines from FDA's substance registry.

ChEMBL records a sequence for only some oligonucleotides, and FDA labels mostly show the sequence as a picture.
FDA's Global Substance Registration System (GSRS, https://gsrs.ncats.nih.gov) holds each strand as text, together with
coded sugar and linkage modifications. For every catalogue entry that is an oligonucleotide (ChEMBL type) or has a
curated oligonucleotide note, this looks the name up in GSRS and stores the strands exactly as recorded.
"X" or "N" in a GSRS sequence marks a position that is not a standard nucleotide (for example where a ligand is attached).
Some oligonucleotides with unusual backbones are registered as "chemical" substances instead (imetelstat: a lipid tail and
an N3'->P5' thiophosphoramidate backbone). For those, the strand is read from the registry's own systematic name, which
spells it out as "(T-A-G-G-...)", and the backbone description is kept word for word from that name. No codes are inferred.
Writes raw/oligo_sequences.json keyed by drug id. Nothing is typed by hand.
Usage: python3 pipeline/fetch_oligo_sequences.py <raw dir> <data dir>
"""
import json, pathlib, re, sys, time, urllib.parse, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
SEARCH = "https://gsrs.ncats.nih.gov/api/v1/substances/search?top=10&view=full&q="


def get(url):
    for attempt in range(3):
        try:
            return json.loads(urllib.request.urlopen(url, timeout=90).read())
        except Exception:
            time.sleep(2 * (attempt + 1))
    return {}


SPELLED = re.compile(r"\(([ACGTU](?:-[ACGTU]){5,})\)")          # "(T-A-G-G-G-T-T-A-G-A-C-A-A)" in a systematic name


def spelled_strand(s):
    """(sequence, the name it was read from) for a chemical-class record whose systematic name spells out one strand."""
    hits = [(m.group(1).replace("-", ""), n["name"]) for n in s.get("names") or [] for m in [SPELLED.search(n.get("name") or "")] if m]
    seqs = {seq for seq, _ in hits}
    if len(seqs) != 1:                                           # none, or names that disagree: take nothing
        return None
    seq = seqs.pop()
    name = next((nm for sq, nm in hits if nm.upper().startswith(("DNA,", "RNA,"))), hits[0][1])
    return seq, name


def lookup(name):
    """The GSRS nucleic-acid substance whose primary _name or official synonym in names[] is exactly this name;
    failing that, a chemical-class record of that exact name whose systematic name spells out the strand."""
    target = name.upper()
    fallback = None
    for query in (f'root_names_name:"^{name}$"', name):
        for s in get(SEARCH + urllib.parse.quote(query)).get("content", []):
            all_names = {(s.get("_name") or "").upper()} | {(n.get("name") or "").upper() for n in (s.get("names") or [])}
            if target not in all_names:
                continue
            if s.get("substanceClass") == "nucleicAcid":
                return s
            if s.get("substanceClass") == "chemical" and fallback is None and spelled_strand(s):
                fallback = s
    return fallback


def counts(items, key):
    return "; ".join(f"{x.get(key)} x{len(x.get('sites', []))}" for x in items if x.get(key))


def main():
    out = {}
    for f in sorted((DATA / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        # oligonucleotides by ChEMBL type, by curated note, or by an oligonucleotide name stem (-rsen, -siran, -aptanib, -captad, -telstat)
        if d["type"] != "Oligonucleotide" and not d.get("oligo_note") and not re.search(r"(rsen|siran|ptanib|captad|telstat)\b", d["name"].lower()):
            continue
        base = re.sub(r" (SODIUM|PEGOL SODIUM)$", "", d["name"].upper())
        s = next((hit for hit in (lookup(n) for n in dict.fromkeys([d["name"].upper(), base, base + " SODIUM"])) if hit), None)
        if not s:
            print("not in GSRS under this name:", d["name"])
            continue
        if s.get("substanceClass") == "chemical":
            seq, named = spelled_strand(s)
            strands, chemistry = [seq], {"as_named": named}
            note = "read from the registry's systematic name"
        else:
            na = s["nucleicAcid"]
            strands = [u["sequence"] for u in sorted(na.get("subunits", []), key=lambda u: u.get("subunitIndex", 0)) if u.get("sequence")]
            chemistry = {"sugars": counts(na.get("sugars", []), "sugar"), "linkages": counts(na.get("linkages", []), "linkage")}
            note = None
        if not strands:
            continue
        out[d["id"]] = {"components": [{"type": "Nucleic Acid", "note": f"strand {i + 1} of {len(strands)}, {len(seq)} positions" + (f", {note}" if note else ""),
                                        "organism": None, "sequence": seq} for i, seq in enumerate(strands)],
                        "chemistry": chemistry, "registry_class": s.get("substanceClass"),
                        "unii": s.get("approvalID"), "source": f"FDA Global Substance Registration System (UNII {s.get('approvalID')})",
                        "source_url": f"https://gsrs.ncats.nih.gov/ginas/app/ui/substances/{s.get('approvalID')}"}
        time.sleep(0.3)
    (RAW / "oligo_sequences.json").write_text(json.dumps(out, indent=1))
    print("oligonucleotides with GSRS strands:", len(out))


if __name__ == "__main__":
    main()
