#!/bin/sh
# Rebuild all generated data from the public sources. Run from the build folder: sh pipeline/run_all.sh
# Needs network access to www.ebi.ac.uk, download.open.fda.gov and pubchem.ncbi.nlm.nih.gov, plus: pip install rdkit
set -e
python3 pipeline/fetch_sources.py raw                 # 1. download (skips files already in raw/)
python3 pipeline/fetch_ema.py raw                     # 1b. EMA's nightly table (needs www.ema.europa.eu and: pip install openpyxl)
python3 pipeline/fetch_canada.py raw                  # 1c. Health Canada Drug Product Database (needs health-products.canada.ca)
# 1d. Japan: save PMDA's "List of Approved Drugs" PDF by hand as raw/japan_approvals.pdf (PMDA does not permit automated downloads), then:
python3 pipeline/read_pmda_list.py raw https://www.pmda.go.jp/files/000281190.pdf   # use the URL the PDF was saved from
python3 pipeline/fetch_who_eml.py raw                 # 1e. WHO Essential Medicines List from WHO's eEML (needs list.essentialmeds.org)
python3 pipeline/build_catalogue.py raw site/data     # 2. merge into the catalogue
# 3. PubChem cross-check, then merge again. It runs before the EU/Japan-only top-up below because that step also writes raw/pubchem.json;
#    the marker "crosscheck" is set only by a full run (v5.26: the old [ -f raw/pubchem.json ] test skipped it on every fresh build)
grep -qs '"crosscheck"' raw/pubchem.json || { python3 pipeline/crosscheck_pubchem.py raw site/data; python3 pipeline/build_catalogue.py raw site/data; }
python3 pipeline/fetch_extra_chembl.py raw site/data  # ChEMBL structures for EU-only and Japan-only entries (resumable; tops up raw/pubchem.json)
python3 pipeline/build_catalogue.py raw site/data
# 3b. slow, cached steps that read the drug files and write raw/*.json; build_catalogue merges them on the next line
#     Needs network access to files.rcsb.org as well, and: pip install gemmi
[ -f raw/manufacturing.json ] || python3 pipeline/fetch_manufacturing.py raw site/data
[ -f raw/oligo_sequences.json ] || python3 pipeline/fetch_oligo_sequences.py raw site/data   # needs gsrs.ncats.nih.gov
python3 pipeline/fetch_peptide_sequences.py raw site/data && python3 pipeline/build_catalogue.py raw site/data   # GSRS peptide sequences, then rebuild so the matcher sees them
[ -f raw/pdb_ligand_by_inchikey.json ] || python3 pipeline/fetch_structure_index.py raw site/data
python3 pipeline/fetch_structure_index.py raw site/data --targets-only   # targets named by new mechanisms only
python3 pipeline/fetch_binding.py raw site; python3 pipeline/fetch_binding_biologics.py raw site   # both skip medicines already found
python3 pipeline/fetch_binding_peptides.py raw site    # peptide medicines: exact or named-and-matching chains only
python3 pipeline/fetch_binding_related.py raw site     # no structure in the own target: same gene in another organism, labelled
python3 pipeline/fetch_binding_covalent.py raw site    # covalent medicines: the reacted ligand bonded to the target (resumable)
python3 pipeline/build_catalogue.py raw site/data
python3 pipeline/render_molecules.py site/data site   # 4. 2D layouts and 3D models
python3 pipeline/build_topics.py raw/legacy site/data # 5. curated topic data carried over from v4
python3 pipeline/build_family_trees.py site/data      # 6. medicine families (same ChEMBL stem and first target)
python3 pipeline/build_departments.py site/data       # 6b. pharmaceutical encyclopedia departments & routes
python3 pipeline/make_brand_images.py site            # 7. share picture and icons (needs: pip install fonttools brotli pillow)
python3 pipeline/build_static_pages.py site           # 8. real pages for search engines and link previews, sitemap, feed, robots, _headers
