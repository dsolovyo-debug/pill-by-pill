"""Pipeline step: binding interfaces for peptide medicines that fetch_binding_biologics.py cannot tie to a chain.

That step needs a run of 30 identical residues, which short or modified peptides never have. Here a chain in a PDB entry
that contains the medicine's ChEMBL target counts as the medicine only under one of two rules:
  A. exact: the medicine is KNOWN to be an unmodified peptide (its ChEMBL HELM notation has only standard amino acids,
     ignoring terminal [ac]/[am] caps, or FDA's GSRS record lists no modifications; letters alone are not enough, because
     insulin detemir and insulin degludec share their letters and differ only in the attached fatty acid) and the chain's sequence (or its deposited
     _entity_poly_seq full sequence in the CIF when flexible terminal residues are unmodeled, with >=80% modeled coverage)
     is identical to it, residue for residue, over the full length of both. For multi-chain peptides (such as two-chain
     insulins), every component chain of the medicine must match a non-target chain in the PDB entry so a shared chain
     (such as the human insulin A-chain) never assigns one analog's structure to another.
  B. named and matching: the PDB entry's title or PDBe's name for that chain contains the medicine's name (or its ChEMBL
     INN/USAN/research code), and the chain lines up with the ChEMBL/GSRS sequence over at least 80% of its length with
     every ordinary residue identical, except where either the PDB chain or the drug sequence has a modified residue (written X),
     and at least 80% identical overall. One ordinary residue that differs (porcine secretin against a human secretin chain)
     rules the chain out.
A sequence that is merely similar (for example the natural hormone in place of the medicine) is never accepted.
Interface and contacts are computed exactly as in fetch_binding_biologics.py. The match rule used is stored with each site.
Usage: python3 pipeline/fetch_binding_peptides.py <raw dir> <site dir>
"""
import datetime, json, pathlib, re, sys

import gemmi

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from fetch_binding import RAW, SITE, get                                            # noqa: E402
from fetch_binding_biologics import search, chain_sequence, interface, name_clause  # noqa: E402

MIN_LEN, MAX_ENTRIES = 8, 12
TERMINAL_CAPS = {"ac", "am", "for", "nh2", "oh"}


def clean_seq(s):
    """Strip inline modification digits (e.g. X1, K1, S1 in ChEMBL biocomponents) and reject 3-letter dashed strings."""
    cleaned = re.sub(r"(?<=[A-Z])\d+", "", (s or "").strip())
    return cleaned if re.fullmatch(r"[A-Z]+", cleaned) else ""


def extract_peptide_sequences(seq_block):
    """Return N-to-C 1-letter peptide strings (with modified internal residues mapped to X for Rule B alignment)."""
    comps = [c for c in seq_block.get("components", []) if c.get("type") == "Protein"]
    # Skip large multi-chain proteins (e.g. ocriplasmin with a 230-aa catalytic chain + 19-aa chain) handled by fetch_binding_biologics.py
    if any(len(c.get("sequence") or "") > 60 for c in comps):
        return []
    helm = seq_block.get("helm") or ""
    helm_seqs = []
    for chain in re.findall(r"PEPTIDE\d+\{([^}]*)\}", helm):
        tokens = [t.strip("[]") for t in chain.split(".") if t]
        while tokens and tokens[0].lower() in TERMINAL_CAPS:
            tokens = tokens[1:]
        while tokens and tokens[-1].lower() in TERMINAL_CAPS:
            tokens = tokens[:-1]
        if MIN_LEN <= len(tokens) <= 60:
            helm_seqs.append("".join(t if re.fullmatch(r"[A-Z]", t) else "X" for t in tokens))
    if helm_seqs:
        return helm_seqs
    out = []
    for c in comps:
        s = clean_seq(c.get("aligned_sequence") or c.get("sequence") or "")
        if not s and c.get("residues"):
            tokens = [t.strip("[]") for t in c["residues"] if t]
            while tokens and tokens[0].lower() in TERMINAL_CAPS:
                tokens = tokens[1:]
            while tokens and tokens[-1].lower() in TERMINAL_CAPS:
                tokens = tokens[:-1]
            s = "".join(t if re.fullmatch(r"[A-Z]", t) else "X" for t in tokens)
        if MIN_LEN <= len(s) <= 60 and s not in out:
            out.append(s)
    return out


def is_unmodified_peptide(seq_block, sequences):
    """True if the peptide has only the 20 standard amino acids (ignoring terminal [ac]/[am] caps in HELM)."""
    helm = seq_block.get("helm") or ""
    if "CHEM" in helm:
        return False
    if helm:
        stripped = re.sub(r"\bPEPTIDE\d+\{(?:\[(?:ac|am|for|nh2|oh)\]\.)?", "PEPTIDE{", helm, flags=re.I)
        stripped = re.sub(r"\.\[(?:ac|am|for|nh2|oh)\]\}|\}", "}", stripped, flags=re.I)
        if "[" in stripped:
            return False
    if any(c.get("modified_sites") for c in seq_block.get("components", [])) or seq_block.get("modifications"):
        return False
    if not helm and not seq_block.get("registry_unmodified"):
        return False                                    # no positive evidence that nothing is attached
    return bool(sequences) and all(re.fullmatch(r"[ACDEFGHIKLMNPQRSTVWY]+", s) for s in sequences)


def candidate_words(d):
    """Distinct search tokens (len >= 6) from the drug's name, INN/USAN, and alphanumeric research codes."""
    words = []
    first = re.sub(r"[^a-z0-9]", "", d["name"].lower().split()[0])
    if len(first) >= 6:
        words.append(first)
    names = d.get("names") or {}
    for group in ("inn", "usan", "ban"):
        for n in names.get(group) or []:
            w = re.sub(r"[^a-z0-9]", "", n.lower().split()[0])
            if len(w) >= 6 and w not in words:
                words.append(w)
    for code in names.get("research_codes") or []:
        c = re.sub(r"[^a-z0-9]", "", code.lower())
        if len(c) >= 6 and re.search(r"[a-z]", c) and re.search(r"\d", c) and c not in words:
            words.append(c)
    return words[:4]


def entity_full_sequence(st, chain):
    """Full deposited polymer sequence (_entity_poly_seq) for chain in st, or modeled chain_sequence(chain) if absent."""
    try:
        ent = st.get_entity_of(chain.get_polymer())
        if ent and ent.full_sequence:
            return gemmi.one_letter_code(ent.full_sequence)
    except Exception:
        pass
    return chain_sequence(chain)


def exact_chain_match(s, cs, full_cs):
    """Rule A check: modeled chain cs is identical to s, or deposited entity full_cs is identical to s and cs is an >=80% exact substring."""
    if cs == s:
        return True
    if full_cs == s and len(cs) >= max(MIN_LEN, int(0.8 * len(s))) and cs in s:
        return True
    return False


def _ungapped_identity(drug, chain, min_cover=0.8):
    best = (0.0, 0.0)
    for shift in range(-len(chain) + 1, len(drug)):
        pairs = [(drug[i], chain[i - shift]) for i in range(max(0, shift), min(len(drug), shift + len(chain)))]
        if len(pairs) >= MIN_LEN:
            if any(a != b and a != "X" and b != "X" for a, b in pairs):
                continue
            score = (sum(a == b and a != "X" for a, b in pairs) / len(pairs), len(pairs) / len(drug))
            if score[1] >= min_cover and score > best:
                best = score
    return best


def identity(drug, chain):
    """Best ungapped alignment. A sequence that only fits after shifting residues around is not accepted: a wrong
    source string (ChEMBL's semaglutide letters) is replaced upstream by the registry sequence, not bent to fit here."""
    return _ungapped_identity(drug, chain)


def main():
    targets = {t["id"]: t for t in json.loads((RAW / "chembl_targets.json").read_text())}
    summary = json.loads((RAW / "binding.json").read_text())
    (RAW / "pdb").mkdir(exist_ok=True)
    tried = found = 0
    for f in sorted((SITE / "data" / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        seq = d.get("sequence") or {}
        sequences = extract_peptide_sequences(seq)
        if d["type"] != "Protein" or not d["mechanisms"] or summary.get(d["id"]) or not sequences:
            continue
        unmodified = is_unmodified_peptide(seq, sequences)
        has_helm = bool(seq.get("helm"))
        words = candidate_words(d)
        tried += 1
        result = None
        for m in d["mechanisms"]:
            t = targets.get(m["target_chembl_id"])
            if not t or not t["accessions"]:
                continue
            accessions = " OR ".join(t["accessions"][:12])
            fields = "pdb_id,resolution,experimental_method,title"
            word_clause = name_clause(words)
            named_hits = search(f"uniprot_accession:({accessions}) AND ({word_clause})", fields, 16) if words else []
            other_hits = search(f"uniprot_accession:({accessions}) AND number_of_polymer_entities:[2 TO *]", fields, 60) if unmodified else []
            seen = []
            for doc in named_hits + other_hits:
                if doc["pdb_id"] in seen or not doc.get("resolution") or doc["resolution"] > 4.5:
                    continue
                if len(seen) >= MAX_ENTRIES:
                    break
                seen.append(doc["pdb_id"])
                entities = search(f"pdb_id:{doc['pdb_id']}", "molecule_name,chain_id,uniprot_accession", 60)
                target_chains = {c for e in entities if set(e.get("uniprot_accession") or []) & set(t["accessions"]) for c in e.get("chain_id", [])}
                title_low = (doc.get("title") or "").lower()
                in_title = any(w in title_low for w in words)
                named = {c for e in entities if any(w in " ".join(e.get("molecule_name") or []).lower() for w in words) for c in e.get("chain_id", [])}
                if not target_chains:
                    continue
                blob = get(f"https://files.rcsb.org/download/{doc['pdb_id'].upper()}.cif", binary=True)
                if not blob:
                    continue
                path = RAW / "pdb" / f"{doc['pdb_id']}.cif"
                path.write_bytes(blob)
                try:
                    st = gemmi.read_structure(str(path))
                    st.setup_entities()
                    model = st[0]
                    non_target = [(c.name, chain_sequence(c), entity_full_sequence(st, c))
                                  for c in model if c.name not in target_chains and 8 <= len(c.get_polymer()) <= 80]
                    # For multi-chain peptides (such as 2-chain insulins), require every chain of the medicine to match in the entry
                    if len(sequences) > 1:
                        all_exact = unmodified and all(any(exact_chain_match(s, cs, fcs) for _, cs, fcs in non_target) for s in sequences)
                        if not all_exact:
                            path.unlink(missing_ok=True)
                            continue
                    how = {}
                    def is_drug(chain):
                        cs = chain_sequence(chain)
                        if len(cs) > 80:
                            return False
                        fcs = entity_full_sequence(st, chain)
                        if unmodified and any(exact_chain_match(s, cs, fcs) for s in sequences):
                            how[chain.name] = "A"; return True
                        if (in_title or chain.name in named) and len(sequences) == 1:
                            ident, cover = max(identity(s, cs) for s in sequences)
                            if ident >= 0.8:
                                how[chain.name] = f"B {round(ident * 100)}% identical over {round(cover * 100)}% of the sequence"; return True
                            # Ends left unmodelled: judge the deposited sequence (_entity_poly_seq) instead, as long as the
                            # residues that were modelled still line up without a single ordinary mismatch over >= 70%.
                            ident, cover = max(identity(s, fcs) for s in sequences)
                            mident, mcover = max(_ungapped_identity(s, cs, 0.7) for s in sequences)
                            if ident >= 0.8 and cover >= 0.95 and mident >= 0.8:
                                how[chain.name] = (f"B {round(ident * 100)}% identical over {round(cover * 100)}% of the sequence as deposited "
                                                   f"({round(mcover * 100)}% of it modelled in 3D)"); return True
                        return False
                    site = interface(path, target_chains, is_drug)
                except Exception:
                    site = None
                path.unlink(missing_ok=True)
                if site:
                    rule = how[site["drug_chains"][0]]
                    (SITE / "bind" / f"{d['id']}.json").write_text(json.dumps(site, separators=(",", ":")))
                    kinds = [c[3] for c in site["contacts"]]
                    match = ("chain sequence is identical to the recorded sequence of this unmodified peptide" if rule == "A" else
                             f"chain named after the medicine in the PDB entry and {rule[2:]} on record (differences only at modified residues)")
                    result = {"pdb_id": doc["pdb_id"], "resolution": doc["resolution"], "method": (doc.get("experimental_method") or [""])[0], "title": doc.get("title"),
                              "ligand_code": "chain " + ", ".join(site["drug_chains"]), "kind": "protein", "match": match,
                              "target": t["name"], "target_chembl_id": t["id"], "organism": t["organism"], "mechanism": m["text"],
                              "residues": [r["label"] for r in site["residues"]], "polar": kinds.count("polar"), "nonpolar": kinds.count("nonpolar"), "metal": 0,
                              "url": f"https://www.rcsb.org/structure/{doc['pdb_id'].upper()}", "checked": datetime.date.today().isoformat()}
                    break
            if result:
                break
        if result:
            summary[d["id"]] = result; found += 1
            print(d["id"], result["pdb_id"], result["target"][:36], "|", result["match"][:70], flush=True)
            (RAW / "binding.json").write_text(json.dumps(summary))
    print("done. peptide interfaces:", found, "of", tried, "tried")


if __name__ == "__main__":
    main()
