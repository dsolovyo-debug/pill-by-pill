#!/usr/bin/env python3
"""Build Pharmaceutical Encyclopedia department & route-of-administration datasets (Pill by Pill v6.0b).

Generates `site/data/departments.json` covering:
  - Formulation Development & Routes of Administration (`formulation`)
  - Analytical Development & Quality Control (`analytical`)
  - Early-Stage Discovery & Preclinical (`discovery`)
  - Commercial Manufacturing & Bioprocessing (`manufacturing`)

Optionally scans `site/data/drugs/*.json` (when present) to compute live catalogue counts
by modality/route so every department links directly into the 3,379-medicine catalogue.

Usage:
  python3 pipeline/build_departments.py site/data
"""
import json
import pathlib
import sys

CHECKED = "2026-11-20"

ROUTES_OF_ADMINISTRATION = [
    {
        "id": "oral-solid",
        "name": "Oral Solid Dosage (Tablets & Capsules)",
        "plain_summary": "Swallowed pills and capsules are the most common way to take medicine because they are easy to store, transport, and take at home without needles.",
        "technical_rationale": "Preferred for chemically stable small molecules with adequate aqueous solubility and intestinal permeability (BCS Classes I–IV). Subject to gastric pH degradation and hepatic first-pass metabolism; modified-release coatings or matrices control plasma Cmax and dosing frequency.",
        "cqas": ["Assay & content uniformity", "Dissolution profile (USP <711>)", "Disintegration & tablet friability", "Related substances / degradation products", "Water activity & residual solvents"],
        "equipment_ids": ["eq-rotary-tablet-press", "eq-fluid-bed-granulator", "eq-dissolution-bath", "eq-hplc-uplc"],
        "catalogue_filter": "#/ref/drugs?type=sm",
        "sources": [
            {"label": "FDA Guidance: Q8(R2) Pharmaceutical Development", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/q8r2-pharmaceutical-development"},
            {"label": "FDA Guidance: Dissolution Testing of Immediate Release Solid Oral Dosage Forms", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/dissolution-testing-immediate-release-solid-oral-dosage-forms"},
        ],
    },
    {
        "id": "sterile-parenteral",
        "name": "Sterile Parenteral (IV, SC & IM Injectables)",
        "plain_summary": "Injections and IV drips send medicine directly into the bloodstream or under the skin—essential for proteins, antibodies, and emergencies where pills would be digested in the stomach.",
        "technical_rationale": "Bypasses gastrointestinal proteolysis and first-pass hepatic clearance, delivering 100% bioavailability (IV) or controlled depot absorption (SC/IM). Requires strict sterility assurance, endotoxin control, sub-visible particulate limits, and often lyophilization for unstable biologics.",
        "cqas": ["Sterility & container-closure integrity (CCI)", "Bacterial endotoxins (USP <85>)", "Sub-visible & visible particulates (USP <788>)", "pH, osmolality & viscosity (SC syringability)", "Protein aggregation / sub-visible dimers"],
        "equipment_ids": ["eq-lyophilizer", "eq-sterile-fill-finish", "eq-single-use-bioreactor", "eq-hplc-uplc"],
        "catalogue_filter": "#/ref/drugs?type=ab",
        "sources": [
            {"label": "FDA Guidance: Sterile Drug Products Produced by Aseptic Processing — cGMP", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/sterile-drug-products-produced-aseptic-processing-current-good-manufacturing-practice"},
        ],
    },
    {
        "id": "lnp-oligo",
        "name": "Lipid Nanoparticles (LNP) & Oligonucleotide Delivery",
        "plain_summary": "Gene-targeted RNA medicines are fragile and cannot enter cells alone, so scientists wrap them in microscopic fat droplets (lipid nanoparticles) or attach sugar homing tags (GalNAc).",
        "technical_rationale": "Ionizable cationic lipids encapsulate polyanionic siRNA or mRNA via microfluidic rapid mixing, protecting cargo from serum nucleases and enabling endosomal escape. Alternatively, trivalent GalNAc conjugation targets hepatic ASGPR receptors for subcutaneous delivery.",
        "cqas": ["Particle size distribution (PDI) & zeta potential", "Encapsulation efficiency (%)", "Lipid identity & ionizable lipid ratio", "Oligonucleotide strand purity & sequence identity", "Sterility & endotoxin"],
        "equipment_ids": ["eq-sterile-fill-finish", "eq-lc-ms-ms", "eq-hplc-uplc"],
        "catalogue_filter": "#/ref/drugs?type=ol",
        "sources": [
            {"label": "FDA Guidance: Drug Products, Including Biological Products, that Contain Nanomaterials", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/drug-products-including-biological-products-contain-nanomaterials-guidance-industry"},
        ],
    },
    {
        "id": "inhaled-pulmonary",
        "name": "Inhaled & Pulmonary (MDI, DPI & Nebulizers)",
        "plain_summary": "Inhalers and nebulizers deliver medicine straight into the lungs as a fine mist or dry powder so it acts quickly on airways with lower doses than a pill.",
        "technical_rationale": "Targets local respiratory receptors (beta-2 agonists, inhaled corticosteroids) or rapid alveolar absorption while minimizing systemic exposure. Performance depends on aerodynamic particle size distribution (typically 1–5 µm respirable fraction) and device-formulation pairing.",
        "cqas": ["Aerodynamic particle size distribution (APSD)", "Delivered dose uniformity (DDU)", "Spray pattern & plume geometry (MDIs)", "Extractables & leachables from device components", "Moisture sensitivity (DPIs)"],
        "equipment_ids": ["eq-hplc-uplc", "eq-karl-fischer", "eq-stability-chamber"],
        "catalogue_filter": "#/ref/drugs?atc=R",
        "sources": [
            {"label": "FDA Draft Guidance: Metered Dose Inhaler (MDI) and Dry Powder Inhaler (DPI) Drug Products—Quality Considerations (2018)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/metered-dose-inhaler-mdi-and-dry-powder-inhaler-dpi-drug-products-quality-considerations"},
        ],
    },
    {
        "id": "ophthalmic-transdermal",
        "name": "Ophthalmic, Topical & Transdermal Systems",
        "plain_summary": "Eye drops, creams, and skin patches deliver medicine right where it is needed—or steadily through the skin over hours or days.",
        "technical_rationale": "Ophthalmic solutions/suspensions require sterility, isotonicity, and preservative compatibility; transdermal delivery systems (TDS) provide zero-order systemic release across the stratum corneum while avoiding GI and hepatic first-pass variability.",
        "cqas": ["Sterility & antimicrobial effectiveness (ophthalmic)", "In vitro permeation / release testing (IVPT / IVRT)", "Adhesion & cold-flow stability (patches)", "Viscosity & drop-size uniformity"],
        "equipment_ids": ["eq-sterile-fill-finish", "eq-hplc-uplc", "eq-stability-chamber"],
        "catalogue_filter": "#/ref/drugs?atc=S",
        "sources": [
            {"label": "FDA Draft Guidance: Transdermal and Topical Delivery Systems—Product Development and Quality Considerations (2019)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transdermal-and-topical-delivery-systems-product-development-and-quality-considerations"},
        ],
    },
]

DEPARTMENTS = [
    {
        "id": "formulation",
        "name": "Formulation Development & Routes of Administration",
        "icon": "💊",
        "stage_range": "Preclinical → Phase III",
        "status": "complete",
        "plain_summary": "An active drug molecule by itself is rarely usable—it might taste awful, dissolve poorly, or break down in stomach acid. Formulation scientists design the exact tablet, capsule, sterile liquid, inhaler, or nanoparticle that gets the medicine safely to its target in the body.",
        "technical_summary": "Bridges drug substance (API) physicochemical profiling (preformulation: pKa, logP, polymorph screening, excipient compatibility) to robust drug product design under Quality by Design (ICH Q8(R2)). Selects the route of administration, excipient matrix, and scalable unit operations (granulation, compression, lyophilization, aseptic fill-finish).",
        "workflows": [
            {"step": "1. Preformulation & Solid-State Characterization", "plain": "Test how the raw drug powder dissolves, absorbs water, and holds up to heat and light.", "expert": "Polymorph & salt screening, BCS solubility/permeability profiling, hygroscopicity (DVS), and binary excipient compatibility."},
            {"step": "2. Dosage Form & Excipient Design", "plain": "Choose inactive ingredients (binders, coatings, buffers, or lipids) that protect the medicine and control how fast it releases.", "expert": "Excipient selection via FDA Inactive Ingredient Database (IID), release-rate architecture (IR, enteric DR, HPMC/OROS ER, depot, LNP), and tonicity/pH buffering for injectables."},
            {"step": "3. Process Development & Scale-Up", "plain": "Turn a small lab recipe into a repeatable factory process that makes thousands of identical doses per hour.", "expert": "Unit operation optimization (high-shear/fluid-bed granulation, roller compaction, rotary compression, lyophilization cycle design, microfluidic LNP mixing) with Design Space characterization."},
            {"step": "4. Packaging & Container-Closure Integrity", "plain": "Pick bottles, blisters, vials, or prefilled syringes that keep moisture, oxygen, and germs out.", "expert": "Extractables & leachables (E&L) evaluation, moisture vapor transmission rate (MVTR), and Container-Closure Integrity Testing (CCIT) for sterile products."},
        ],
        "regulatory_anchors": [
            {"label": "ICH Q8(R2) Pharmaceutical Development (FDA)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/q8r2-pharmaceutical-development"},
            {"label": "FDA Inactive Ingredient Search for Approved Drug Products (IID)", "url": "https://www.accessdata.fda.gov/scripts/cder/iig/index.cfm"},
        ],
        "equipment_ids": ["eq-rotary-tablet-press", "eq-fluid-bed-granulator", "eq-lyophilizer", "eq-sterile-fill-finish"],
        "related_links": [
            {"title": "Routes of Administration Guide", "href": "#/ref/routes", "text": "Compare oral solid, sterile parenteral, LNP/oligo, inhaled, and topical delivery."},
            {"title": "Excipients & PK Release Simulator", "href": "#/ref/topic/excipients", "text": "See how IR, enteric, extended-release, and depot designs shape blood levels."},
        ],
    },
    {
        "id": "analytical",
        "name": "Analytical Development & Quality Control (QC)",
        "icon": "🔬",
        "stage_range": "Preclinical → Commercial Release",
        "status": "complete",
        "plain_summary": "Analytical scientists are the detectives and referees of medicine-making. They build ultra-sensitive tests to prove every batch has the exact right amount of medicine, no harmful impurities, and stays potent until the expiration date on the box.",
        "technical_summary": "Develops, qualifies, and validates phase-appropriate analytical methods (ICH Q2(R2)) to measure identity, assay/potency, impurities (ICH Q3A/B/C/D), dissolution (USP <711>), and shelf-life stability (ICH Q1A(R2)). Transfers validated methods to cGMP QC release laboratories operating under 21 CFR Part 211 and 21 CFR Part 11 data integrity controls.",
        "workflows": [
            {"step": "1. Method Development & Forced Degradation", "plain": "Intentionally stress the drug with heat, light, acid, or oxygen to make sure the test can spot any breakdown products.", "expert": "Stability-indicating chromatographic method development (RP-HPLC/UPLC, HILIC, SEC, IEX) verified by forced degradation and mass-balance studies."},
            {"step": "2. Method Validation (ICH Q2(R2))", "plain": "Prove the test gives accurate, repeatable answers every time, in any lab.", "expert": "Validation of specificity, linearity/range, accuracy, precision (repeatability & intermediate), LOD/LOQ, and robustness prior to Phase III/NDA filing."},
            {"step": "3. Impurity & Elemental Profiling (ICH Q3)", "plain": "Hunt for trace leftover chemicals, nitrosamines, or heavy metals down to parts per billion.", "expert": "Trace organic impurities & nitrosamine risk assessment via LC-MS/MS and GC-MS; elemental impurities (Cd, Pb, As, Hg) via ICP-MS per ICH Q3D; residual solvents per ICH Q3C."},
            {"step": "4. Stability & Batch Release Testing (QC)", "plain": "Store batches in climate chambers for months or years and test every finished lot before patients receive it.", "expert": "Real-time (25 °C/60% RH or 2–8 °C) and accelerated (40 °C/75% RH) ICH Q1A stability protocols, Certificate of Analysis (CoA) release, and OOS/OOT investigations."},
        ],
        "regulatory_anchors": [
            {"label": "ICH Q2(R2) Validation of Analytical Procedures (FDA)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/q2r2-validation-analytical-procedures"},
            {"label": "ICH Q1A(R2) Stability Testing of New Drug Substances and Products (FDA)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/q1ar2-stability-testing-new-drug-substances-and-products"},
            {"label": "ICH Q3D Elemental Impurities (FDA)", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/q3dr2-guideline-elemental-impurities"},
            {"label": "FDA 21 CFR Part 11 Electronic Records & Signatures Guidance", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/part-11-electronic-records-electronic-signatures-scope-and-application"},
        ],
        "equipment_ids": ["eq-hplc-uplc", "eq-lc-ms-ms", "eq-dissolution-bath", "eq-karl-fischer", "eq-stability-chamber", "eq-icp-ms"],
        "related_links": [
            {"title": "Equipment Market & Specs", "href": "#/ref/equipment", "text": "Inspect analytical hardware, leading OEMs, and public/secondary pricing bands."},
            {"title": "Manufacturers & Site Audits", "href": "#/ref/vendors", "text": "Compare facility FDA Form 483 lab-control and data-integrity records."},
        ],
    },
    {
        "id": "discovery",
        "name": "Early-Stage Discovery & Preclinical R&D",
        "icon": "🧬",
        "stage_range": "Target ID → IND Filing",
        "status": "scaffold",
        "plain_summary": "Before a medicine is ever tested in people, scientists identify the biological target behind a disease, test thousands of candidate molecules, image how the best ones lock into their target in 3D, and check basic safety.",
        "technical_summary": "Encompasses target validation, high-throughput screening (HTS), hit-to-lead medicinal chemistry or antibody discovery (phage display/hybridoma), structural biology (X-ray crystallography, cryo-EM, NMR), in vitro ADME/PK, and Good Laboratory Practice (GLP, 21 CFR Part 58) nonclinical safety studies supporting an IND submission.",
        "workflows": [
            {"step": "1. Target Identification & High-Throughput Screening", "plain": "Screen thousands of molecules with lab robots to find initial 'hits' that affect a disease protein.", "expert": "Biochemical and cell-based HTS assays using automated liquid handlers and multimode plate readers."},
            {"step": "2. Structural Biology & Lead Optimization", "plain": "Map the 3D atomic pocket of the target so chemists can reshape the molecule for a tighter, safer fit.", "expert": "Structure-based drug design (SBDD) via X-ray crystallography, cryo-EM, and NMR—directly reflected in this site's 485 PDB binding-site animations."},
            {"step": "3. Preclinical ADME/PK & GLP Toxicology", "plain": "Verify how the candidate moves through the body and establish safe starting doses before Phase I human trials.", "expert": "Metabolic stability, CYP inhibition, hERG cardiac safety, and multi-species GLP toxicology studies under 21 CFR Part 58."},
        ],
        "regulatory_anchors": [
            {"label": "FDA Drug Development Process — Step 1: Discovery and Development", "url": "https://www.fda.gov/patients/drug-development-process/step-1-discovery-and-development"},
            {"label": "FDA Good Laboratory Practice (GLP) Regulations (21 CFR Part 58)", "url": "https://www.ecfr.gov/current/title-21/chapter-I/subchapter-A/part-58"},
        ],
        "equipment_ids": ["eq-hts-liquid-handler", "eq-lc-ms-ms"],
        "related_links": [
            {"title": "3D Experimental Binding Animations (485)", "href": "#/ref/drugs?has=binding", "text": "Explore real PDB crystal and cryo-EM drug-target pockets."},
            {"title": "Medicine Families (297 Trees)", "href": "#/ref/families", "text": "See how follow-on drugs evolved from first-in-class discoveries."},
        ],
    },
    {
        "id": "manufacturing",
        "name": "Commercial Manufacturing & Bioprocessing",
        "icon": "🏭",
        "stage_range": "Phase III / PPQ → Commercial",
        "status": "scaffold",
        "plain_summary": "Making a few grams in a research lab is very different from making millions of sterile, identical doses for hospitals and pharmacies around the world. Commercial manufacturing scales up chemistry or living cell factories under strict cleanroom rules.",
        "technical_summary": "Covers API chemical synthesis scale-up or upstream/downstream biologics processing (cell culture bioreactors, harvest, Protein A / ion-exchange chromatography, tangential flow filtration, viral clearance), Process Performance Qualification (PPQ), ICH 3.2.S.2.6 batch comparability, and cGMP cleanroom operations (21 CFR Parts 210/211).",
        "workflows": [
            {"step": "1. Upstream Synthesis or Bioreactor Production", "plain": "Build the active ingredient in large chemical reactors or brew biologic proteins inside living cells.", "expert": "cGMP API synthesis or fed-batch/perfusion mammalian/microbial culture in single-use or stainless-steel bioreactors."},
            {"step": "2. Downstream Purification & Isolation", "plain": "Filter and purify the active medicine until it meets pharmaceutical purity standards.", "expert": "Preparative chromatography skids, tangential flow filtration (TFF), viral inactivation/filtration, and crystallization."},
            {"step": "3. Process Validation (PPQ) & cGMP Inspections", "plain": "Run consecutive full-scale batches to prove the factory produces consistent quality before regulators inspect the site.", "expert": "Stage 1–3 FDA Process Validation, Pre-Approval Inspections (PAI), and ongoing Continued Process Verification (CPV)."},
        ],
        "regulatory_anchors": [
            {"label": "FDA Guidance: Process Validation — General Principles and Practices", "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/process-validation-general-principles-and-practices"},
            {"label": "FDA cGMP for Finished Pharmaceuticals (21 CFR Part 211)", "url": "https://www.ecfr.gov/current/title-21/chapter-I/subchapter-C/part-211"},
        ],
        "equipment_ids": ["eq-single-use-bioreactor", "eq-lyophilizer", "eq-sterile-fill-finish"],
        "related_links": [
            {"title": "Manufacturers, CDMOs & Site Audits", "href": "#/ref/vendors", "text": "Compare manufacturing sites by stage, modality, and FDA/EMA audit history."},
            {"title": "How Medicines Are Made (By Modality)", "href": "#/explore/made", "text": "Compare chemical synthesis, fermentation, and recombinant cells."},
        ],
    },
]


def _catalogue_modality_counts(data_dir: pathlib.Path) -> dict:
    drugs_dir = data_dir / "drugs"
    if not drugs_dir.is_dir():
        return {}
    counts = {}
    for fp in drugs_dir.glob("*.json"):
        d = json.loads(fp.read_text(encoding="utf-8"))
        t = d.get("type") or "Unknown"
        counts[t] = counts.get(t, 0) + 1
    return counts


def build_departments(data_dir: pathlib.Path) -> dict:
    data_dir.mkdir(parents=True, exist_ok=True)
    mod_counts = _catalogue_modality_counts(data_dir)
    payload = {
        "checked": CHECKED,
        "department_count": len(DEPARTMENTS),
        "route_count": len(ROUTES_OF_ADMINISTRATION),
        "catalogue_modality_counts": mod_counts,
        "departments": DEPARTMENTS,
        "routes": ROUTES_OF_ADMINISTRATION,
    }
    out_path = data_dir / "departments.json"
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {
        "written": str(out_path),
        "departments": len(DEPARTMENTS),
        "routes": len(ROUTES_OF_ADMINISTRATION),
        "catalogue_types_counted": len(mod_counts),
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: python3 pipeline/build_departments.py <site/data>")
    print(json.dumps(build_departments(pathlib.Path(sys.argv[1])), indent=2))
