"""Pipeline step: ChEMBL records for medicines that only a regulator lists (EMA-only and PMDA-only entries).

ChEMBL's approved set (maximum phase 4) misses some medicines approved only in the EU or Japan; ChEMBL often still has
them at an earlier phase. For each such entry with a plain substance name (not a vaccine, extract, cell or tissue
product), this looks the name up in ChEMBL (preferred name, then synonym, exact match,
case ignored) and keeps it only when the name points to exactly one parent molecule. It stores the ChEMBL id, molecule
type, structure, a few computed properties and any mechanisms with their references. The highest phase ChEMBL records is
kept too, so the site can say that ChEMBL has not recorded the approval.
build_catalogue.py uses the result two ways: if the ChEMBL molecule is one the catalogue already has, the EU or Japanese
record is filed under that medicine instead of a separate entry; otherwise the entry gets the structure and mechanisms.
Writes raw/extra_chembl.json keyed by the upper-case name. Each answer (match or no match) is kept in
raw/extra_chembl_cache.json, so a run that is stopped picks up where it left off; delete that file to ask ChEMBL again. Run after build_catalogue.py, then run build_catalogue.py again.
Usage: python3 pipeline/fetch_extra_chembl.py <raw dir> <data dir>
"""
import concurrent.futures, json, pathlib, re, sys, threading, time, urllib.error, urllib.parse, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
API = "https://www.ebi.ac.uk/chembl/api/data/"


def get(path, **params):
    url = API + path + ".json?" + urllib.parse.urlencode(params)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as r:
                return json.loads(r.read())
        except Exception as e:
            if isinstance(e, urllib.error.HTTPError) and e.code == 404:
                return {}
            time.sleep(3 * (attempt + 1))
    raise RuntimeError("ChEMBL did not answer: " + url)            # never record a failed request as "no match"


def parents(molecules):
    out = {}
    for m in molecules:
        pid = ((m.get("molecule_hierarchy") or {}).get("parent_chembl_id")) or m["molecule_chembl_id"]
        out.setdefault(pid, m)
    return out


def main():
    names = []
    skip = re.compile(r"vaccine|virus|cells?\b|extract|powder|lysate|microbiota|antigen|tissue|fibrinogen|human|allogeneic|autologous|\(\d+[a-z]+\)|\[\d+", re.I)
    for f in sorted((DATA / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        if (d.get("jp") or d.get("eu")) and not d.get("chembl_id") and not d.get("us") and d["type"] not in ("Vaccine component", "Cell", "Gene") \
                and len(d["name"].split()) <= 3 and not skip.search(d["name"]):
            names.append(d["name"])
    cache_file = RAW / "extra_chembl_cache.json"
    cache = json.loads(cache_file.read_text()) if cache_file.exists() else {}
    lock = threading.Lock()

    def look_up(name):
        hits = parents(get("molecule", pref_name__iexact=name, limit=20).get("molecules", []))
        how = "preferred name"
        if not hits:
            hits = parents(get("molecule", molecule_synonyms__molecule_synonym__iexact=name, limit=20).get("molecules", []))
            how = "synonym"
        if len(hits) != 1:
            return {"no_match": len(hits)}
        pid, m = next(iter(hits.items()))
        if pid != m["molecule_chembl_id"]:
            m = get(f"molecule/{pid}") or m
        s, p = m.get("molecule_structures") or {}, m.get("molecule_properties") or {}
        mechs = get("mechanism", molecule_chembl_id__in=",".join({pid, m["molecule_chembl_id"]}), limit=50).get("mechanisms", [])
        tids = sorted({x["target_chembl_id"] for x in mechs if x.get("target_chembl_id")})
        tnames = {t["target_chembl_id"]: t["pref_name"] for t in get("target", target_chembl_id__in=",".join(tids), limit=50).get("targets", [])} if tids else {}
        return {
            "chembl_id": pid, "matched_by": how, "pref_name": m.get("pref_name"), "molecule_type": m.get("molecule_type"), "max_phase": m.get("max_phase"),
            "structure": {"smiles": s.get("canonical_smiles"), "inchikey": s.get("standard_inchi_key"),
                          "inchi": s.get("standard_inchi") if len(s.get("standard_inchi") or "") < 700 else None} if s.get("canonical_smiles") else None,
            "properties": {k: p.get(f) for k, f in (("formula", "full_molformula"), ("weight", "full_mwt"), ("alogp", "alogp"), ("hbd", "hbd"), ("hba", "hba"),
                                                    ("psa", "psa"), ("rotatable_bonds", "rtb"), ("ro5_violations", "num_ro5_violations"),
                                                    ("aromatic_rings", "aromatic_rings"), ("heavy_atoms", "heavy_atoms"))} if p else None,
            "mechanisms": [{"text": x["mechanism_of_action"], "action": x["action_type"], "target_chembl_id": x["target_chembl_id"],
                            "target_name": tnames.get(x["target_chembl_id"]),
                            "refs": [{"type": r["ref_type"], "url": r["ref_url"]} for r in x.get("mechanism_refs") or [] if (r.get("ref_url") or "").startswith("https://")][:3]}
                           for x in mechs if x.get("mechanism_of_action")]}

    def one(name):
        try:
            r = look_up(name)
        except RuntimeError as e:
            print(name, ": not answered this run, will ask again next run", e, flush=True)
            return
        with lock:
            cache[name.upper()] = r
            cache_file.write_text(json.dumps(cache, indent=1))
        print(name, "->", r.get("chembl_id") or f"no single ChEMBL match ({r.get('no_match')})", r.get("molecule_type") or "", flush=True)

    todo = [n for n in names if n.upper() not in cache]
    print(len(names), "names;", len(names) - len(todo), "already answered;", len(todo), "to ask ChEMBL", flush=True)
    with concurrent.futures.ThreadPoolExecutor(4) as pool:          # ChEMBL's API is slow at times; four requests at once, no more
        list(pool.map(one, todo))
    out = {k: v for k, v in sorted(cache.items()) if "chembl_id" in v}  # keep entries merged by build_catalogue on earlier runs
    (RAW / "extra_chembl.json").write_text(json.dumps(out, indent=1))
    # top up the PubChem cross-check (raw/pubchem.json) for these structures, so "not found in PubChem" is never said unchecked
    pc_file = RAW / "pubchem.json"
    pc = json.loads(pc_file.read_text()) if pc_file.exists() else {"by_inchikey": {}, "by_name": {}}
    keys = sorted({v["structure"]["inchikey"] for v in out.values() if v["structure"]} - set(pc["by_inchikey"]))
    if keys:
        req = urllib.request.Request("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchikey/property/InChIKey/JSON",
                                     data=urllib.parse.urlencode({"inchikey": ",".join(keys)}).encode())
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                for prop in json.loads(r.read()).get("PropertyTable", {}).get("Properties", []):
                    cur = pc["by_inchikey"].get(prop["InChIKey"])
                    pc["by_inchikey"][prop["InChIKey"]] = min(cur, prop["CID"]) if cur else prop["CID"]
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise
        pc.setdefault("checked_inchikeys", [])
        pc["checked_inchikeys"] = sorted(set(pc["checked_inchikeys"]) | set(keys))
        pc_file.write_text(json.dumps(pc))
        print("PubChem cross-check topped up for", len(keys), "structures")
    print("regulator-only entries matched in ChEMBL:", len(out), "of", len(names))


if __name__ == "__main__":
    main()
