"""Pipeline step: approvals of new drugs in Japan, from PMDA's English "List of Approved Drugs" (April 2004 onwards).

PMDA (Pharmaceuticals and Medical Devices Agency) publishes one PDF that lists every new-drug approval and partial change
it reviewed since April 2004: review category, approval date, brand names with the applicant company, whether each
product was a new approval or a change, the active ingredient, and a note. The note says "a new active ingredient" when the
ingredient was approved in Japan for the first time.
This step reads the PDF's tables and keeps only facts:
date, brand names, applicant, approval or change, ingredient, and the two flags "new active ingredient" and "orphan drug".
The notes themselves are not copied.
Not covered: drugs approved in Japan before April 2004 (unless they had a later change), generics, and products that PMDA
did not review as new drugs.
No download happens here. PMDA's site policy (https://www.pmda.go.jp/english/0013.html) does not permit automated
download applications, so a person downloads the PDF by hand from
https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html and saves it as
raw/japan_approvals.pdf. PMDA content is under the Public Data License 1.0; because the table is restructured here, the
site cites it as "Created by editing ..." with PMDA named and linked.
Writes raw/japan_approvals.json. Needs pdfplumber.
Usage: python3 pipeline/read_pmda_list.py <raw dir> <URL the PDF was downloaded from>
"""
import datetime, json, pathlib, re, sys

import pdfplumber

RAW, PDF_URL = pathlib.Path(sys.argv[1]), sys.argv[2]
LIST_PAGE = "https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html"
MONTHS = {m: i + 1 for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split())}


def parse_date(s):
    """'May 19, 2025', 'Jun. 24, 2025', 'Sept. 27, 2017' or '14-Feb-05' -> '2025-05-19'."""
    s = re.sub(r"\s+", " ", (s or "").strip())
    m = re.fullmatch(r"([A-Za-z]{3})[a-z]*\.? ?(\d{1,2}), ?(\d{4})", s)
    if m:
        return f"{m.group(3)}-{MONTHS[m.group(1).lower()]:02d}-{int(m.group(2)):02d}"
    m = re.fullmatch(r"(\d{1,2})-([A-Za-z]{3})-(\d{2})", s)
    if m:
        year = 2000 + int(m.group(3))
        return f"{year}-{MONTHS[m.group(2).lower()]:02d}-{int(m.group(1)):02d}"
    return None


def fix_glyphs(s):
    """Older pages of the PDF encode parentheses as glyph ids: '(cid:7330)' is '(' and '(cid:7331)' is ')'."""
    s = re.sub(r"\(?cid:7330\)?", "(", s or "")
    s = re.sub(r"\(?cid:7331\)?", ")", s)
    return re.sub(r"\(cid:\d+\)", "", s)


def split_brands(cell):
    """Brand lines and applicants. Applicants are the lines in parentheses that end a group; item numbers are dropped."""
    lines = [l.strip() for l in fix_glyphs(cell).split("\n") if l.strip()]
    if lines and re.fullmatch(r"\d{1,3}", lines[0]):                 # older layout: the row number sits in this cell
        lines = lines[1:]
    if lines:
        lines[0] = re.sub(r"^\d{1,3}(?=[A-Z][a-z])", "", lines[0])     # ... or is glued to the first brand ("58Femara")
    joined = []
    for l in lines:                                                   # re-join only obvious wraps: a unit, a quoted maker code, an open parenthesis
        if joined and not l.startswith("(") and re.match(r"^(mg|mL|g/|μg|%|\"|“|\[)", l):
            joined[-1] += " " + l
        elif joined and joined[-1].startswith("(") and not joined[-1].endswith(")"):
            joined[-1] += " " + l
        else:
            joined.append(l)
    items = []
    for l in joined:                                                  # "1) A 2) B" or "1. A 2. B" on one line
        parts = [x.strip() for x in re.split(r"(?:^|\s)(?:\(\d{1,2}\)|\d{1,2}[.)])\s", " " + l) if x.strip()]
        items += parts if len(parts) > 1 or re.match(r"^(?:\(\d{1,2}\)|\d{1,2}[.)])\s", l) else [l]
    is_applicant = lambda l: l.startswith("(") and l.endswith(")") and not re.match(r"\(\d+\)", l)
    applicants = [l[1:-1].strip() for l in items if is_applicant(l)]
    brands = [re.sub(r"^\(\d+\)\s*", "", l) for l in items if not is_applicant(l)]
    return brands, applicants


def undouble(text):
    """Bold text in some pages is extracted twice per letter: 'hhyyddrroocchhlloorriiddee' -> 'hydrochloride'."""
    def fix(w):
        return w[::2] if len(w) >= 6 and len(w) % 2 == 0 and all(w[i] == w[i + 1] for i in range(0, len(w), 2)) else w
    return " ".join(fix(w) for w in text.split(" "))


def clean_ingredient(cell):
    raw = undouble(re.sub(r"\s+", " ", fix_glyphs(cell).replace("\n", " ")).strip())
    raw = re.sub(r"(?<=[A-Za-z0-9])- (?=[A-Za-z0-9])", "-", raw)      # "alfa- 2b", "SARS- CoV-2": a hyphen broken at a line end
    bare = re.sub(r"\[[^\]]*\]", "", raw)                             # "[Infliximab biosimilar 2]"
    bare = bare.replace("（", "(").replace("）", ")")
    bare = re.sub(r"\(+\s*g+e+n+e+t+[^)]*(?:\)+|$)", "", bare, flags=re.I)   # "(genetical recombination)", also cut or doubled
    return raw, re.sub(r"\s+", " ", bare).strip(" ,")


def rows_from_pages(pages):
    """Turn [(page_no, tables), ...] into cleaned approval rows, joining rows split across a page break."""
    rows, last = [], {"date": None, "category": None}
    for page_no, tables in pages:
        first_on_page = True
        for table in tables:
            for cells in table:
                cells = [c if c is None else c.strip() for c in cells]
                if not cells or (cells[0] or "").replace("\n", " ") in ("Review Category", "Category") or "Approval Date" in (cells[1] or "") or "Date of" in (cells[1] or ""):
                    continue
                if len(cells) == 7:
                    category, date_s, _no, brand_cell, kind_cell, ingr_cell, note = cells
                elif len(cells) == 6:
                    category, date_s, brand_cell, kind_cell, ingr_cell, note = cells
                    _no = ""
                else:
                    continue
                date = parse_date(date_s) or (last["date"] if not date_s else None)
                category = (category or last["category"] or "").replace("\n", " ")
                has_row_no = bool((_no or "").strip() or re.match(r"^\d{1,3}(?:\n|$|[A-Z][a-z])", (brand_cell or "").strip()))
                continues = (first_on_page and not has_row_no and not (kind_cell or "").strip() and not date_s
                             and rows and rows[-1]["page"] < page_no)
                if not date or not (ingr_cell or continues):
                    continue
                first_on_page = False
                last = {"date": date, "category": category}
                brands, applicants = split_brands(brand_cell)
                note = (note or "").replace("\n", " ")
                if continues:
                    # a row cut by a page break: its second half starts the new page and continues the previous row's cells
                    # (the ingredient cell may be blank when only the brand or the note wrapped onto the new page)
                    prev = rows[-1]
                    prev["brands"] += [b for b in brands if b not in prev["brands"]]
                    prev["applicants"] += [a for a in applicants if a not in prev["applicants"]]
                    if ingr_cell:
                        prev["ingredient_raw"], prev["ingredient"] = clean_ingredient(prev["ingredient_raw"] + " " + ingr_cell)
                    prev["_note"] = (prev.get("_note", "") + " " + note).strip()
                    prev["new_active_ingredient"] |= bool(re.search(r"new active ingredient", prev["_note"], re.I))
                    prev["orphan"] |= "[Orphan drug]" in prev["_note"]
                    continue
                raw, ingredient = clean_ingredient(ingr_cell)
                rows.append({"date": date, "category": category, "brands": brands, "applicants": applicants,
                             "kinds": sorted({k for k in re.split(r"\s+", (kind_cell or "").replace("Partial", "").replace("Supplemental", "")) if k in ("Approval", "Change")}),
                             "ingredient_raw": raw, "ingredient": ingredient,
                             "new_active_ingredient": bool(re.search(r"new active ingredient", note, re.I)),
                             "orphan": "[Orphan drug]" in note, "page": page_no, "_note": note})
    for r in rows:
        r.pop("_note", None)
    return rows


def main():
    pdf_path = RAW / "japan_approvals.pdf"
    if not pdf_path.exists():
        sys.exit(f"save the PDF from {LIST_PAGE} as {pdf_path} first (PMDA does not permit automated downloads)")
    with pdfplumber.open(str(pdf_path)) as pdf:
        first = re.sub(r"\s+", " ", pdf.pages[0].extract_text() or "")
    m = re.search(r"List of Approved Drugs (April 2004 to \w+ \d{4})", first)
    title_range = m.group(1) if m else "April 2004 onwards"
    pdf_url = PDF_URL
    with pdfplumber.open(str(pdf_path)) as pdf:
        rows = rows_from_pages([(page_no, p.extract_tables()) for page_no, p in enumerate(pdf.pages, 1)])
    out = {"title": f"List of Approved Drugs, {title_range}", "page": LIST_PAGE, "pdf": pdf_url,
           "fetched_on": datetime.date.today().isoformat(), "rows": rows}
    (RAW / "japan_approvals.json").write_text(json.dumps(out, ensure_ascii=False, indent=0))
    print(out["title"], "rows:", len(rows), "new active ingredient rows:", sum(r["new_active_ingredient"] for r in rows))


if __name__ == "__main__":
    main()
