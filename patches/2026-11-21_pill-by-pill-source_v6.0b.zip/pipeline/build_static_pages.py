"""Pipeline step: real pages for search engines, link previews and people without JavaScript.

The site itself is a single page with #/ routes, which search engines treat as one page and which link previews cannot read.
This writes, from the same drug files the site uses:
  medicine/<id>/index.html   one page per medicine: title, description, Open Graph and Twitter tags, schema.org JSON-LD and the
                             main facts with their sources as plain HTML; the site's script then opens the interactive page on top
  medicines/index.html       every medicine, A to Z (a crawlable list of links)
  index.html                 the start page, with the same head tags and a short plain-HTML introduction
  sitemap.xml, robots.txt, feed.xml (Atom: most recent first approvals), manifest.webmanifest, 404.html, _headers (Netlify)
Nothing here states a fact the drug files do not hold; every section keeps its source link.
The public address comes from config/site.json ("base_url"); change it there if the site moves to its own domain.
Usage: python3 pipeline/build_static_pages.py <site dir>
"""
import datetime, html, json, pathlib, re, shutil, sys

SITE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site")
CFG = json.loads((SITE / "config" / "site.json").read_text(encoding="utf-8"))
BASE = CFG["base_url"].rstrip("/")
NAME = "Pill by Pill"
TODAY = datetime.date.today().isoformat()
TYPES = json.loads((SITE / "data" / "how_made.json").read_text(encoding="utf-8"))["types"]
ACTION = {"INHIBITOR": "blocks", "ANTAGONIST": "blocks", "BLOCKER": "blocks", "AGONIST": "switches on", "ACTIVATOR": "switches on",
          "OPENER": "opens", "BINDING AGENT": "sticks to", "MODULATOR": "adjusts", "POSITIVE ALLOSTERIC MODULATOR": "boosts",
          "NEGATIVE ALLOSTERIC MODULATOR": "dials down", "PARTIAL AGONIST": "partly switches on", "INVERSE AGONIST": "turns down"}
e = lambda s: html.escape(str(s if s is not None else ""), quote=True)


def head(title, description, url, extra_ld=None, root=False):
    ld = [{"@context": "https://schema.org", "@type": "WebSite", "name": NAME, "url": BASE + "/",
           "description": "The story of the world's medicines, with a source link for every fact."}] if root else []
    if extra_ld:
        ld.append(extra_ld)
    verify = "".join(f'\n<meta name="{k}" content="{e(CFG[c])}">' for k, c in (("google-site-verification", "google_site_verification"),
                                                                                 ("msvalidate.01", "bing_site_verification")) if CFG.get(c))
    ld_tag = "".join(f'\n<script type="application/ld+json">{json.dumps(x, ensure_ascii=False).replace("</", "<\\/")}</script>' for x in ld)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{'' if root else '<base href="/">'}
<title>{e(title)}</title>
<meta name="description" content="{e(description)}">
<link rel="canonical" href="{e(url)}">
<meta property="og:type" content="{'website' if root else 'article'}">
<meta property="og:site_name" content="{NAME}">
<meta property="og:title" content="{e(title)}">
<meta property="og:description" content="{e(description)}">
<meta property="og:url" content="{e(url)}">
<meta property="og:image" content="{BASE}/img/og-card.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Pill by Pill: the story of the world's medicines">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#1b2440">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="alternate" type="application/atom+xml" title="Pill by Pill: newest approvals" href="/feed.xml">{verify}
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/explore.css">
<link rel="stylesheet" href="css/reference.css">{ld_tag}
</head>
"""


def body(skip_to, inner, app=True):
    script = '\n<script type="module" src="js/app.js"></script>' if app else ""
    return f"""<body data-env="explore">
<a class="skip" href="{skip_to}#main">Skip to content</a>
<div id="app"><div class="shell shell-explore static">
<header class="x-top"><a class="logo" href="/">Pill <span>by</span> Pill</a><a class="door" href="/medicines/">All medicines A to Z</a></header>
<main id="main" tabindex="-1">{inner}</main>
<footer class="foot"><p>Pill by Pill is for learning. It does not give medical advice: ask a doctor or pharmacist about your own medicines.</p>
<p><a href="/#/ref/data">Where the facts come from</a> · <a href="/#/fund">How this site is funded</a> · <a href="/#/privacy">Privacy</a> · <a href="/#/share">Share Pill by Pill</a></p></footer>
</div></div>{script}
</body>
</html>
"""


def plain_mechanism(m):
    verb = ACTION.get(m.get("action") or "")
    target = re.sub(r"\s+(inhibitor|antagonist|blocker|agonist|partial agonist|inverse agonist|activator|opener|modulator|positive allosteric modulator|"
                    r"negative allosteric modulator|binding agent)$", "", m["text"], flags=re.I)
    return f"It {verb} {target}." if verb and target != m["text"] else f"Scientists describe it as: {m['text']}."


def first_dates(d):
    rows = []
    if (d.get("us") or {}).get("first_date"):
        rows.append(("United States", d["us"]["first_date"], "earliest approval in FDA's records", d["us"]["source_url"], "FDA Drugs@FDA"))
    if (d.get("eu") or {}).get("first_authorised"):
        rows.append(("European Union", d["eu"]["first_authorised"], "first authorised through EMA (central procedure)", d["eu"]["source_url"], "EMA"))
    if (d.get("jp") or {}).get("first_new_ingredient"):
        rows.append(("Japan", d["jp"]["first_new_ingredient"], "approved as a new active ingredient", d["jp"]["source_url"], "edited from PMDA's list"))
    if (d.get("ca") or {}).get("first_marketed"):
        rows.append(("Canada", d["ca"]["first_marketed"], "first marketed (not the approval date)", d["ca"]["source_url"], "Health Canada"))
    return sorted(rows, key=lambda r: r[1])


def regions(d):
    out = [p for p, ok in (("the US", d.get("us")), ("the EU", (d.get("eu") or {}).get("authorised_now")), ("Canada", (d.get("ca") or {}).get("marketed_now")),
                           ("Japan", d.get("jp"))) if ok]
    return ", ".join(out[:-1]) + " and " + out[-1] if len(out) > 1 else (out[0] if out else "")


def link_list(items):
    return " · ".join(f'<a href="{e(u)}" rel="noopener">{e(label)}</a>' for label, u in items if str(u).startswith("https://"))


def medicine_page(d, fam, title_case):
    t = TYPES.get(d["type"], TYPES["Unknown"])
    url = f"{BASE}/medicine/{d['id']}/"
    brands = [title_case(b) for b in ((d.get("us") or {}).get("brands") or (d.get("names") or {}).get("trade") or [])][:3]
    mech = plain_mechanism(d["mechanisms"][0]) if d["mechanisms"] else ""
    kind = t["simple_name"].lower() if t["simple_name"] != "Other" else "medicine"
    desc = f"{d['name']}: {('a ' if not re.match('[aeiou]', kind) else 'an ') + kind}{', first approved ' + str(d['first_year']) if d.get('first_year') else ''}. " \
           f"{mech} {'Records in ' + regions(d) + '. ' if regions(d) else ''}Every fact with its source."
    desc = (desc[:157] + "…") if len(desc) > 158 else desc
    title = f"{d['name']}: how it works and where it came from | {NAME}"
    sections = []
    facts = [("First approved", f"{d['first_year']} (earliest year in these records)" if d.get("first_year") else "not recorded"),
             ("Records in", regions(d) or "none of the four regulators' lists"), ("Type", t["simple_name"])]
    if d.get("who_eml"):
        facts.append(("WHO essential medicine", "Yes" if d["who_eml"]["listed_alone"] else "As part of a combination"))
    dl = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in facts)
    if d["mechanisms"]:
        refs = [(f"{r['type']} via ChEMBL", r["url"]) for m in d["mechanisms"][:1] for r in m.get("refs", [])]
        sections.append(f"<section><h2>How it works</h2>{''.join(f'<p>{e(plain_mechanism(m))}</p>' for m in d['mechanisms'][:2])}"
                        f"<p class=\"src\">Source: {link_list(refs or [(d['sources'][0]['label'], d['sources'][0]['url'])])}</p></section>")
    if d.get("indications"):
        refs = [(f"{r['type']} via ChEMBL", r["url"]) for r in d["indications"][0].get("refs", [])]
        sections.append(f"<section><h2>What it is used for</h2><p>Doctors' words for what it treats:</p><ul class=\"tags\">"
                        f"{''.join(f'<li>{e(i['term'])}</li>' for i in d['indications'][:6])}</ul><p class=\"src\">Source: {link_list(refs)}</p></section>")
    if d.get("origin"):
        o = d["origin"]
        sections.append(f"<section><h2>Where it comes from</h2><p>{e(o['simple'])}</p><p class=\"src\">Source: {link_list([(s['label'], s['url']) for s in o['sources']])}</p></section>")
    dates = first_dates(d)
    if dates:
        sections.append("<section><h2>Around the world</h2><ul>" + "".join(
            f"<li><b>{e(p)}</b>: {e(dt)} ({e(kind_)}) · <a href=\"{e(u)}\" rel=\"noopener\">{e(src)}</a></li>" for p, dt, kind_, u, src in dates) +
            "</ul><p class=\"muted\">Each date comes from that place's own records, and they count different things.</p></section>")
    if d.get("who_eml"):
        w = d["who_eml"]
        sections.append(f"<section><h2>WHO Essential Medicines List</h2><p>{e(d['name'])} is on WHO's list of essential medicines"
                        f"{'' if w['listed_alone'] else ' as part of a combination'}. <a href=\"{e(w['entries'][0]['url'])}\" rel=\"noopener\">WHO's entry</a>.</p>"
                        f"<p class=\"src\">{e(w['attribution'])}</p></section>")
    if fam:
        others = [m for m in fam["members"] if m["id"] != d["id"]][:12]
        sections.append(f"<section><h2>Its family</h2><p>Medicines with the same name stem ({e(fam['stem'])}) and the same target ({e(fam['target_name'])}), "
                        f"in order of first approval:</p><ul>" + "".join(f'<li><a href="/medicine/{e(m["id"])}/">{e(m["name"])}</a> ({m["year"]})</li>' for m in others) +
                        "</ul><p class=\"src\">Stems and targets from ChEMBL.</p></section>")
    sources = link_list([(s["label"], s["url"]) for s in d["sources"][:8]])
    inner = f"""<article class="page level-page static-page">
<nav class="crumbs" aria-label="You are here"><ol><li><a href="/">Start</a></li><li><a href="/medicines/">Medicines</a></li><li><span aria-current="page">{e(d['name'])}</span></li></ol></nav>
<header class="page-head"><p class="kicker">{e(t['icon'])} {e(t['simple_name'])}</p><h1>{e(d['name'])}</h1>
{f'<p class="lede">Also sold as {e(", ".join(brands))}.</p>' if brands else ''}<dl class="facts">{dl}</dl></header>
<div class="page-body">{''.join(sections)}
<p class="careful">For learning, not medical advice. Ask a doctor or pharmacist about your own medicines.</p>
<p class="src">Sources: {sources}</p>
<p><a class="btn" href="/#/explore/medicine/{e(d['id'])}">Open the interactive page</a> <a class="btn" href="/#/ref/drug/{e(d['id'])}">In-depth record</a></p></div>
</article>"""
    ld = {"@context": "https://schema.org", "@type": "MedicalWebPage", "name": title, "url": url, "description": desc, "dateModified": TODAY,
          "isPartOf": {"@type": "WebSite", "name": NAME, "url": BASE + "/"},
          "about": {"@type": "Drug", "name": d["name"], **({"alternateName": brands} if brands else {}),
                    "sameAs": [s["url"] for s in d["sources"][:1] if "ebi.ac.uk/chembl" in s["url"]]},
          "breadcrumb": {"@type": "BreadcrumbList", "itemListElement": [
              {"@type": "ListItem", "position": 1, "name": "Start", "item": BASE + "/"},
              {"@type": "ListItem", "position": 2, "name": "Medicines", "item": BASE + "/medicines/"},
              {"@type": "ListItem", "position": 3, "name": d["name"], "item": url}]}}
    return head(title, desc, url, ld) + body(f"/medicine/{d['id']}/", inner)


def main():
    drugs = sorted((json.loads(f.read_text(encoding="utf-8")) for f in (SITE / "data" / "drugs").glob("*.json")), key=lambda d: d["name"].lower())
    fams = json.loads((SITE / "data" / "family_trees.json").read_text(encoding="utf-8"))
    fam_of = {m["id"]: f for f in fams["families"] for m in f["members"]}
    stats = json.loads((SITE / "data" / "catalogue_stats.json").read_text(encoding="utf-8"))
    title_case = lambda b: " ".join(w if any(c.isdigit() for c in w) else w[:1].upper() + w[1:].lower() for w in b.split())
    out = SITE / "medicine"
    if out.exists():
        shutil.rmtree(out)                              # a medicine removed from the catalogue loses its page too
    for d in drugs:
        p = out / d["id"]
        p.mkdir(parents=True)
        (p / "index.html").write_text(medicine_page(d, fam_of.get(d["id"]), title_case), encoding="utf-8")
    # A to Z
    groups = {}
    for d in drugs:
        k = d["name"][0].upper() if d["name"][0].isalpha() else "#"
        groups.setdefault(k, []).append(d)
    nav = " ".join(f'<a href="/medicines/#letter-{k}">{k}</a>' for k in groups)
    lists = "".join(f'<section><h2 id="letter-{k}">{k}</h2><ul class="az">' + "".join(f'<li><a href="/medicine/{e(d["id"])}/">{e(d["name"])}</a></li>' for d in v) +
                    "</ul></section>" for k, v in groups.items())
    inner = f"""<article class="page level-page static-page"><header class="page-head"><h1>All medicines, A to Z</h1>
<p class="lede">{len(drugs):,} medicines. Each page shows what it is, how it works, where it came from and where it is approved, with sources.</p></header>
<div class="page-body"><p class="az-nav">{nav}</p>{lists}</div></article>"""
    (SITE / "medicines").mkdir(exist_ok=True)
    (SITE / "medicines" / "index.html").write_text(head(f"All medicines, A to Z | {NAME}", f"All {len(drugs):,} medicines in Pill by Pill, A to Z, each with its sources.",
                                                        BASE + "/medicines/") + body("/medicines/", inner), encoding="utf-8")
    # start page
    intro = f"""<article class="page level-home static-page"><header class="page-head"><h1>The story of the world's medicines</h1>
<p class="lede">{stats['total']:,} approved medicines: what each one is, how it works, where it came from and where it is approved, with a source link for every fact.
A Simple side for students and an In-depth side for professionals. No adverts, no tracking.</p></header>
<div class="page-body"><p><a class="btn" href="/#/explore">Simple</a> <a class="btn" href="/#/ref">In-depth</a> <a class="btn" href="/medicines/">All medicines A to Z</a></p></div></article>"""
    (SITE / "index.html").write_text(head(f"{NAME}: the story of the world's medicines",
                                          "Every approved medicine with its molecule, its story and its sources. A simple side for students and an in-depth side for experts.",
                                          BASE + "/", root=True) + body("/", intro), encoding="utf-8")
    # 404
    inner404 = """<article class="page level-page static-page"><header class="page-head"><h1>We couldn't find that page</h1>
<p class="lede">The link may be old, or the medicine may have been renamed.</p></header>
<div class="page-body"><p><a class="btn" href="/">Go to the start</a> <a class="btn" href="/medicines/">All medicines A to Z</a></p></div></article>"""
    (SITE / "404.html").write_text(head(f"Page not found | {NAME}", "This page does not exist.", BASE + "/404.html").replace(
        '<meta name="description"', '<meta name="robots" content="noindex">\n<meta name="description"') + body("/404.html", inner404, app=False), encoding="utf-8")
    # sitemap, robots, feed, manifest, headers
    urls = [BASE + "/", BASE + "/medicines/"] + [f"{BASE}/medicine/{d['id']}/" for d in drugs]
    (SITE / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
                                      "".join(f"<url><loc>{e(u)}</loc><lastmod>{TODAY}</lastmod></url>\n" for u in urls) + "</urlset>\n", encoding="utf-8")
    (SITE / "robots.txt").write_text(f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n", encoding="utf-8")
    dated = []
    for d in drugs:
        dates = [r for r in first_dates(d) if r[0] != "Canada"]             # Canada's date is a first sale, not an approval
        if dates:
            dated.append((dates[0][1], dates[0][0], d))
    dated.sort(key=lambda x: x[0], reverse=True)
    entries = "".join(f"""<entry><title>{e(d['name'])}: first approved {e(day)} ({e(place)})</title><link href="{BASE}/medicine/{e(d['id'])}/"/>
<id>{BASE}/medicine/{e(d['id'])}/</id><updated>{day}T00:00:00Z</updated>
<summary>{e((d['mechanisms'][0]['text'] + '. ') if d['mechanisms'] else '')}{e(TYPES.get(d['type'], TYPES['Unknown'])['simple_name'])}. Earliest approval in these records: {e(day)}, {e(place)}.</summary></entry>
""" for day, place, d in dated[:40])
    (SITE / "feed.xml").write_text(f"""<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom"><title>Pill by Pill: newest approvals</title><subtitle>Medicines with the most recent first approval in the US, EU or Japan records this site uses. Updated when the site is rebuilt.</subtitle>
<link href="{BASE}/feed.xml" rel="self"/><link href="{BASE}/"/><id>{BASE}/feed.xml</id><updated>{TODAY}T00:00:00Z</updated><author><name>{NAME}</name></author>
{entries}</feed>
""", encoding="utf-8")
    (SITE / "manifest.webmanifest").write_text(json.dumps({"name": f"{NAME}: the story of the world's medicines", "short_name": NAME, "start_url": "/",
                                                           "display": "browser", "background_color": "#f6f7fb", "theme_color": "#1b2440",
                                                           "icons": [{"src": "/img/icon-192.png", "sizes": "192x192", "type": "image/png"},
                                                                     {"src": "/img/icon-512.png", "sizes": "512x512", "type": "image/png"}]}, indent=1), encoding="utf-8")
    (SITE / "_headers").write_text("""/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()
/data/*
  Cache-Control: public, max-age=3600
/mol/*
  Cache-Control: public, max-age=86400
/bind/*
  Cache-Control: public, max-age=86400
/img/*
  Cache-Control: public, max-age=86400
/fonts/*
  Cache-Control: public, max-age=31536000, immutable
""", encoding="utf-8")
    print("static pages:", len(drugs), "medicines + start, A to Z, 404; sitemap", len(urls), "URLs; feed", min(40, len(dated)), "entries; base", BASE)


if __name__ == "__main__":
    main()
