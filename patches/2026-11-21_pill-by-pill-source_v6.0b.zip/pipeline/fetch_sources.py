"""Step 1 of the data pipeline: download raw source data into raw/.

Sources (all public, no key needed):
  ChEMBL web services  https://www.ebi.ac.uk/chembl/api/data/   approved drugs worldwide (max_phase = 4),
                       mechanisms, indications, safety warnings, ATC classes
  openFDA Drugs@FDA    https://download.open.fda.gov/drug/drugsfda/  every US application
Usage: python3 pipeline/fetch_sources.py [raw_dir]
"""
import json, sys, time, pathlib, urllib.request, urllib.parse, zipfile, io, datetime

RAW = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "raw")
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data/"
FDA_ZIP = "https://download.open.fda.gov/drug/drugsfda/drug-drugsfda-0001-of-0001.json.zip"


def get(url, tries=5):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "pill-by-pill-build/5.0 (educational site)"})
            with urllib.request.urlopen(req, timeout=180) as r:
                return r.read()
        except Exception as e:  # network hiccup: back off and retry
            print("  retry", i + 1, url[:90], e, flush=True)
            time.sleep(3 * (i + 1))
    raise RuntimeError("failed: " + url)


def chembl_all(resource, key, **params):
    """Page through one ChEMBL resource and return every record."""
    out, offset = [], 0
    while True:
        q = urllib.parse.urlencode({**params, "limit": 1000, "offset": offset, "format": "json"})
        page = json.loads(get(f"{CHEMBL}{resource}?{q}"))
        out += page[key]
        total = page["page_meta"]["total_count"]
        print(f"  {resource}: {len(out)}/{total}", flush=True)
        if len(out) >= total or not page[key]:
            return out
        offset += 1000


def main():
    RAW.mkdir(exist_ok=True)
    meta = {"fetched_on": datetime.date.today().isoformat()}
    status = json.loads(get(CHEMBL + "status?format=json"))
    meta["chembl_release"] = status.get("chembl_db_version")
    jobs = [
        ("molecules", "molecule", "molecules", {"max_phase": 4}),
        ("mechanisms", "mechanism", "mechanisms", {}),
        ("indications", "drug_indication", "drug_indications", {"max_phase_for_ind": 4}),
        ("warnings", "drug_warning", "drug_warnings", {}),
        ("atc", "atc_class", "atc", {}),
    ]
    for name, resource, key, params in jobs:
        f = RAW / f"chembl_{name}.json"
        if f.exists():
            continue
        f.write_text(json.dumps(chembl_all(resource, key, **params)))
    f = RAW / "drugsfda.json"
    if not f.exists():
        z = zipfile.ZipFile(io.BytesIO(get(FDA_ZIP)))
        data = json.loads(z.read(z.namelist()[0]))
        meta["drugsfda_last_updated"] = data["meta"].get("last_updated")
        f.write_text(json.dumps(data["results"]))
    (RAW / "meta.json").write_text(json.dumps(meta, indent=1))
    print(meta)


if __name__ == "__main__":
    main()
