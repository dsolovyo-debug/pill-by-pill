"""One-off migration step: pull the curated data arrays out of the v4.0.3 single-file site into JSON.

v4.0.3 kept its curated data as JavaScript constants inside index.html. This loads that page in headless
Chromium and dumps each constant to raw/legacy/<NAME>.json so v5.0 can keep them as plain data files.
Usage: python3 pipeline/extract_legacy.py <v4.0.3 folder> <out dir>
"""
import asyncio, json, pathlib, re, sys
from playwright.async_api import async_playwright


async def main(folder, out):
    out = pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
    html = pathlib.Path(folder, "index.html").read_text(encoding="utf-8")
    names = sorted(set(re.findall(r"\b(?:const|let|var)\s+([A-Z][A-Z0-9_]{3,})\s*=\s*[\[\{]", html)))
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        await pg.goto(pathlib.Path(folder, "index.html").resolve().as_uri())
        await pg.wait_for_timeout(800)
        for n in names + ["ALL_DRUGS"]:
            try:
                v = await pg.evaluate(f"JSON.stringify({n})")
            except Exception:
                continue
            if v:
                (out / f"{n}.json").write_text(v, encoding="utf-8")
        await b.close()


asyncio.run(main(sys.argv[1], sys.argv[2]))
