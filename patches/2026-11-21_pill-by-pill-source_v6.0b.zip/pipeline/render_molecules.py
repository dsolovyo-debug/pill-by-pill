"""Step 4 of the data pipeline: lay out every structure for drawing.

For each medicine with a SMILES string (from ChEMBL, or PubChem for a few FDA-only names) writes <site>/mol/<id>.json:
  d2   2D layout computed by RDKit (kekulised, stereo wedges assigned): atoms [x, y, element, charge, hydrogens],
       bonds [from, to, order, wedge]  (wedge: 1 solid, 2 hashed, starting at "from")
  d3   3D model: RDKit ETKDGv3 embedding + MMFF94 clean-up, hydrogens included: atoms [element, x, y, z], bonds [from, to, order].
       This is a computed shape, not a crystal structure.
The browser draws both from this file (js/molecule.js), so one drug costs a few KB instead of a 25 KB SVG.
3D is skipped above MAX_3D_ATOMS heavy atoms or when embedding fails within the time limit.
Adds a "graphics" block to each drug file saying what was produced. Nothing is drawn without a sourced SMILES.
Usage: python3 pipeline/render_molecules.py <data dir> <site dir>
"""
import json, multiprocessing, pathlib, signal, sys

from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdDepictor

MAX_2D_ATOMS, MAX_3D_ATOMS, TIME_LIMIT_S = 400, 110, 25
RDLogger.DisableLog("rdApp.*")


class Timeout(Exception):
    pass


def _alarm(*_):
    raise Timeout()


def layout_2d(mol):
    m = Chem.Mol(mol)
    Chem.Kekulize(m, clearAromaticFlags=True)
    rdDepictor.Compute2DCoords(m)
    rdDepictor.StraightenDepiction(m)
    Chem.WedgeMolBonds(m, m.GetConformer())
    conf = m.GetConformer()
    atoms = []
    for a in m.GetAtoms():
        p = conf.GetAtomPosition(a.GetIdx())
        atoms.append([round(p.x, 2), round(p.y, 2), a.GetSymbol(), a.GetFormalCharge(), a.GetTotalNumHs()])
    wedge = {Chem.BondDir.BEGINWEDGE: 1, Chem.BondDir.BEGINDASH: 2}
    order = {Chem.BondType.SINGLE: 1, Chem.BondType.DOUBLE: 2, Chem.BondType.TRIPLE: 3}
    bonds = [[b.GetBeginAtomIdx(), b.GetEndAtomIdx(), order.get(b.GetBondType(), 1), wedge.get(b.GetBondDir(), 0)] for b in m.GetBonds()]
    return {"atoms": atoms, "bonds": bonds}


def model_3d(mol):
    m = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = 42
    if AllChem.EmbedMolecule(m, params) != 0:
        return None
    try:
        AllChem.MMFFOptimizeMolecule(m, maxIters=300)
    except Exception:
        pass
    Chem.Kekulize(m, clearAromaticFlags=True)
    conf = m.GetConformer()
    order = {Chem.BondType.SINGLE: 1, Chem.BondType.DOUBLE: 2, Chem.BondType.TRIPLE: 3}
    atoms = []
    for a in m.GetAtoms():
        p = conf.GetAtomPosition(a.GetIdx())
        atoms.append([a.GetSymbol(), round(p.x, 3), round(p.y, 3), round(p.z, 3)])
    return {"atoms": atoms, "bonds": [[b.GetBeginAtomIdx(), b.GetEndAtomIdx(), order.get(b.GetBondType(), 1)] for b in m.GetBonds()]}


def work(job):
    drug_id, smiles = job
    result = {"id": drug_id, "layout": None, "mol3d": None, "note": None}
    signal.signal(signal.SIGALRM, _alarm)
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            result["note"] = "RDKit could not read the SMILES"
            return result
        n = mol.GetNumHeavyAtoms()
        result["heavy_atoms"] = n
        if n <= MAX_2D_ATOMS:
            signal.alarm(TIME_LIMIT_S)
            result["layout"] = layout_2d(mol)
            signal.alarm(0)
        if n <= MAX_3D_ATOMS and n > 1:
            signal.alarm(TIME_LIMIT_S)
            result["mol3d"] = model_3d(mol)
            signal.alarm(0)
    except Timeout:
        result["note"] = "3D embedding timed out" if result["layout"] else "drawing timed out"
    except Exception as e:  # keep going: one odd structure must not stop the build
        result["note"] = f"{type(e).__name__}"
    finally:
        signal.alarm(0)
    return result


def main():
    data, site = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    (site / "mol").mkdir(exist_ok=True)
    for old in (site / "mol").iterdir():
        old.unlink()
    files = {f.stem: f for f in (data / "drugs").glob("*.json")}
    docs = {k: json.loads(f.read_text()) for k, f in files.items()}
    jobs = [(k, d["structure"]["smiles"]) for k, d in docs.items() if d.get("structure")]
    counts = {"structures": len(jobs), "drawing": 0, "mol3d": 0, "failed": []}
    with multiprocessing.Pool(4) as pool:
        for r in pool.imap_unordered(work, jobs, chunksize=8):
            if r["layout"]:
                (site / "mol" / f"{r['id']}.json").write_text(json.dumps({"d2": r["layout"], "d3": r["mol3d"]}, separators=(",", ":")))
                counts["drawing"] += 1; counts["mol3d"] += bool(r["mol3d"])
            if not r["layout"]:
                counts["failed"].append([r["id"], r["note"] or "too large to draw"])
            docs[r["id"]]["graphics"] = {
                "drawing": bool(r["layout"]), "model3d": bool(r["mol3d"]), "heavy_atoms": r.get("heavy_atoms"), "note": r["note"],
                "layout_by": "RDKit", "model3d_method": "Computed 3D shape (RDKit ETKDGv3 + MMFF94), not an experimental structure"}
    for k, d in docs.items():
        d.setdefault("graphics", {"drawing": False, "model3d": False})
        files[k].write_text(json.dumps(d, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    stats_file = data / "catalogue_stats.json"
    stats = json.loads(stats_file.read_text())
    stats["graphics"] = {"drawing": counts["drawing"], "model3d": counts["mol3d"], "not_drawn": counts["failed"]}
    stats_file.write_text(json.dumps(stats, indent=1))
    print({k: (v if k != "failed" else v[:10]) for k, v in counts.items()})


if __name__ == "__main__":
    main()
