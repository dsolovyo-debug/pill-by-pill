"""Name handling shared by the catalogue build and its tests: salt words, WHO name stems, Japanese name cleaning.
Pure functions only (no files, no network), so tests/test_pipeline.py can check them directly."""
import re

SALT_WORDS = ("HYDROCHLORIDE DIHYDROCHLORIDE HYDROBROMIDE SODIUM POTASSIUM CALCIUM MAGNESIUM SULFATE PHOSPHATE ACETATE "
              "MALEATE FUMARATE TARTRATE BITARTRATE CITRATE MESYLATE BESYLATE TOSYLATE SUCCINATE NITRATE CHLORIDE BROMIDE "
              "ANHYDROUS MONOHYDRATE DIHYDRATE HEMIHYDRATE TRIHYDRATE DISODIUM DIPOTASSIUM LACTATE GLUCONATE PAMOATE "
              "HEMIFUMARATE MEGLUMINE TROMETHAMINE HYDRATE DIMESYLATE HEMISULFATE OXALATE BENZOATE USP "
              "MESILATE DIMESILATE BESILATE CAMSILATE TOSILATE DITOSILATE SULPHATE HEMISULPHATE TROMETAMOL EMBONATE "
              "XINAFOATE SESQUIHYDRATE PENTAHYDRATE TETRAHYDRATE "
              "HEXAHYDRATE HEPTAHYDRATE OCTAHYDRATE DECAHYDRATE HEMIPENTAHYDRATE TRIFLUOROACETATE "
              "MONOSODIUM TRISODIUM MONOPOTASSIUM").split()        # esters (valerate, propionate, furoate, acetonide) are different medicines, not salts


ADC_PAYLOADS = ("vedotin", "deruxtecan", "emtansine", "ozogamicin", "govitecan", "mafodotin", "ravtansine", "tesirine", "soravtansine")


INN_STEMS = (                                   # WHO INN stems (Stem Book 2024): stem, type
    ("mab", "Antibody"), ("cel", "Cell"), ("vec", "Gene"), ("rsen", "Oligonucleotide"), ("siran", "Oligonucleotide"), ("meran", "Oligonucleotide"),
    ("plase", "Enzyme"), ("ase", "Enzyme"),
    ("cept", "Protein"), ("cog", "Protein"), ("ermin", "Protein"), ("kinra", "Protein"), ("poetin", "Protein"), ("grastim", "Protein"),
    ("gramostim", "Protein"), ("relix", "Protein"), ("pressin", "Protein"), ("tocin", "Protein"), ("feron", "Protein"),
    ("fusp", "Protein"), ("tide", "Protein"))


NOT_STEM = {"defibrotide"}                      # ends in -tide but is a mixture of oligonucleotides, not a peptide
# -relin is left out: anamorelin carries it but is not a peptide. Stems are only read from short, INN-like names (at most three
# words, e.g. "lisocabtagene maraleucel"); a descriptive name such as "... thymidine kinase gene" is not an INN and stays Unknown.


# v5.18: ATC groups in which every substance is the same kind of medicine (WHO ATC/DDD index, checked 2026-11-19).
# These are read before the INN stems: a radiolabelled peptide ("... oxodotreotide") is typed by what makes it radioactive.
ATC_GROUP_TYPES = (("V09", "Radiopharmaceutical", "diagnostic radiopharmaceuticals"),
                   ("V10", "Radiopharmaceutical", "therapeutic radiopharmaceuticals"),
                   ("V01", "Allergen extract", "allergens"))
# Single ATC codes whose substance is a protein or an enzyme, read only after the INN stems. Listed code by code because the
# groups around them are mixed: B02BD15-18 (e.g. etranacogene dezaparvovec) and A16AB21/26/29 are gene or cell therapies, and
# B05AA03-07 are fluorocarbons, dextran, gelatin and starch. A code not listed here (including a new one) leaves the type Unknown.
ATC_PROTEIN_CODES = {
    **{f"B02BD{n:02d}": ("Protein", "blood coagulation factors") for n in (1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 14, 30)},
    **{f"B05AA{n:02d}": ("Protein", "albumin, plasma protein fractions and haemoglobin products") for n in (1, 2, 8, 9, 10)},
    **{f"A16AB{n:02d}": ("Enzyme", "enzymes for metabolic disorders") for n in (*range(1, 21), 22, 23, 24, 25, 27, 28)},
}


def classify_ema_type(clean, product):
    """Type of a substance listed only by EMA, with the basis for it. Only EMA's ATC code, the named attached drug of an
    antibody-drug conjugate, and WHO INN stems are used; anything else stays "Unknown" rather than being guessed."""
    low, atc = clean.lower(), (product.get("atc") or "").upper()
    if atc.startswith("J07"):
        return "Vaccine component", "EMA ATC code " + atc
    if "vaccine" in low:
        return "Vaccine component", "the word 'vaccine' in EMA's substance name"
    if atc.startswith("J06B") or "immunoglobulin" in low:
        return "Antibody", ("EMA ATC code " + atc) if atc.startswith("J06B") else "the word 'immunoglobulin' in EMA's substance name"
    for prefix, kind, group in ATC_GROUP_TYPES:
        if atc.startswith(prefix):
            return kind, f"EMA ATC code {atc} ({group})"
    for word in ADC_PAYLOADS:                    # two-word INN: "<antibody>mab <payload>", e.g. "brentuximab vedotin"
        if re.search(r"\b" + word + r"\b", low) and re.search(r"\b\w+mab\b", low):
            return "Antibody drug conjugate", f"the word '{word}' in EMA's substance name (the drug attached to the antibody)"
    words = low.split()
    if 1 <= len(words) <= 3:
        for stem, kind in INN_STEMS:
            if any(re.fullmatch(r"[a-z]+", w) and w not in NOT_STEM and len(w) > len(stem) + 2 and w.endswith(stem) for w in words):
                return kind, f"WHO INN stem -{stem}"
    if atc in ATC_PROTEIN_CODES:
        kind, group = ATC_PROTEIN_CODES[atc]
        return kind, f"EMA ATC code {atc} ({group})"
    return "Unknown", None


ELEMENTS = set("ZINC MAGNESIUM CALCIUM SODIUM POTASSIUM IRON FERROUS FERRIC COPPER CUPRIC MANGANESE CHROMIUM CHROMIC SELENIUM ALUMINUM ALUMINIUM "
               "LITHIUM BARIUM BISMUTH SILVER STRONTIUM COBALT GOLD AMMONIUM MOLYBDENUM GALLIUM".split())


def normalise_fda_name(name):
    """Return candidate lookup keys for a Drugs@FDA or EMA ingredient string, most specific first."""
    n = re.sub(r"\s+", " ", name.upper().strip(" ,)("))
    out = [n]
    n2 = re.sub(r"-[A-Z]{4}$", "", n)             # biosimilar suffix, e.g. DENOSUMAB-BMWO
    n2 = re.sub(r",? USP$", "", n2)
    n2 = re.sub(r",\s*(?=(?:\w*HYDRATE|ANHYDROUS)\b)", " ", n2)   # EMA: "DANTROLENE SODIUM, HEMIHEPTAHYDRATE"
    out.append(n2)
    words = n2.split()
    while len(words) > 1 and (words[-1] in SALT_WORDS or words[-1].endswith("HYDRATE")):
        words = words[:-1]
        if len(words) == 1 and words[0] in ELEMENTS:     # "ZINC GLUCONATE" must not become "ZINC" (that would match any zinc salt)
            break
        out.append(" ".join(words))
    return out


JP_FORM_WORDS = set("tablets tablet tab capsules capsule cap injection inj for subcutaneous intravenous i.v intramuscular infusion ophthalmic solution oral "
                    "granules fine cream ointment patch syringe syringes kit suspension powder inhalation nasal spray tape lotion gel drops dry syrup pen "
                    "combination intravitreal transdermal od extended enteric s.c iv sc liquid emulsion vial bag pfs".split())


JP_COUNTER_IONS = re.compile(r"\s+(?:L-\s?ARGININE|L-\s?PROLINE|L-\s?LYSINE|ETHANOLATE|CITRIC ACID|FUMARIC ACID|HYDRATE|BESILATE|TOSILATE|MESILATE)$")


NOT_A_SINGLE_MEDICINE = re.compile(r"vaccine|virus|virion|extract|immunoglobulin|concentrat|polysaccharide|antigen|mrna|toxoid|strain|milk|juice|starch|"
                                   r"talc|hyaluronate|\(\d+[a-z]+\)|n/a", re.I)


def jp_clean(text):
    n = re.sub(r"\balpha\b", "alfa", text.strip(" ,"), flags=re.I).upper()
    while JP_COUNTER_IONS.search(n):
        n = JP_COUNTER_IONS.sub("", n)
    return n


def near(a, b):
    """True if the two names differ by at most one letter (insert, delete or change)."""
    if abs(len(a) - len(b)) > 1:
        return False
    i = 0
    while i < min(len(a), len(b)) and a[i] == b[i]:
        i += 1
    return a[i + 1:] == b[i + 1:] or a[i:] == b[i + 1:] or a[i + 1:] == b[i:]
