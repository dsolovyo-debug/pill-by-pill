"""Pipeline step: for a small-molecule medicine with no deposited structure in its own target, look for one in the same
protein of another species, and say so.

fetch_binding.py only accepts an entry that contains the medicine AND its ChEMBL target (same UniProt accession). Many
medicines have instead been crystallised in the rat, mouse or bacterial version of that protein. This step accepts an entry when:
  1. it contains the medicine itself (PDB chemical component with the same InChIKey, as in fetch_binding.py), and
  2. every protein in the entry that PDBe maps to UniProt carries the same gene name as the ChEMBL target
     (gene symbols from ChEMBL's target components, compared without regard to case), and
  3. none of those proteins is the ChEMBL target itself (those cases belong to fetch_binding.py).
Gene symbols that name several different protein families are skipped (AMBIGUOUS: "bla" covers TEM, SHV, KPC and other
beta-lactamases). If the protein in the entry is an engineered fusion, every source organism PDBe lists is shown.
Only this "same gene, other organism or strain" relation is used. A different member of the same protein family is NOT accepted,
because a family member's pocket can differ where it matters.
The result is stored with kind "related" and a "related" block (species, protein name, accession, gene) so the site can
label the animation as not being the medicine's own target. Contacts are measured exactly as in fetch_binding.py.
Usage: python3 pipeline/fetch_binding_related.py <raw dir> <site dir>
"""
import datetime, json, pathlib, sys, urllib.parse

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from fetch_binding import RAW, SITE, SEARCH, get, binding_site       # noqa: E402

CHEMBL = "https://www.ebi.ac.uk/chembl/api/data/target.json?"
AMBIGUOUS = {"bla"}


def gene_symbols(target_ids):
    """{target id: sorted gene symbols} from ChEMBL target components; cached in raw/chembl_target_genes.json."""
    cache_file = RAW / "chembl_target_genes.json"
    cache = json.loads(cache_file.read_text()) if cache_file.exists() else {}
    todo = sorted(set(target_ids) - set(cache))
    for i in range(0, len(todo), 40):
        res = get(CHEMBL + urllib.parse.urlencode({"target_chembl_id__in": ",".join(todo[i:i + 40]), "limit": 100})) or {}
        for t in res.get("targets", []):
            cache[t["target_chembl_id"]] = sorted({s["component_synonym"] for c in t.get("target_components") or []
                                                   for s in c.get("target_component_synonyms") or [] if s.get("syn_type") == "GENE_SYMBOL"})
        for tid in todo[i:i + 40]:
            cache.setdefault(tid, [])
        cache_file.write_text(json.dumps(cache))
    return cache


def solr(query, fields, rows, group=False):
    params = {"q": query, "fl": fields, "sort": "resolution asc", "rows": rows, "wt": "json"}
    if group:
        params.update({"group": "true", "group.field": "pdb_id"})
    res = get(SEARCH + urllib.parse.urlencode(params)) or {}
    if group:
        return [g["doclist"]["docs"][0] for g in res.get("grouped", {}).get("pdb_id", {}).get("groups", [])]
    return res.get("response", {}).get("docs", [])


def main():
    ligands = json.loads((RAW / "pdb_ligand_by_inchikey.json").read_text())
    targets = {t["id"]: t for t in json.loads((RAW / "chembl_targets.json").read_text())}
    summary = json.loads((RAW / "binding.json").read_text())
    (RAW / "pdb").mkdir(exist_ok=True)
    todo = []
    for f in sorted((SITE / "data" / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        if d.get("structure") and d["mechanisms"] and not summary.get(d["id"]) and d["structure"]["inchikey"] in ligands:
            todo.append(d)
    genes = gene_symbols([m["target_chembl_id"] for d in todo for m in d["mechanisms"] if m.get("target_chembl_id") in targets])
    found = 0
    for d in todo:
        codes = sorted(set(ligands[d["structure"]["inchikey"]]))[:6]
        result = None
        for m in d["mechanisms"]:
            t = targets.get(m["target_chembl_id"])
            symbols = genes.get(m["target_chembl_id"]) or []
            if not t or not t["accessions"] or not symbols or t["type"] != "SINGLE PROTEIN":
                continue
            wanted = {s.lower() for s in symbols} - AMBIGUOUS
            symbols = [s for s in symbols if s.lower() in wanted]
            if not symbols:
                continue
            variants = sorted({v for s in symbols for v in (s, s.upper(), s.lower(), s.capitalize(), s[:1].lower() + s[1:])})
            hits = solr(f"compound_id:({' OR '.join(codes)}) AND gene_name:({' OR '.join(variants)})", "pdb_id,resolution,experimental_method,title,compound_id", 6, group=True)
            for doc in hits:
                if not doc.get("resolution") or doc["resolution"] > 3.5:
                    continue
                entities = [e for e in solr(f"pdb_id:{doc['pdb_id']}", "molecule_name,gene_name,uniprot_accession,organism_scientific_name", 60) if e.get("uniprot_accession")]
                if not entities or any(set(e["uniprot_accession"]) & set(t["accessions"]) for e in entities):
                    continue
                if not all({g.lower() for g in e.get("gene_name") or []} & wanted for e in entities):
                    continue
                e = entities[0]
                organisms = list(dict.fromkeys(e.get("organism_scientific_name") or []))
                if not organisms or organisms == [t["organism"]]:
                    continue
                organism = " and ".join(organisms)
                code = next((c for c in doc.get("compound_id", []) if c in codes), codes[0])
                blob = get(f"https://files.rcsb.org/download/{doc['pdb_id'].upper()}.cif", binary=True)
                if not blob:
                    continue
                path = RAW / "pdb" / f"{doc['pdb_id']}.cif"
                path.write_bytes(blob)
                try:
                    site = binding_site(path, code)
                except Exception:
                    site = None
                path.unlink(missing_ok=True)
                if not site:
                    continue
                gene = next(g for g in e["gene_name"] if g.lower() in wanted)
                (SITE / "bind" / f"{d['id']}.json").write_text(json.dumps(site, separators=(",", ":")))
                kinds = [c[3] for c in site["contacts"]]
                result = {"pdb_id": doc["pdb_id"], "resolution": doc["resolution"], "method": (doc.get("experimental_method") or [""])[0], "title": doc.get("title"),
                          "ligand_code": code, "match": "same InChIKey", "kind": "related",
                          "related": {"organism": organism, "protein": (e.get("molecule_name") or [""])[0], "accession": e["uniprot_accession"][0], "gene": gene,
                                      "basis": f"same gene ({gene}) in a different organism or strain", "fusion": len(organisms) > 1,
                                      "uniprot_url": f"https://www.uniprot.org/uniprotkb/{e['uniprot_accession'][0].split('-')[0]}"},
                          "target": t["name"], "target_chembl_id": t["id"], "organism": t["organism"], "mechanism": m["text"],
                          "residues": [r["label"] for r in site["residues"]], "polar": kinds.count("polar"), "nonpolar": kinds.count("nonpolar"),
                          "metal": kinds.count("metal"), "url": f"https://www.rcsb.org/structure/{doc['pdb_id'].upper()}", "checked": datetime.date.today().isoformat()}
                break
            if result:
                break
        if result:
            summary[d["id"]] = result; found += 1
            print(d["id"], result["pdb_id"], "|", t["name"][:30], t["organism"], "->", result["related"]["organism"], result["related"]["gene"], flush=True)
            (RAW / "binding.json").write_text(json.dumps(summary))
    print("done. related-protein sites:", found, "of", len(todo), "tried")


if __name__ == "__main__":
    main()
