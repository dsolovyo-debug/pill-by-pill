"""Pipeline step: medicine families, from data the catalogue already holds.

Two medicines are in the same family when they share the USAN stem that ChEMBL records for them (e.g. "-stat-") AND the same
first mechanism target in ChEMBL (e.g. HMG-CoA reductase). The stem alone groups too much ("-mab" is every antibody, "-stat-"
is many enzyme inhibitors); the target alone mixes unrelated chemistry. Members are listed by the first approval year the
catalogue holds. The earliest one is "earliest in these records", which is not a claim that it was first in its class:
older medicines may have been approved before the records begin, and some class members carry a different stem.
Idea from Gemini's v5.22 patch; rewritten to use the catalogue's own fields (ChEMBL stem, target id and name, first_year).
Writes <data dir>/family_trees.json.
Usage: python3 pipeline/build_family_trees.py <data dir>
"""
import collections, datetime, json, pathlib, re, sys

DATA = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site/data")


def main():
    drugs = [json.loads(f.read_text(encoding="utf-8")) for f in sorted((DATA / "drugs").glob("*.json"))]
    groups = collections.defaultdict(list)
    for d in drugs:
        stem = ((d.get("stem") or {}).get("stem") or "").split(";")[0].strip()
        targets = [m for m in d.get("mechanisms", []) if m.get("target_chembl_id") and m.get("target_name")]
        if not stem or not targets or not d.get("first_year"):
            continue
        groups[(stem, targets[0]["target_chembl_id"])].append((d, targets[0]))
    families = []
    for (stem, tid), members in groups.items():
        if len(members) < 2:
            continue
        members.sort(key=lambda x: (x[0]["first_year"], x[0]["name"].lower()))
        d0, t0 = members[0]
        meaning = (d0["stem"].get("meaning") or "").split(";")[0].strip()
        families.append({
            "id": re.sub(r"[^a-z0-9]+", "-", f"{stem}-{t0['target_name']}".lower()).strip("-")[:70],
            "stem": stem, "stem_meaning": meaning, "target_chembl_id": tid, "target_name": t0["target_name"],
            "target_url": f"https://www.ebi.ac.uk/chembl/explore/target/{tid}",
            "earliest": d0["id"], "first_year": d0["first_year"], "last_year": members[-1][0]["first_year"],
            "members": [{"id": d["id"], "name": d["name"], "year": d["first_year"], "type": d["type"],
                         "binding": bool(d.get("binding")), "eml": bool(d.get("who_eml")), "us": bool(d.get("us"))} for d, _ in members]})
    families.sort(key=lambda f: (-len(f["members"]), f["first_year"], f["id"]))
    used = collections.Counter()
    for f in families:                                     # ids stay unique if two targets share a name
        used[f["id"]] += 1
        if used[f["id"]] > 1:
            f["id"] += f"-{used[f['id']]}"
    out = {"note": "Families share the USAN stem ChEMBL records and the same first mechanism target in ChEMBL. Years are the first approval "
                   "year in this catalogue's records; the earliest member is the earliest in these records, not necessarily the first of its class.",
           "source": "ChEMBL (stems, targets) and the catalogue's approval records", "built": datetime.date.today().isoformat(),
           "count": len(families), "families": families}
    (DATA / "family_trees.json").write_text(json.dumps(out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print("families:", len(families), "medicines in them:", sum(len(f["members"]) for f in families))


if __name__ == "__main__":
    main()
