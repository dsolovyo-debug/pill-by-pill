"""Step 5 of the data pipeline: turn the curated v4 data sets into topic files for the v5 pages.

Each topic is one JSON file (<out>/topics/<key>.json) plus one line in <out>/topics.json describing how to show it:
which field is the title, which holds the plain-language text, which the expert text, which columns the reference
table shows, and where the source link is. Rows without a source link are left out and counted, because the site
shows nothing it cannot link to a source. Two topics (name stems, medicine families) are computed from the
catalogue instead of the old hand-typed lists, which had no sources.
Usage: python3 pipeline/build_topics.py <legacy json dir> <out data dir>
"""
import collections, json, pathlib, sys

SRC, OUT = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])

LABELS = {"gene": "Medicine", "brand": "Brand", "date": "Date", "year": "Year", "nda": "FDA application", "ind": "Used for",
          "target": "Target", "mod_chem": "Chemistry", "route": "Route", "co": "Company", "use": "Type of use", "status": "Status",
          "mod": "Type", "app": "FDA application", "name": "Name", "dis": "Disease", "ph": "Phase reached", "out": "What happened",
          "modality": "Type", "phase": "Phase", "sponsor": "Sponsor", "indication": "Used for", "key_data": "Key data",
          "milestone": "Milestone", "significance": "Why it matters", "category": "Category", "culprit": "Cause",
          "affected_drugs": "Medicines affected", "mechanism": "Mechanism", "clinical_rule": "Clinical rule", "rank": "Rank",
          "generic": "Medicine", "rx_count": "Prescriptions", "patients": "Patients", "class": "Class", "first_approval": "First approved",
          "generic_share": "Generic share", "biosim": "Biosimilar", "ref": "Reference product", "impact": "Impact", "price": "Price",
          "cat": "Class", "prod": "Product", "firm": "Firm", "reason": "Reason", "yr": "Year", "why": "Why", "title": "Title",
          "jobs2025": "Jobs 2025", "jobs2035": "Jobs 2035", "growth": "Growth %", "pay": "Median pay (USD)", "edu": "Education",
          "school": "School subjects", "cert": "Licence", "disease": "Disease", "desc": "About", "country": "Country", "region": "Region",
          "founded": "Founded", "hq": "Headquarters", "pathways": "Pathways", "landmark": "Landmark", "drug": "Medicine",
          "first_agency": "First agency", "us_fda": "US FDA", "eu_ema": "EU EMA", "japan_pmda": "Japan PMDA", "other_agencies": "Others",
          "lesson": "Lesson", "launched": "Launched", "scope": "Scope", "summary": "Summary", "framework": "Framework", "code": "Code",
          "label": "Pathway", "example": "Example", "dossier": "Dossier", "sequential_desc": "One country at a time",
          "parallel_desc": "Reviewed together", "designations": "Designations", "hta_step": "Pricing step", "imprint": "Imprint",
          "shape_color": "Shape and colour", "ndc": "NDC", "packaging": "Packaging", "safety_feature": "Safety feature",
          "schedule": "Schedule", "medical_use": "Medical use", "abuse_dependence": "Abuse and dependence",
          "prescribing_rules": "Prescribing rules", "examples": "Examples", "biomarker": "Biomarker", "rx_year": "Prescription since",
          "otc_date": "Over the counter since", "class_indication": "Class and use", "switch_milestone": "Milestone", "role": "Role",
          "function": "Function", "era": "Era", "discoverers": "Who", "civilization": "Tradition", "primary_text": "Key text",
          "botanical_source": "Plant source", "active_molecule": "Active molecule", "modern_descendant": "Modern medicine",
          "span": "How long it took", "what_for": "Used for", "how": "How it works", "warning": "Main warning", "pdb": "Structure",
          "stem": "Name part", "meaning": "Meaning", "count": "Medicines", "group": "Family", "expert": "Detail", "simple": "In short"}

# key, legacy constant, group, title, one-line intro, {t: title field, sub: subtitle fields, s: plain text, x: expert text,
#  cols: reference table columns, url: source link field, src: source title field, lab: [legacy view, sub-module] or None}
TOPICS = [
    ("discoveries", "MEDICAL_DISCOVERIES", "stories", "Great discoveries", "32 breakthroughs that changed medicine, from vaccination to gene editing.",
     dict(t="title", sub=["year", "discoverers"], s="simple", x="expert", cols=["year", "era", "title", "discoverers", "expert"], url="source_url", src="source_title")),
    ("ancient", "ANCIENT_TRADITIONS", "stories", "Ancient healers", "Old healing traditions and the modern medicines that grew out of them.",
     dict(t="civilization", sub=["era"], s="summary", x="summary", cols=["civilization", "era", "region", "primary_text", "botanical_source", "active_molecule", "modern_descendant"], url="url")),
    ("timelines", "DISCOVERY_TIMELINES", "stories", "From idea to pharmacy", "How long six famous medicines took to reach patients.",
     dict(t="drug", sub=["span"], s="sp", x="sp", cols=["drug", "span"], url="src")),
    ("withdrawals", "WITHDRAWALS_LIST", "safety", "Medicines taken off the market", "Six medicines that were withdrawn, and why.",
     dict(t="name", sub=["yr"], s="why", x="why", cols=["name", "yr", "why"], url="url", lab=["recalls", "faers-withdrawals"])),
    ("recalls", "RECALLS_LIST", "safety", "Recalls", "What happens when a medicine on the shelf turns out to have a problem.",
     dict(t="prod", sub=["cat", "date"], s="reason", x="reason", cols=["cat", "prod", "firm", "date", "reason"], url="url", lab=["recalls", "recall-classes"])),
    ("careers", "BLS_CAREERS", "people", "Jobs in medicine-making", "Nine careers, with pay and growth figures from the US Bureau of Labor Statistics.",
     dict(t="title", sub=["edu"], s="sp", x="xp", cols=["title", "jobs2025", "jobs2035", "growth", "pay", "edu", "cert"], url="url", lab=["careers", "bls-heatmap"])),
    ("charities", "CHARITIES", "people", "Patient groups", "Foundations that support people living with the diseases these medicines treat.",
     dict(t="name", sub=["disease"], s="desc", x="desc", cols=["name", "disease", "desc"], url="url")),
    ("peptides", "PEPTIDES_APPROVED", "modalities", "Approved peptide medicines", "92 peptide medicines approved by the FDA since 1970.",
     dict(t="gene", sub=["brand", "year"], s="ind", x="mod_chem", cols=["gene", "brand", "date", "nda", "ind", "target", "mod_chem", "route", "co", "status"], url="url", src="src_title", drug="gene", lab=["gene-medicines", "approved-peptides"])),
    ("oligos", "GENE_MEDICINES", "modalities", "Approved gene-targeted medicines", "25 oligonucleotide medicines (antisense, siRNA, aptamers) with FDA approval.",
     dict(t="gene", sub=["brand", "year"], s="ind", x="target", cols=["gene", "brand", "mod", "date", "ind", "target", "co", "status", "app"], url="url", drug="gene", lab=["gene-medicines", "approved-oligos"])),
    ("failed-peptides", "FAILED_PEPTIDES", "modalities", "Peptide programmes that failed", "Peptide candidates that did not make it, and what was learned.",
     dict(t="name", sub=["ph"], s="out", x="out", cols=["name", "mod", "dis", "ph", "out"], url="url")),
    ("failed-oligos", "FAILED_OLIGOS", "modalities", "Oligonucleotide programmes that failed", "25 oligonucleotide candidates that were stopped or withdrawn.",
     dict(t="name", sub=["ph"], s="out", x="out", cols=["name", "mod", "dis", "ph", "out"], url="url", src="src")),
    ("pipeline", "PIPELINE_CANDIDATES", "modalities", "In development", "Peptide and oligonucleotide candidates in late clinical trials.",
     dict(t="name", sub=["phase"], s="indication", x="key_data", cols=["name", "modality", "phase", "sponsor", "target", "route", "indication", "key_data"], url="url", lab=["gene-medicines", "pipeline-history"])),
    ("oligo-timeline", "OLIGO_TIMELINE", "modalities", "Oligonucleotide milestones", "Ten turning points in gene-targeted medicines.",
     dict(t="milestone", sub=["year"], s="significance", x="significance", cols=["year", "milestone", "modality", "significance"], url="url")),
    ("moa", "MOA_ENGINE_DATA", "modalities", "How eight medicines work, in 3D", "Mechanism walk-throughs from whole body down to the binding pocket.",
     dict(t="name", sub=["pdb"], s=None, x=None, cols=["name", "pdb"], url="source_url", src="source_title", keep=["tiers", "drug_name"], drug="drug_name", lab=["how", "moa-engine"])),
    ("interactions", "DRUG_INTERACTIONS", "clinical", "Food and drug interactions", "Six well-known interactions and the rule that follows from each.",
     dict(t="title", sub=["category"], s="clinical_rule", x="mechanism", cols=["title", "category", "culprit", "affected_drugs", "mechanism", "clinical_rule"], url="url", src="source_title", lab=["how", "interactions-peds"])),
    ("pgx", "PHARMACOGENOMICS_DATA", "clinical", "Pharmacogenomics", "Gene variants that change how a medicine should be dosed.",
     dict(t="biomarker", sub=["drug"], s="clinical_rule", x="mechanism", cols=["biomarker", "drug", "category", "mechanism", "clinical_rule"], url="url", src="src_title", lab=["gene-medicines", "pgx-biomarkers"])),
    ("labels", "DRUG_LABELS", "clinical", "Prescribing label notes", "Plain summaries of 28 FDA labels: use, mechanism and main warning.",
     dict(t="name", sub=[], s="what_for", x="how", cols=["name", "what_for", "how", "warning"], url="label_url", drug="name", lab=["find", "label-anatomy"])),
    ("pediatric", "PEDIATRIC_AND_VACCINE_DATA", "clinical", "Medicines for children, and vaccines", "The laws and schedules behind children's medicines.",
     dict(t="title", sub=["code"], s="simple", x="expert", cols=["code", "title", "expert"], url="url", src="src_title", lab=["how", "interactions-peds"])),
    ("controlled", "CONTROLLED_SUBSTANCES_DATA", "clinical", "Controlled substance schedules", "US DEA Schedules I to V and what each means for prescribing.",
     dict(t="schedule", sub=[], s="medical_use", x="prescribing_rules", cols=["schedule", "medical_use", "abuse_dependence", "prescribing_rules", "examples"], url="url", src="src_title", lab=["recalls", "dea-schedules"])),
    ("pill-id", "PILL_IDENTIFICATION_DATA", "clinical", "Pill identification", "Imprints, shapes, NDC codes and packaging safety features.",
     dict(t="drug", sub=["category"], s="safety_feature", x="imprint", cols=["drug", "category", "imprint", "shape_color", "ndc", "packaging", "safety_feature"], url="url", src="src_title", lab=["find", "pill-id"])),
    ("otc", "OTC_SWITCHES_DATA", "clinical", "Prescription to over-the-counter", "Eight medicines that moved from prescription to the open shelf.",
     dict(t="drug", sub=["otc_date"], s="switch_milestone", x="class_indication", cols=["drug", "rx_year", "otc_date", "class_indication", "switch_milestone"], url="url", src="src_title", lab=["find", "otc-switches"])),
    ("excipients", "EXCIPIENTS_AND_DELIVERY_DATA", "chemistry", "Excipients and delivery", "The ingredients that are not the drug, and what they do.",
     dict(t="category", sub=["role"], s="function", x="function", cols=["category", "role", "examples", "function"], url="url", src="src_title", lab=["how", "formulation-pk"])),
    ("meps", "TOP_MEPS_DRUGS", "market", "Most prescribed in the US", "The 15 most prescribed outpatient medicines (AHRQ MEPS).",
     dict(t="generic", sub=["brand"], s="indication", x="mechanism", cols=["rank", "generic", "brand", "rx_count", "patients", "class", "indication", "first_approval", "generic_share"], url="url", drug="generic")),
    ("biosimilars", "BIOSIMILARS_2026", "market", "Biosimilars", "Recent biosimilar approvals and their reference products.",
     dict(t="biosim", sub=["date"], s="ref", x="target", cols=["biosim", "date", "ref", "target"], url="url")),
    ("medicare", "CMS_DRUGS", "market", "Medicare spending", "Six medicines with large Medicare impact.",
     dict(t="name", sub=[], s="impact", x="price", cols=["name", "ind", "impact", "price"], url="url", lab=["new-medicines", "market-policy"])),
    ("agencies", "GLOBAL_AGENCIES", "world", "Medicine regulators around the world", "14 agencies and bodies that decide which medicines people can use.",
     dict(t="name", sub=["country", "founded"], s="simple", x="expert", cols=["code", "name", "country", "founded", "hq", "pathways", "landmark"], url="url", src="src_title", lab=["global", "agencies-overview"])),
    ("divergences", "GLOBAL_DIVERGENCES", "world", "When countries disagreed", "14 medicines approved in one place and delayed or refused in another.",
     dict(t="drug", sub=["first_agency"], s="lesson", x="lesson", cols=["drug", "modality", "category", "first_agency", "us_fda", "eu_ema", "japan_pmda", "other_agencies", "lesson"], url="url", src="src_title", lab=["global", "divergences"])),
    ("pharmacovigilance", "GLOBAL_PV_SYSTEMS", "world", "Safety monitoring systems", "How side effects are reported and tracked after approval.",
     dict(t="name", sub=["region", "launched"], s="simple", x="expert", cols=["code", "name", "region", "launched", "expert"], url="url", src="src_title", lab=["global", "pv-access"])),
    ("access", "GLOBAL_ACCESS_PROGRAMS", "world", "Global access programmes", "Programmes that get medicines to countries that cannot wait.",
     dict(t="name", sub=["scope"], s="summary", x="summary", cols=["code", "name", "scope", "summary"], url="url", src="src_title", lab=["global", "pv-access"])),
    ("hta", "GLOBAL_HTA_AGENCIES", "world", "Who decides what a medicine is worth", "Health technology assessment bodies and how they judge value.",
     dict(t="name", sub=["country"], s="simple", x="expert", cols=["code", "name", "country", "framework", "expert"], url="url", src="src_title", lab=["global", "hta-pathways"])),
    ("submissions", "SUBMISSION_PATHWAYS", "world", "Filing in many countries", "Four routes for submitting one medicine to several regulators.",
     dict(t="label", sub=["example"], s="parallel_desc", x="dossier", cols=["label", "example", "dossier", "sequential_desc", "parallel_desc", "designations", "hta_step"], url="url", src="src_title", lab=["global", "hta-pathways"])),
]
ATC_GROUPS = {"A": "Digestive system and metabolism", "B": "Blood", "C": "Heart and circulation", "D": "Skin", "G": "Urinary and reproductive system",
              "H": "Hormones", "J": "Infections", "L": "Cancer and the immune system", "M": "Muscles and bones", "N": "Nervous system",
              "P": "Parasites", "R": "Breathing", "S": "Eyes and ears", "V": "Various"}


def main():
    (OUT / "topics").mkdir(parents=True, exist_ok=True)
    listing, dropped = [], {}
    for key, const, group, title, intro, d in TOPICS:
        rows = json.loads((SRC / f"{const}.json").read_text())
        if isinstance(rows, dict):                       # keyed objects become rows with a name; the key is usually the plain drug name
            rows = [dict({"name": v.get("name") or k.title(), "drug_name": "penicillin g" if k == "penicillin" else k}, **v) for k, v in rows.items()]
        kept = [r for r in rows if str(r.get(d["url"]) or "").startswith("http")]
        if len(kept) != len(rows):
            dropped[key] = len(rows) - len(kept)
        fields = sorted({f for f in [d["t"], d.get("s"), d.get("x"), d["url"], d.get("src"), d.get("drug"), *d.get("keep", []), *d.get("sub", []), *d["cols"]] if f})
        (OUT / "topics" / f"{key}.json").write_text(json.dumps([{f: r.get(f) for f in fields} for r in kept], ensure_ascii=False), encoding="utf-8")
        listing.append({"key": key, "group": group, "title": title, "intro": intro, "count": len(kept), "title_field": d["t"],
                        "sub_fields": d.get("sub", []), "simple_field": d.get("s"), "expert_field": d.get("x"), "columns": d["cols"],
                        "url_field": d["url"], "source_field": d.get("src"), "drug_field": d.get("drug"), "lab": d.get("lab"),
                        "labels": {c: LABELS.get(c, c.replace("_", " ").capitalize()) for c in d["cols"] + d.get("sub", [])}})

    # computed topics -----------------------------------------------------------------------------------------
    stems, families = collections.defaultdict(lambda: {"meaning": "", "examples": []}), collections.Counter()
    index = json.loads((OUT / "drug_index.json").read_text())["rows"]
    for f in sorted((OUT / "drugs").glob("*.json")):
        drug = json.loads(f.read_text())
        if drug.get("stem"):
            s = stems[drug["stem"]["stem"]]
            s["meaning"] = drug["stem"]["meaning"]
            s["examples"].append(drug["name"])
            s.setdefault("url", f"https://www.ebi.ac.uk/chembl/explore/compound/{drug['chembl_id']}")   # a record that shows this stem
    stem_rows = [{"stem": k, "meaning": v["meaning"], "count": len(v["examples"]), "examples": ", ".join(v["examples"][:5]),
                  "url": v["url"]}
                 for k, v in sorted(stems.items(), key=lambda kv: -len(kv[1]["examples"])) if len(v["examples"]) >= 3]
    (OUT / "topics" / "stems.json").write_text(json.dumps(stem_rows, ensure_ascii=False), encoding="utf-8")
    listing.append({"key": "stems", "group": "chemistry", "title": "Name decoder", "intro": "The hidden code in medicine names: what endings like -mab and -statin mean.",
                    "count": len(stem_rows), "title_field": "stem", "sub_fields": ["count"], "simple_field": "meaning", "expert_field": "examples",
                    "columns": ["stem", "meaning", "count", "examples"], "url_field": "url", "source_field": None, "drug_field": None, "lab": ["how", "journey-stems"],
                    "labels": {"stem": "Name part", "meaning": "Meaning (USAN stem definition, via ChEMBL)", "count": "Medicines in this catalogue", "examples": "Examples"}})
    for row in index:
        for letter in row[4]:
            families[letter] += 1
    family_rows = [{"group": ATC_GROUPS[k], "code": k, "count": n, "url": f"https://atcddd.fhi.no/atc_ddd_index/?code={k}"}
                   for k, n in sorted(families.items(), key=lambda kv: -kv[1]) if k in ATC_GROUPS]
    (OUT / "topics" / "families.json").write_text(json.dumps(family_rows, ensure_ascii=False), encoding="utf-8")
    listing.append({"key": "families", "group": "chemistry", "title": "Medicine families", "intro": "Every medicine sorted by the part of the body it works on (WHO ATC groups).",
                    "count": len(family_rows), "title_field": "group", "sub_fields": ["count"], "simple_field": None, "expert_field": None,
                    "columns": ["code", "group", "count"], "url_field": "url", "source_field": None, "drug_field": None, "lab": None,
                    "labels": {"code": "ATC code", "group": "Family", "count": "Medicines in this catalogue"}})

    quiz = [q for q in json.loads((SRC / "QUIZ.json").read_text()) if isinstance(q.get("src"), list) and len(q["src"]) > 1 and str(q["src"][1]).startswith("http")]
    extra = json.loads((pathlib.Path(__file__).parent / "quiz_extra.json").read_text(encoding="utf-8"))["questions"]   # v5.24, checked
    rows = [{"q": q["q"], "answers": q["a"], "right": q["right"], "why": q["why"], "source": q["src"][0], "url": q["src"][1]} for q in quiz]
    rows += [{k: q[k] for k in ("q", "answers", "right", "why", "source", "url")} for q in extra if q["url"].startswith("https://")]
    (OUT / "quiz.json").write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    quiz = rows
    (OUT / "topics.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1), encoding="utf-8")
    print("topics", len(listing), "rows dropped for missing source:", dropped, "quiz questions kept:", len(quiz))


if __name__ == "__main__":
    main()
