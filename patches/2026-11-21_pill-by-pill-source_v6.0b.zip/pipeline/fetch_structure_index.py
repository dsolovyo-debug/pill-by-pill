"""Pipeline step: the two lookup tables fetch_binding.py needs.

  raw/pdb_ligand_by_inchikey.json   InChIKey -> ligand codes, read from the PDB chemical component dictionary
                                    (https://files.rcsb.org/pub/pdb/data/monomers/components.cif.gz, about 120 MB)
  raw/chembl_targets.json           name, organism and UniProt accessions of every ChEMBL target named in a mechanism
Targets already in raw/chembl_targets.json are kept and only new ones are asked for; --targets-only skips the ligand index.
Usage: python3 pipeline/fetch_structure_index.py <raw dir> <data dir> [--targets-only]
"""
import gzip, json, pathlib, re, sys, time, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
COMPONENTS = "https://files.rcsb.org/pub/pdb/data/monomers/components.cif.gz"
TARGETS = "https://www.ebi.ac.uk/chembl/api/data/target.json?limit=100&target_chembl_id__in="


def ligand_index():
    gz = RAW / "components.cif.gz"
    if not gz.exists():
        urllib.request.urlretrieve(COMPONENTS, gz)
    keys, code = {}, None
    with gzip.open(gz, "rt", errors="replace") as f:
        for line in f:
            if line.startswith("data_"):
                code = line[5:].strip()
            elif " InChIKey " in line and code:
                m = re.search(r"([A-Z]{14}-[A-Z]{10}-[A-Z])", line)
                if m:
                    keys.setdefault(m.group(1), []).append(code)
    (RAW / "pdb_ligand_by_inchikey.json").write_text(json.dumps(keys))
    print("ligand codes indexed:", len(keys))


def target_table():
    ids = sorted({m["target_chembl_id"] for f in (DATA / "drugs").glob("*.json") for m in json.loads(f.read_text())["mechanisms"] if m["target_chembl_id"]})
    known_file = RAW / "chembl_targets.json"
    out = json.loads(known_file.read_text()) if known_file.exists() else []
    have = {t["id"] for t in out}
    ids = [i for i in ids if i not in have]
    for i in range(0, len(ids), 40):                       # larger pages make the ChEMBL server return 500
        for attempt in range(4):
            try:
                page = json.loads(urllib.request.urlopen(TARGETS + ",".join(ids[i:i + 40]), timeout=120).read())
                break
            except Exception:
                time.sleep(3)
        else:
            raise RuntimeError("ChEMBL did not answer for targets " + ",".join(ids[i:i + 40]))
        out += [{"id": t["target_chembl_id"], "name": t["pref_name"], "organism": t["organism"], "type": t["target_type"],
                 "accessions": [c["accession"] for c in t["target_components"] if c.get("accession")]} for t in page["targets"]]
    (RAW / "chembl_targets.json").write_text(json.dumps(out))
    print("targets:", len(out), "(" + str(len(ids)), "new asked for)")


if __name__ == "__main__":
    if "--targets-only" not in sys.argv:
        ligand_index()
    target_table()
