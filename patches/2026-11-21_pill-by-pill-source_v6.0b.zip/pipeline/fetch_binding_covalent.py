"""Pipeline step: binding sites for medicines that bond covalently to their target.

A covalent drug (ibrutinib, osimertinib, sotorasib, beta-lactam antibiotics, boronic acids...) reacts with its target, so the
PDB deposits the reacted form under its own ligand code, and the InChIKey match in fetch_binding.py misses it. For each small
molecule with a structure and a ChEMBL target but no binding site yet, this:
  1. asks PDBe for entries of the target (UniProt accession) whose title or molecule name contains the medicine's name or a
     research code (case-insensitive: PDBe's text fields are case-sensitive, see name_clause), and collects their ligand codes;
  2. keeps a ligand code only if its chemistry is the medicine's: the largest common substructure (elements compared, bond
     orders ignored, because the reaction changes them) covers at least 75% of the medicine's heavy atoms, and the ligand's
     heavy-atom count is 60-140% of the medicine's (a ring-opened or partly cleaved adduct still passes; an unrelated
     compound does not);
  3. takes every entry of the target with a kept ligand code, best resolution first (at most 4 tried, 3.5 A or better), and
     reads its covalent links (mmCIF _struct_conn, type covale) between an amino acid of a target chain of 60 or more residues
     and that ligand;
  4. cuts out the binding site as fetch_binding.py does, keeps it only if most contacted residues belong to that target
     chain, and records the covalent bond (residue, atoms, distance).
Nothing is modelled. The page says the deposited ligand is the reacted form. Idea and the covale parsing from Gemini's v5.20
patch; matching rules added here.
Usage: python3 pipeline/fetch_binding_covalent.py <raw dir> <site dir> [comma-separated page ids, to try only those]
"""
import collections, datetime, json, pathlib, re, sys, urllib.parse

import gemmi
from rdkit import Chem, RDLogger
from rdkit.Chem import rdFMCS

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from fetch_binding import get, binding_site, SEARCH          # noqa: E402  (same downloads, same site cutting)
from fetch_binding_biologics import name_clause              # noqa: E402

RDLogger.DisableLog("rdApp.*")
RAW, SITE = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
AMINO = set("ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL".split())
SKIP = set("HOH SO4 PO4 GOL EDO PEG DMS ACT CL NA MG ZN CA K MN FE CU NI CO BME DTT NAG MAN FUC BMA GAL".split())
_ccd = {}


def ccd_smiles(code):
    """SMILES of a PDB chemical component, from its CCD file (cached in raw/ccd_smiles.json)."""
    if not _ccd:
        f = RAW / "ccd_smiles.json"
        _ccd.update(json.loads(f.read_text()) if f.exists() else {})
    if code not in _ccd:
        blob = get(f"https://files.rcsb.org/ligands/download/{code}.cif", binary=True)
        smi = None
        if blob:
            doc = gemmi.cif.read_string(blob.decode("utf-8", "replace"))
            block = doc.sole_block()
            table = block.find("_pdbx_chem_comp_descriptor.", ["type", "descriptor"])
            for row in table:
                if row[0].strip('"') in ("SMILES_CANONICAL", "SMILES"):
                    smi = gemmi.cif.as_string(row[1])
                    if row[0].strip('"') == "SMILES_CANONICAL":
                        break
        _ccd[code] = smi
        (RAW / "ccd_smiles.json").write_text(json.dumps(_ccd))
    return _ccd[code]


def same_chemistry(drug_smiles, lig_smiles):
    a, b = Chem.MolFromSmiles(drug_smiles or ""), Chem.MolFromSmiles(lig_smiles or "")
    if a is None or b is None:
        return None
    # the largest fragment of the medicine (drop counter-ions)
    a = max(Chem.GetMolFrags(a, asMols=True), key=lambda m: m.GetNumHeavyAtoms())
    na, nb = a.GetNumHeavyAtoms(), b.GetNumHeavyAtoms()
    if na < 8 or not 0.6 * na <= nb <= 1.4 * na:
        return None
    # quick screen first: element counts must be close (a reaction adds or removes only a few atoms)
    ca, cb = collections.Counter(x.GetSymbol() for x in a.GetAtoms()), collections.Counter(x.GetSymbol() for x in b.GetAtoms())
    if sum((ca & cb).values()) < 0.75 * na:
        return None
    res = rdFMCS.FindMCS([a, b], atomCompare=rdFMCS.AtomCompare.CompareElements, bondCompare=rdFMCS.BondCompare.CompareAny,
                         ringMatchesRingOnly=False, completeRingsOnly=False, timeout=4)
    share = res.numAtoms / na
    return round(share, 2) if share >= 0.75 else None


def covalent_links(path, accessions):
    """(protein chain, residue name, seq, atom, ligand chain, ligand code, ligand seq, ligand atom, distance) for covale links."""
    st = gemmi.read_structure(str(path))
    block = gemmi.cif.read(str(path)).sole_block()
    target_chains = {gemmi.cif.as_string(r[0]) for r in block.find("_struct_ref_seq.", ["pdbx_strand_id", "pdbx_db_accession"])
                     if gemmi.cif.as_string(r[1]) in accessions}           # author chain ids mapped to the target's UniProt entry
    model0 = st[0]
    target_chains = {c for c in target_chains if model0.find_chain(c) and sum(1 for r in model0[c] if r.name in AMINO) >= 60}   # not a peptide fragment
    if not target_chains:
        return []
    out = []
    model = st[0]
    for con in st.connections:
        if con.type != gemmi.ConnectionType.Covale:
            continue
        p1, p2 = con.partner1, con.partner2
        sides = []
        for p in (p1, p2):
            cra = model.find_cra(p, ignore_segment=True)
            sides.append((p.chain_name, p.res_id.name, str(p.res_id.seqid.num), p.atom_name, cra.residue))
        for prot, lig in ((sides[0], sides[1]), (sides[1], sides[0])):
            if prot[1] in AMINO and lig[1] not in AMINO and lig[1] not in SKIP and (not target_chains or prot[0] in target_chains):
                out.append((prot[0], prot[1], prot[2], prot[3], lig[0], lig[1], lig[2], lig[3],
                            round(prot[4][prot[3]][0].pos.dist(lig[4][lig[3]][0].pos), 2) if prot[4] and lig[4] else None))
    return out


def mark_covalent(site, bond):
    """Turn the closest ligand-residue atom pair of the bonded residue into a "covalent" contact (shown first)."""
    best = None
    for ri, r in enumerate(site["residues"]):
        if r["label"] != bond["protein_residue"] or r.get("chain") != bond["protein_chain"]:
            continue
        for ai, (_, *pa) in enumerate(r["atoms"]):
            for li, (_, *pl) in enumerate(site["ligand"]["atoms"]):
                dist = sum((x - y) ** 2 for x, y in zip(pa, pl)) ** 0.5
                if best is None or dist < best[0]:
                    best = (dist, li, ri, ai)
    if best and best[0] < 2.3:
        site["contacts"] = [[best[1], best[2], best[3], "covalent", round(best[0], 2)]] + \
                           [c for c in site["contacts"] if not (c[0] == best[1] and c[1] == best[2])]
        return True
    return False


def main():
    targets = {t["id"]: t for t in json.loads((RAW / "chembl_targets.json").read_text())}
    summary = json.loads((RAW / "binding.json").read_text())
    (RAW / "pdb").mkdir(exist_ok=True)
    tried_file = RAW / "binding_covalent_tried.json"
    tried = json.loads(tried_file.read_text()) if tried_file.exists() else {}
    found = 0
    only = set(sys.argv[3].split(",")) if len(sys.argv) > 3 else None
    for f in sorted((SITE / "data" / "drugs").glob("*.json")):
        if only and f.stem not in only:
            continue
        d = json.loads(f.read_text())
        if d["type"] != "Small molecule" or not d.get("structure") or not d["mechanisms"] or summary.get(d["id"]) or d["id"] in tried:
            continue
        word = re.sub(r"[^a-z]", "", d["name"].lower().split()[0])
        if len(word) < 6:
            continue
        result, failed = None, False
        for m in d["mechanisms"]:
            t = targets.get(m["target_chembl_id"])
            if not t or not t["accessions"] or t.get("type") != "SINGLE PROTEIN":      # covalent drugs react with one enzyme; skips ribosomes and complexes
                continue
            codes = {c for c in (d.get("names") or {}).get("research_codes", [])[:6] if re.fullmatch(r"[A-Z]{1,6}[- ]?\d{2,7}", c)}
            forms = sorted({v.replace(" ", "\\ ") for c in codes for v in (c, c.replace("-", " "), c.replace("-", ""))})   # AMG-510, AMG 510, AMG510
            code_clause = " OR ".join(f"title:*{v}*" for v in forms)
            acc = " OR ".join(t["accessions"][:12])
            q = f"uniprot_accession:({acc}) AND ({name_clause([word])}{' OR ' + code_clause if code_clause else ''})"
            params = {"q": q, "fl": "pdb_id,compound_id", "rows": 30, "wt": "json"}
            docs = (get(SEARCH + urllib.parse.urlencode(params)) or {}).get("response", {}).get("docs", [])
            ligand_codes = list(dict.fromkeys(c for doc in docs for c in doc.get("compound_id") or [] if c not in SKIP and c not in AMINO))[:15]
            verified = {c: share for c in ligand_codes if (share := same_chemistry(d["structure"]["smiles"], ccd_smiles(c)))}
            if not verified:
                continue
            # every entry of this target with one of those ligand codes, best resolution first (titles often use a code name)
            params = {"q": f"compound_id:({' OR '.join(verified)}) AND uniprot_accession:({acc})", "fl": "pdb_id,resolution,experimental_method,title",
                      "sort": "resolution asc", "rows": 20, "wt": "json"}
            entries = (get(SEARCH + urllib.parse.urlencode(params)) or {}).get("response", {}).get("docs", [])
            seen = []
            for doc in entries:
                if doc["pdb_id"] in seen or not doc.get("resolution") or doc["resolution"] > 3.5:
                    continue
                seen.append(doc["pdb_id"])
                if len(seen) > 4:
                    break
                path = RAW / "pdb" / f"{doc['pdb_id']}.cif"
                blob = get(f"https://files.rcsb.org/download/{doc['pdb_id'].upper()}.cif", binary=True)
                if not blob:
                    continue
                path.write_bytes(blob)
                hit = site = None
                try:
                    links = [l for l in covalent_links(path, set(t["accessions"])) if l[5] in verified]
                    for link in links:
                        site = binding_site(path, link[5])
                        if site and sum(1 for r in site["residues"] if r["chain"] == link[0]) >= 0.6 * len(site["residues"]):
                            hit = (link, verified[link[5]])
                            break
                        site = None                                  # most contacts come from another molecule (an antibody, MHC...)
                except Exception as e:
                    print(d["id"], doc["pdb_id"], "error:", e, flush=True)
                    site, failed = None, True
                path.unlink(missing_ok=True)
                if site and hit:
                    link, share = hit
                    bond = {"protein_residue": f"{link[1].capitalize()} {link[2]}", "protein_chain": link[0], "protein_atom": link[3],
                            "ligand_code": link[5], "ligand_atom": link[7], "distance": link[8]}
                    site["covalent"] = dict(bond, shown=mark_covalent(site, bond))
                    (SITE / "bind" / f"{d['id']}.json").write_text(json.dumps(site, separators=(",", ":")))
                    kinds = [c[3] for c in site["contacts"]]
                    result = {"pdb_id": doc["pdb_id"], "resolution": doc["resolution"], "method": (doc.get("experimental_method") or [""])[0],
                              "title": doc.get("title"), "ligand_code": link[5],
                              "match": f"covalently bound form of the medicine (ligand {link[5]}, joined to {bond['protein_residue']}); "
                                       f"shares {int(share * 100)}% of the medicine's heavy atoms",
                              "covalent": bond, "target": t["name"], "target_chembl_id": t["id"], "organism": t["organism"], "mechanism": m["text"],
                              "residues": [r["label"] for r in site["residues"]], "polar": kinds.count("polar"), "nonpolar": kinds.count("nonpolar"),
                              "metal": kinds.count("metal"), "url": f"https://www.rcsb.org/structure/{doc['pdb_id'].upper()}",
                              "checked": datetime.date.today().isoformat()}
                    break
            if result:
                break
        if result or not failed:                      # an error is retried on the next run, never recorded as "nothing found"
            tried[d["id"]] = bool(result)
            tried_file.write_text(json.dumps(tried))
        if result:
            summary[d["id"]] = result
            found += 1
            (RAW / "binding.json").write_text(json.dumps(summary))
            print(d["id"], result["pdb_id"], result["ligand_code"], result["covalent"]["protein_residue"], result["match"][-40:], flush=True)
    print("done. covalent binding sites:", found, "new;", sum(1 for v in tried.values() if v), "in all")


if __name__ == "__main__":
    main()
