"""Pipeline step: find an experimental structure of each drug bound to its own target, and cut out the binding site.

For each medicine that has a structure (InChIKey) or biologic UniProt/PDB entry and a mechanism target in ChEMBL:
  1. find the drug's ligand code in the PDB chemical component dictionary (same InChIKey; protonation may differ)
  2. ask PDBe's search for entries that contain that ligand AND the target protein (UniProt accession), best resolution first
  3. download the entry from files.rcsb.org and keep the drug plus every residue that has an atom within 4 A of it
  4. record geometric contacts measured on the deposited coordinates:
       metal    drug N/O/S within 2.8 A of a metal ion (monoatomic ion OR catalytic metal center inside a cofactor such as HEM/HEC/CLA)
       polar    drug N/O within 3.5 A of a protein or cofactor N/O (a possible hydrogen bond or salt bridge)
       nonpolar drug carbon or halogen within 4.0 A of a protein or cofactor carbon or sulfur (closest one per residue)
These are distances, not energies. Nothing is modelled or docked: a drug with no deposited complex gets no binding site.
Writes <site>/bind/<id>.json (coordinates for the animation) and raw/binding.json (summary merged into the drug files).
Usage: python3 pipeline/fetch_binding.py <raw dir> <site dir>
"""
import datetime, json, math, pathlib, sys, time, urllib.parse, urllib.request

import gemmi

RAW, SITE = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
SEARCH = "https://www.ebi.ac.uk/pdbe/search/pdb/select?"
METALS = {"ZN", "MG", "FE", "MN", "CA", "CU", "CO", "NI", "NA", "K", "CD", "HG"}
COFACTORS = {"HEM", "HEC", "HEA", "FAD", "FMN", "NAD", "NAP", "NAI", "NDP", "PLP", "TPP", "SAM", "SAH", "COA", "ATP", "ADP"}
RADII = {"C": .76, "N": .71, "O": .66, "S": 1.05, "P": 1.07, "F": .57, "CL": 1.02, "BR": 1.20, "I": 1.39, "SE": 1.20, "B": .84,
         "FE": 1.32, "ZN": 1.22, "MG": 1.41, "CA": 1.76, "MN": 1.39, "CU": 1.32, "CO": 1.26}
MAX_CONTACTS, MAX_LIGAND_ATOMS = 14, 120


def get(url, binary=False, tries=4):
    for i in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=120) as r:
                return r.read() if binary else json.loads(r.read())
        except Exception as e:
            if getattr(e, "code", None) == 404:
                return None
            time.sleep(2 * (i + 1))
    return None


def best_entry(ligand_codes, accessions):
    q = f"compound_id:({' OR '.join(ligand_codes)}) AND uniprot_accession:({' OR '.join(accessions[:12])})"
    params = {"q": q, "fl": "pdb_id,resolution,experimental_method,title,compound_id", "sort": "resolution asc", "rows": 5, "wt": "json",
              "group": "true", "group.field": "pdb_id"}
    res = get(SEARCH + urllib.parse.urlencode(params))
    for g in ((res or {}).get("grouped", {}).get("pdb_id", {}).get("groups", [])):
        doc = g["doclist"]["docs"][0]
        if doc.get("resolution"):
            code = next((c for c in doc.get("compound_id", []) if c in ligand_codes), ligand_codes[0])
            return {"pdb_id": doc["pdb_id"], "resolution": doc["resolution"], "method": (doc.get("experimental_method") or [""])[0],
                    "title": doc.get("title"), "ligand_code": code}
    return None


def bonds_within(atoms):
    out = []
    for i in range(len(atoms)):
        for j in range(i + 1, len(atoms)):
            limit = RADII.get(atoms[i].element.name.upper(), .8) + RADII.get(atoms[j].element.name.upper(), .8) + .45
            if atoms[i].pos.dist(atoms[j].pos) < limit:
                out.append([i, j])
    return out


def keep(atom):
    return atom.element.name != "H" and atom.altloc in ("\0", "A")


def same_residue(chain_a, res_a, chain_b, res_b):
    return chain_a.name == chain_b.name and str(res_a.seqid) == str(res_b.seqid) and res_a.name == res_b.name


def binding_site(path, ligand_code):
    st = gemmi.read_structure(str(path))
    st.setup_entities()
    model = st[0]
    ns = gemmi.NeighborSearch(model, st.cell, 6).populate()
    best = None
    for chain in model:
        for res in chain:
            if res.name != ligand_code:
                continue
            lig = [a for a in res if keep(a)]
            if not 4 <= len(lig) <= MAX_LIGAND_ATOMS:
                continue
            near = {}                                   # (chain, seqid_str, name) -> residue
            pairs = []
            for li, a in enumerate(lig):
                for mark in ns.find_atoms(a.pos, "\0", radius=4.0):
                    cra = mark.to_cra(model)
                    if same_residue(cra.chain, cra.residue, chain, res) or cra.residue.name == "HOH" or not keep(cra.atom):
                        continue
                    el = cra.atom.element.name.upper()
                    is_protein = cra.residue.entity_type == gemmi.EntityType.Polymer
                    # Include both monoatomic metal ions (ZN, MG, CA) and catalytic metal centers inside cofactors (e.g. FE in HEM)
                    is_metal = el in METALS and (len(cra.residue) == 1 or cra.residue.name in COFACTORS)
                    is_cofactor = cra.residue.name in COFACTORS and not is_metal
                    if not (is_protein or is_metal or is_cofactor):
                        continue
                    d = a.pos.dist(cra.atom.pos)
                    if d > 4.0 or d < 1.0:
                        continue
                    key = (cra.chain.name, str(cra.residue.seqid), cra.residue.name)
                    near[key] = cra.residue
                    le, pe = a.element.name.upper(), el
                    kind = ("metal" if is_metal and le in ("N", "O", "S") and d <= 2.8 else
                            "polar" if not is_metal and le in ("N", "O") and pe in ("N", "O") and d <= 3.5 else
                            "nonpolar" if not is_metal and le in ("C", "F", "CL", "BR", "I") and pe in ("C", "S") else None)
                    if kind:
                        pairs.append((kind, round(d, 2), li, key, cra.atom.name))
            protein_contacts = sum(1 for p in pairs if p[0] != "metal")
            metal_contacts = sum(1 for p in pairs if p[0] == "metal")
            score = protein_contacts + 2 * metal_contacts
            if best is None or score > best[0]:
                best = (score, res, lig, near, pairs, chain)
    if not best or len(best[4]) < 3:
        return None
    _, res, lig, near, pairs, lig_chain = best
    chosen, seen_polar, seen_nonpolar = [], {}, set()
    for kind, d, li, key, pname in sorted(pairs, key=lambda p: ({"metal": 0, "polar": 1, "nonpolar": 2}[p[0]], p[1])):
        if kind == "polar":
            if seen_polar.get(key, 0) >= 2 or (li, key) in [(c[2], c[3]) for c in chosen]:
                continue
            seen_polar[key] = seen_polar.get(key, 0) + 1
        elif kind == "nonpolar":
            if key in seen_nonpolar or key in seen_polar:
                continue
            seen_nonpolar.add(key)
        chosen.append((kind, d, li, key, pname))
    # keep a mix: the closest polar and metal contacts first, then room for non-polar ones
    strong = [c for c in chosen if c[0] != "nonpolar"][:8]
    chosen = strong + [c for c in chosen if c[0] == "nonpolar"][:MAX_CONTACTS - len(strong)]
    centre = gemmi.Position(*(sum(getattr(a.pos, k) for a in lig) / len(lig) for k in "xyz"))
    rel = lambda p: [round(p.x - centre.x, 2), round(p.y - centre.y, 2), round(p.z - centre.z, 2)]
    residues, index = [], {}
    for kind, d, li, key, pname in chosen:
        if key not in index:
            atoms = [a for a in near[key] if keep(a)]
            index[key] = len(residues)
            label = f"{key[2].capitalize()} {key[1]}" if len(near[key]) > 1 else key[2].capitalize()
            residues.append({"label": label, "chain": key[0], "atoms": [[a.element.name, *rel(a.pos)] for a in atoms],
                             "names": [a.name for a in atoms], "bonds": bonds_within(atoms)})
    contacts = []
    for kind, d, li, key, pname in chosen:
        r = residues[index[key]]
        contacts.append([li, index[key], r["names"].index(pname), kind, d])
    for r in residues:
        r["anchor"] = r["names"].index("CA") if "CA" in r["names"] else (r["names"].index("FE") if "FE" in r["names"] else 0)
        del r["names"]
    # direction out of the pocket: away from the protein polymer heavy atoms around the drug (excluding HOH and the ligand itself)
    around = [cra.atom.pos for m in ns.find_atoms(centre, "\0", radius=14.0)
              if (cra := m.to_cra(model)).residue.entity_type == gemmi.EntityType.Polymer
              and not same_residue(cra.chain, cra.residue, lig_chain, res) and keep(cra.atom)]
    if not around:
        around = [m.to_cra(model).atom.pos for m in ns.find_atoms(centre, "\0", radius=14.0)]
    v = [centre.x - sum(p.x for p in around) / len(around), centre.y - sum(p.y for p in around) / len(around), centre.z - sum(p.z for p in around) / len(around)]
    n = math.sqrt(sum(c * c for c in v)) or 1
    return {"ligand": {"atoms": [[a.element.name, *rel(a.pos)] for a in lig], "bonds": bonds_within(lig)}, "residues": residues,
            "contacts": contacts, "approach": [round(c / n, 3) for c in v]}


def main():
    ligands = json.loads((RAW / "pdb_ligand_by_inchikey.json").read_text())
    by_skeleton = {}
    for key, codes in ligands.items():
        by_skeleton.setdefault(key[:23], []).extend(codes)
    targets = {t["id"]: t for t in json.loads((RAW / "chembl_targets.json").read_text())}
    out_file = RAW / "binding.json"
    summary = json.loads(out_file.read_text()) if out_file.exists() else {}
    (SITE / "bind").mkdir(exist_ok=True)
    (RAW / "pdb").mkdir(exist_ok=True)
    drugs = sorted((SITE / "data" / "drugs").glob("*.json"))
    for n, f in enumerate(drugs):
        d = json.loads(f.read_text())
        if d["id"] in summary or not d.get("structure") or not d["mechanisms"]:
            continue
        key = d["structure"]["inchikey"]
        codes, match = (ligands[key], "same InChIKey") if key in ligands else (by_skeleton.get(key[:23], []), "same structure, different protonation state")
        candidates = []
        for m in d["mechanisms"] if codes else []:
            t = targets.get(m["target_chembl_id"])
            if not t or not t["accessions"]:
                continue
            entry = best_entry(sorted(set(codes))[:6], t["accessions"])
            if entry:
                candidates.append((entry["resolution"], entry, t, m))
        # Evaluate candidate target complexes in order of best experimental resolution first
        candidates.sort(key=lambda x: x[0])
        result = None
        for _, entry, t, m in candidates:
            path = RAW / "pdb" / f"{entry['pdb_id']}.cif"
            if not path.exists():
                blob = get(f"https://files.rcsb.org/download/{entry['pdb_id'].upper()}.cif", binary=True)
                if not blob:
                    continue
                path.write_bytes(blob)
            try:
                site = binding_site(path, entry["ligand_code"])
            except Exception:
                site = None
            path.unlink(missing_ok=True)                       # entries are large; keep only what was cut out
            if site:
                (SITE / "bind" / f"{d['id']}.json").write_text(json.dumps(site, separators=(",", ":")))
                kinds = [c[3] for c in site["contacts"]]
                result = {**entry, "match": match, "target": t["name"], "target_chembl_id": t["id"], "organism": t["organism"], "mechanism": m["text"],
                          "residues": [r["label"] for r in site["residues"]], "polar": kinds.count("polar"), "nonpolar": kinds.count("nonpolar"),
                          "metal": kinds.count("metal"), "url": f"https://www.rcsb.org/structure/{entry['pdb_id'].upper()}", "checked": datetime.date.today().isoformat()}
                break
        if not result:
            (SITE / "bind" / f"{d['id']}.json").unlink(missing_ok=True)      # drop a site left over from an earlier run
        summary[d["id"]] = result
        if n % 50 == 0:
            out_file.write_text(json.dumps(summary)); print(n, "/", len(drugs), "sites:", sum(1 for v in summary.values() if v), flush=True)
    out_file.write_text(json.dumps(summary))
    print("done. binding sites:", sum(1 for v in summary.values() if v), "of", len(summary), "tried")


if __name__ == "__main__":
    main()
