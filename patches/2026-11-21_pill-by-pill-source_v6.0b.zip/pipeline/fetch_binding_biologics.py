"""Pipeline step: binding interfaces for antibody and protein medicines (the small-molecule step is fetch_binding.py).

For an antibody, antibody-drug conjugate, protein or enzyme medicine with a ChEMBL mechanism target:
  1. PDBe search for entries that contain the target protein (UniProt accession) and name the medicine in the entry title
     or in a chain name, best resolution first
  2. in the entry, the target chains are those PDBe maps to the accession; a chain counts as the medicine only if
       - its sequence shares a run of at least 30 identical residues with a ChEMBL sequence of the medicine, or
       - for an antibody with no sequence in ChEMBL only: PDBe's own name for that chain contains the antibody's name
     Entries where no chain can be tied to the medicine this way are skipped.
  3. every medicine residue with an atom within 4 A of a target residue forms the interface. Contacts use the same
     distance rules as fetch_binding.py (polar 3.5 A between N/O, non-polar 4.0 A between carbons), one per residue pair.
Output has the same shape as the small-molecule sites, so js/binding.js animates both: "ligand" holds the medicine's
interface residues (with labels), "residues" the target's. Merges into raw/binding.json and writes <site>/bind/<id>.json.
Usage: python3 pipeline/fetch_binding_biologics.py <raw dir> <site dir>
"""
import datetime, json, pathlib, re, sys, urllib.parse

import gemmi

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from fetch_binding import RAW, SITE, SEARCH, get, bonds_within, keep        # noqa: E402  (shares its helpers and arguments)

TYPES = {"Antibody", "Antibody drug conjugate", "Protein", "Enzyme"}
MAX_PAIRS, MIN_RUN = 16, 30


def name_clause(words):
    """PDBe's title and molecule_name are case-sensitive string fields: a wildcard on "semaglutide" does not find
    "Crystal structure of Semaglutide ...". Search lower-case, capitalised and upper-case forms of each word."""
    forms = {f for w in words for f in (w.lower(), w.capitalize(), w.upper())}
    return " OR ".join(f"title:*{f}* OR molecule_name:*{f}*" for f in sorted(forms))


def search(query, fields, rows=40):
    params = {"q": query, "fl": fields, "sort": "resolution asc", "rows": rows, "wt": "json"}
    return (get(SEARCH + urllib.parse.urlencode(params)) or {}).get("response", {}).get("docs", [])


def shared_run(a, b, n=MIN_RUN):
    """True if a and b share a run of n identical letters."""
    if len(a) < n or len(b) < n:
        return False
    grams = {a[i:i + n] for i in range(len(a) - n + 1)}
    return any(b[i:i + n] in grams for i in range(len(b) - n + 1))


def chain_sequence(chain):
    return gemmi.one_letter_code([r.name for r in chain.get_polymer()])


def interface(path, target_chains, is_drug_chain):
    st = gemmi.read_structure(str(path))
    st.setup_entities()
    model = st[0]
    drug_chains = [c.name for c in model if c.name not in target_chains and len(c.get_polymer()) >= 8 and is_drug_chain(c)]
    if not drug_chains:
        return None
    ns = gemmi.NeighborSearch(model, st.cell, 6).populate()
    pairs = {}                                               # (drug residue key, target residue key) -> best contact
    residues = {}
    for chain in model:
        if chain.name not in drug_chains:
            continue
        for res in chain.get_polymer():
            dkey = (chain.name, str(res.seqid), res.name)
            for a in res:
                if not keep(a):
                    continue
                for mark in ns.find_atoms(a.pos, "\0", radius=4.0):
                    cra = mark.to_cra(model)
                    if cra.chain.name not in target_chains or cra.residue.entity_type != gemmi.EntityType.Polymer or not keep(cra.atom):
                        continue
                    d = a.pos.dist(cra.atom.pos)
                    le, pe = a.element.name, cra.atom.element.name
                    kind = "polar" if le in ("N", "O") and pe in ("N", "O") and d <= 3.5 else "nonpolar" if le == "C" and pe in ("C", "S") and d <= 4.0 else None
                    if not kind:
                        continue
                    tkey = (cra.chain.name, str(cra.residue.seqid), cra.residue.name)
                    rank = (0 if kind == "polar" else 1, d)
                    if (dkey, tkey) not in pairs or rank < pairs[(dkey, tkey)][0]:
                        pairs[(dkey, tkey)] = (rank, kind, round(d, 2), a.name, cra.atom.name)
                        residues[dkey], residues[tkey] = res, cra.residue
    # an entry often holds several copies of the complex: keep the one copy whose target chain has the most contacts
    per_copy = {}
    for (dkey, tkey) in pairs:
        per_copy[tkey[0]] = per_copy.get(tkey[0], 0) + 1
    copy = max(per_copy, key=per_copy.get) if per_copy else None
    pairs = {k: v for k, v in pairs.items() if k[1][0] == copy}
    if len(pairs) < 4:
        return None
    drug_chains = sorted({k[0][0] for k in pairs})
    ranked, used_target = [], set()
    for (dkey, tkey), (rank, kind, d, dname, tname) in sorted(pairs.items(), key=lambda kv: kv[1][0]):
        if tkey in used_target:
            continue
        used_target.add(tkey)
        ranked.append((dkey, tkey, kind, d, dname, tname))
    polar = [c for c in ranked if c[2] == "polar"][:10]                       # a mix, as for small molecules
    chosen = polar + [c for c in ranked if c[2] == "nonpolar"][:MAX_PAIRS - len(polar)]
    label = lambda key: f"{key[2].capitalize()} {key[1]}"
    drug_keys = list(dict.fromkeys(c[0] for c in chosen))
    drug_atoms, owner, drug_bonds, names = [], [], [], []
    for i, key in enumerate(drug_keys):
        atoms = [a for a in residues[key] if keep(a)]
        offset = len(drug_atoms)
        drug_bonds += [[offset + p, offset + q] for p, q in bonds_within(atoms)]
        drug_atoms += atoms; owner += [i] * len(atoms); names += [(key, a.name) for a in atoms]
    centre = gemmi.Position(*(sum(getattr(a.pos, k) for a in drug_atoms) / len(drug_atoms) for k in "xyz"))
    rel = lambda p: [round(p.x - centre.x, 2), round(p.y - centre.y, 2), round(p.z - centre.z, 2)]
    target_keys = list(dict.fromkeys(c[1] for c in chosen))
    target = []
    for key in target_keys:
        atoms = [a for a in residues[key] if keep(a)]
        atom_names = [a.name for a in atoms]
        target.append({"label": label(key), "chain": key[0], "atoms": [[a.element.name, *rel(a.pos)] for a in atoms], "bonds": bonds_within(atoms),
                       "anchor": atom_names.index("CA") if "CA" in atom_names else 0, "_names": atom_names})
    contacts = [[names.index((dkey, dname)), target_keys.index(tkey), target[target_keys.index(tkey)]["_names"].index(tname), kind, d]
                for dkey, tkey, kind, d, dname, tname in chosen]
    all_target = [a.pos for t in target_keys for a in residues[t] if keep(a)]
    tc = [sum(getattr(p, k) for p in all_target) / len(all_target) for k in "xyz"]
    v = [centre.x - tc[0], centre.y - tc[1], centre.z - tc[2]]
    n = sum(c * c for c in v) ** 0.5 or 1
    for t in target:
        del t["_names"]
    return {"kind": "protein", "ligand": {"atoms": [[a.element.name, *rel(a.pos)] for a in drug_atoms], "bonds": drug_bonds, "owner": owner,
                                          "labels": [f"{label(k)} ({k[0]})" for k in drug_keys]},
            "residues": target, "contacts": contacts, "approach": [round(c / n, 3) for c in v], "drug_chains": drug_chains}


def main():
    targets = {t["id"]: t for t in json.loads((RAW / "chembl_targets.json").read_text())}
    summary = json.loads((RAW / "binding.json").read_text())
    (RAW / "pdb").mkdir(exist_ok=True)
    tried = found = 0
    for f in sorted((SITE / "data" / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        if d["type"] not in TYPES or not d["mechanisms"] or summary.get(d["id"]):
            continue
        word = re.sub(r"[^a-z]", "", d["name"].lower().split()[0])
        if len(word) < 7:                                        # short names match too much in titles
            continue
        sequences = [c["sequence"] for c in (d.get("sequence") or {}).get("components", []) if len(c.get("sequence") or "") >= MIN_RUN]
        tried += 1
        result = None
        for m in d["mechanisms"]:
            t = targets.get(m["target_chembl_id"])
            if not t or not t["accessions"]:
                continue
            accessions = " OR ".join(t["accessions"][:12])
            hits = search(f"uniprot_accession:({accessions}) AND ({name_clause([word])})", "pdb_id,resolution,experimental_method,title,chain_id", 12)
            seen = []
            for doc in hits:
                if doc["pdb_id"] in seen or not doc.get("resolution") or doc["resolution"] > 4.5:
                    continue
                seen.append(doc["pdb_id"])
                if len(seen) > 3:
                    break
                entities = search(f"pdb_id:{doc['pdb_id']}", "molecule_name,chain_id,uniprot_accession", 60)
                target_chains = {c for e in entities if set(e.get("uniprot_accession") or []) & set(t["accessions"]) for c in e.get("chain_id", [])}
                named = {c for e in entities if word in " ".join(e.get("molecule_name") or []).lower() for c in e.get("chain_id", [])} - target_chains
                path = RAW / "pdb" / f"{doc['pdb_id']}.cif"
                blob = get(f"https://files.rcsb.org/download/{doc['pdb_id'].upper()}.cif", binary=True)
                if not blob or not target_chains:
                    continue
                path.write_bytes(blob)
                try:
                    how = {}
                    def is_drug(chain):
                        if sequences and any(shared_run(chain_sequence(chain), s) for s in sequences):
                            how[chain.name] = "sequence"; return True
                        # a name alone is accepted only for antibodies (their names are unique) that have no ChEMBL sequence to test;
                        # "calcitonin" or "insulin" in a chain name does not say which calcitonin or insulin it is
                        if chain.name in named and not sequences and d["type"] in ("Antibody", "Antibody drug conjugate"):
                            how[chain.name] = "name"; return True
                        return False
                    site = interface(path, target_chains, is_drug)
                except Exception:
                    site = None
                path.unlink(missing_ok=True)
                if site:
                    by_sequence = any(how.get(c) == "sequence" for c in site["drug_chains"])
                    (SITE / "bind" / f"{d['id']}.json").write_text(json.dumps(site, separators=(",", ":")))
                    kinds = [c[3] for c in site["contacts"]]
                    result = {"pdb_id": doc["pdb_id"], "resolution": doc["resolution"], "method": (doc.get("experimental_method") or [""])[0], "title": doc.get("title"),
                              "ligand_code": "chain " + ", ".join(site["drug_chains"]), "kind": "protein",
                              "match": "chain sequence matches the ChEMBL sequence of the medicine" if by_sequence else
                                       f"chain named after the conjugate's antibody ({word}) in the PDB entry" if d["type"] == "Antibody drug conjugate" else
                                       "chain named after the medicine in the PDB entry",
                              "target": t["name"], "target_chembl_id": t["id"], "organism": t["organism"], "mechanism": m["text"],
                              "residues": [r["label"] for r in site["residues"]], "polar": kinds.count("polar"), "nonpolar": kinds.count("nonpolar"), "metal": 0,
                              "url": f"https://www.rcsb.org/structure/{doc['pdb_id'].upper()}", "checked": datetime.date.today().isoformat()}
                    break
            if result:
                break
        if result:
            summary[d["id"]] = result; found += 1
            print(d["id"], result["pdb_id"], result["target"][:40], result["match"][:22], flush=True)
        if tried % 25 == 0:
            (RAW / "binding.json").write_text(json.dumps(summary))
    (RAW / "binding.json").write_text(json.dumps(summary))
    print("done. biologic interfaces:", found, "of", tried, "tried")


if __name__ == "__main__":
    main()
