"""Step 2 of the data pipeline: merge raw sources into the drug catalogue used by the site and by app.py.

Inputs  raw/chembl_*.json, raw/drugsfda.json, raw/legacy/*.json, raw/pubchem.json (optional, from crosscheck_pubchem.py)
Outputs <out>/drugs/<id>.json   one file per medicine (loaded when its page opens)
        <out>/drug_index.json   compact list of every medicine (search, browse)
        <out>/drug_aliases.json other names -> medicine (brand names, international names)
        <out>/catalogue_stats.json counts used on landing pages and by the tests
One medicine = one ChEMBL parent molecule (its salts are folded in) or, if ChEMBL has no match,
one Drugs@FDA active-ingredient name. Every block carries the URL of the record it came from.
Usage: python3 pipeline/build_catalogue.py <raw dir> <out data dir>
"""
import datetime, collections, json, pathlib, re, sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from names import (SALT_WORDS, ELEMENTS, normalise_fda_name, ADC_PAYLOADS, INN_STEMS, NOT_STEM, classify_ema_type,  # noqa: E402
                   JP_FORM_WORDS, JP_COUNTER_IONS, NOT_A_SINGLE_MEDICINE, jp_clean, near)

RAW, OUT = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
META = json.loads((RAW / "meta.json").read_text())
CHECKED = META["fetched_on"]

TYPE_CODES = {"Small molecule": "sm", "Protein": "pr", "Antibody": "ab", "Antibody drug conjugate": "adc",
              "Enzyme": "en", "Oligonucleotide": "ol", "Oligosaccharide": "os", "Gene": "ge", "Cell": "ce",
              "Vaccine component": "va", "Radiopharmaceutical": "rp", "Allergen extract": "al", "Unknown": "un"}
AVAILABILITY = {2: "Over the counter", 1: "Prescription only", 0: "Discontinued", -1: "Unknown", -2: "Withdrawn"}
TERMINAL_CAPS = {"[ac]", "[am]", "[for]", "[nh2]", "[oh]"}


def load(name):
    return json.loads((RAW / name).read_text())


def https(url):
    return re.sub(r"^http://", "https://", url or "")


def slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def title_case(name):
    """ChEMBL and FDA names are upper case; make them readable without touching codes like 'F-18'."""
    return " ".join(w if re.search(r"\d", w) and len(w) <= 6 else w.capitalize() for w in name.split())


def refs(items, limit=3):
    seen, out = set(), []
    for r in items or []:
        url = https(r.get("ref_url"))
        if url and url not in seen and len(url) < 300:
            seen.add(url)
            out.append({"type": r.get("ref_type"), "url": url})
    return out[:limit]


def clean_biocomponent_sequence(seq):
    """Strip inline modification digits (e.g. X1, K1, S1 in tirzepatide/bulevirtide) and reject 3-letter dashed strings."""
    s = re.sub(r"(?<=[A-Z])\d+", "", (seq or "").strip())
    return s if re.fullmatch(r"[A-Z]+", s) else ""


def parse_helm_peptides(helm):
    """Extract N-to-C peptide chains from HELM notation, stripping terminal [ac]/[am] caps before checking unmodified residues."""
    chains = []
    for chain in re.findall(r"PEPTIDE\d+\{([^}]*)\}", helm or ""):
        raw_tokens = [t for t in chain.split(".") if t]
        core = list(raw_tokens)
        while core and core[0].lower() in TERMINAL_CAPS:
            core = core[1:]
        while core and core[-1].lower() in TERMINAL_CAPS:
            core = core[:-1]
        if core and all(re.fullmatch(r"[A-Z]", t) for t in core):
            chains.append({"type": "Protein", "note": "Read from HELM notation", "organism": None,
                           "sequence": "".join(core),
                           "residues": [t.strip("[]") for t in raw_tokens] if len(raw_tokens) != len(core) else None})
        elif core and all(re.fullmatch(r"[A-Z]|\[[A-Za-z0-9_\-()]+\]", t) for t in raw_tokens):
            chains.append({"type": "Protein", "note": "Read from HELM notation; bracketed names are modified residues",
                           "organism": None, "sequence": "", "residues": [t.strip("[]") for t in raw_tokens]})
    return [{k: v for k, v in c.items() if v is not None} for c in chains]


def reconcile_components(components, helm_chains):
    """Prefer HELM N-to-C order when ChEMBL biocomponents are C-to-N reversed or drop modified residues."""
    if not helm_chains:
        return components
    if not components:
        return helm_chains
    if len(components) == len(helm_chains):
        out = []
        for comp, hc in zip(components, helm_chains):
            seq = comp.get("sequence") or ""
            hseq = hc.get("sequence") or ""
            if hseq and seq != hseq:      # ChEMBL stores some biocomponent strings C-to-N (exenatide); its HELM notation is N-to-C
                comp = dict(comp, sequence=hseq, note="Read from HELM notation (ChEMBL's component string differs)")
            elif not hseq and hc.get("residues"):
                comp = dict(hc, organism=comp.get("organism"), note=hc["note"])
            out.append(comp)
        return out
    return components


# ---------------------------------------------------------------- ChEMBL: group salts under the parent molecule
molecules = load("chembl_molecules.json")
groups = collections.defaultdict(list)
for m in molecules:
    parent = (m.get("molecule_hierarchy") or {}).get("parent_chembl_id") or m["molecule_chembl_id"]
    groups[parent].append(m)


def representative(parent, members):
    for m in members:
        if m["molecule_chembl_id"] == parent:
            return m
    with_structure = [m for m in members if m.get("molecule_structures")]
    return sorted(with_structure or members, key=lambda m: len(m["pref_name"]))[0]


atc_by_code = {a["level5"]: a for a in load("chembl_atc.json")}
by_parent = lambda rows, key="parent_molecule_chembl_id": _group(rows, key)


def _group(rows, key):
    out = collections.defaultdict(list)
    for r in rows:
        out[r.get(key) or r["molecule_chembl_id"]].append(r)
    return out


target_names = {t["id"]: t["name"] for t in (load("chembl_targets.json") if (RAW / "chembl_targets.json").exists() else [])}
mechanisms, indications, warnings = (by_parent(load(f"chembl_{n}.json")) for n in ("mechanisms", "indications", "warnings"))
member_to_parent = {m["molecule_chembl_id"]: p for p, ms in groups.items() for m in ms}


def rows_for(table, parent, members):
    """Rows filed under the parent or under any salt in the group."""
    seen, out = set(), []
    for cid in [parent] + [m["molecule_chembl_id"] for m in members]:
        for r in table.get(cid, []):
            if id(r) not in seen:
                seen.add(id(r)); out.append(r)
    return out


def chembl_entry(parent, members):
    rep = representative(parent, members)
    cid = rep["molecule_chembl_id"]
    chembl_url = f"https://www.ebi.ac.uk/chembl/explore/compound/{cid}"
    names = collections.defaultdict(list)
    for m in members:
        for s in m["molecule_synonyms"]:
            if s["molecule_synonym"] not in names[s["syn_type"]]:
                names[s["syn_type"]].append(s["molecule_synonym"])
    structures, props = rep.get("molecule_structures") or {}, rep.get("molecule_properties") or {}
    entry = {
        "name": title_case(rep["pref_name"]),
        "type": rep["molecule_type"],
        "chembl_id": cid,
        "first_approval": min((m["first_approval"] for m in members if m["first_approval"]), default=None),
        "availability": AVAILABILITY.get(max(m["availability_type"] for m in members)),
        "flags": {k: any(m.get(f) in (1, True) for m in members) for k, f in (
            ("withdrawn", "withdrawn_flag"), ("boxed_warning", "black_box_warning"), ("prodrug", "prodrug"),
            ("first_in_class", "first_in_class"), ("orphan", "orphan"), ("oral", "oral"),
            ("parenteral", "parenteral"), ("topical", "topical"))},
        "names": {
            "inn": names["INN"][:3], "usan": names["USAN"][:3], "ban": names["BAN"][:3], "jan": names["JAN"][:3],
            "trade": sorted(set(names["TRADE_NAME"]), key=str.lower)[:24], "research_codes": names["RESEARCH_CODE"][:6],
            "salt_forms": sorted(title_case(m["pref_name"]) for m in members if m is not rep)[:12]},
        "stem": ({"stem": rep["usan_stem"], "meaning": rep["usan_stem_definition"]} if rep.get("usan_stem") else None),
        "atc": [], "mechanisms": [], "indications": [], "warnings": [],
        "sources": [{"label": f"ChEMBL {cid} ({META['chembl_release']})", "url": chembl_url}],
    }
    for code in sorted({c for m in members for c in m["atc_classifications"]}):
        a = atc_by_code.get(code)
        if a:
            entry["atc"].append({"code": code, "levels": [a["level1_description"].capitalize(), a["level2_description"].capitalize(),
                                                          a["level3_description"].capitalize(), a["level4_description"]],
                                 "url": f"https://atcddd.fhi.no/atc_ddd_index/?code={code}"})
    seen = set()
    for r in rows_for(mechanisms, parent, members):
        if r["mechanism_of_action"] and r["mechanism_of_action"] not in seen:
            seen.add(r["mechanism_of_action"])
            entry["mechanisms"].append({"text": r["mechanism_of_action"], "action": r["action_type"],
                                        "target_chembl_id": r["target_chembl_id"], "target_name": target_names.get(r["target_chembl_id"]),
                                        "refs": refs(r["mechanism_refs"])})
    seen = set()
    order = {"DailyMed": 0, "FDA": 1, "EMA": 2, "ATC": 3}
    for r in rows_for(indications, parent, members):
        term = r["mesh_heading"] or r["efo_term"]
        # keep only uses backed by a label or regulator reference; ChEMBL also lists uses seen only in phase 4 trials
        best = sorted((x for x in r["indication_refs"] if x["ref_type"] in order), key=lambda x: order[x["ref_type"]])
        if term and best and term not in seen:
            seen.add(term)
            entry["indications"].append({"term": term, "refs": refs(best, 1)})
    entry["indication_count"] = len(entry["indications"])
    entry["indications"] = entry["indications"][:40]
    for r in rows_for(warnings, parent, members):
        entry["warnings"].append({"type": r["warning_type"], "class": r["warning_class"], "country": r["warning_country"],
                                  "year": r["warning_year"], "note": r["warning_description"], "refs": refs(r["warning_refs"], 2)})
    if structures.get("canonical_smiles"):
        entry["structure"] = {"smiles": structures["canonical_smiles"], "inchikey": structures["standard_inchi_key"],
                              "inchi": structures["standard_inchi"] if len(structures.get("standard_inchi") or "") < 700 else None,
                              "source": "ChEMBL", "source_url": chembl_url, "checked": CHECKED}
        entry["properties"] = {k: props.get(f) for k, f in (
            ("formula", "full_molformula"), ("weight", "full_mwt"), ("alogp", "alogp"), ("hbd", "hbd"), ("hba", "hba"),
            ("psa", "psa"), ("rotatable_bonds", "rtb"), ("ro5_violations", "num_ro5_violations"),
            ("aromatic_rings", "aromatic_rings"), ("heavy_atoms", "heavy_atoms"))}
    elif props.get("full_molformula"):
        entry["properties"] = {"formula": props["full_molformula"], "weight": props.get("full_mwt")}
    bio = next((m["biotherapeutic"] for m in [rep] + members if m.get("biotherapeutic")), None)
    helm = next((m["helm_notation"] for m in [rep] + members if m.get("helm_notation")), None)
    helm_chains = parse_helm_peptides(helm) if helm else []
    components = []
    for c in (bio or {}).get("biocomponents", []):
        cleaned = clean_biocomponent_sequence(c.get("sequence"))
        if cleaned:
            components.append({"type": c["component_type"], "note": c["description"], "organism": c["organism"], "sequence": cleaned})
    components = reconcile_components(components, helm_chains)
    if components or helm:
        entry["sequence"] = {"helm": helm, "description": (bio or {}).get("description"), "components": components,
                             "source": "ChEMBL", "source_url": chembl_url, "checked": CHECKED}
    elif (bio or {}).get("description"):
        entry["biologic_description"] = {"text": bio["description"], "source": "ChEMBL", "source_url": chembl_url}
    ema = sorted({c["xref_id"] for m in members for c in m["cross_references"] if c["xref_src"] == "EMA"})
    entry["world"] = {"ema_epar": [{"name": x.split("/")[-1], "url": f"https://www.ema.europa.eu/en/medicines/{x}"} for x in ema][:8]}
    entry["_match"] = {rep["pref_name"].upper()} | {m["pref_name"].upper() for m in members} | {
        s["molecule_synonym"].upper() for m in members for s in m["molecule_synonyms"]}
    return entry


entries = [chembl_entry(p, ms) for p, ms in groups.items()]
# cross-member C->N reversal check (e.g. ziconotide vs ziconotide-acetate in ChEMBL)
seq_by_len = collections.defaultdict(list)
for e in entries:
    for c in (e.get("sequence") or {}).get("components", []):
        if c.get("sequence") and len(c["sequence"]) >= 8:
            seq_by_len[len(c["sequence"])].append((e, c))
for length, group in seq_by_len.items():
    for e, c in group:
        s = c["sequence"]
        if not (e.get("sequence") or {}).get("helm"):
            for other_e, other_c in group:
                if other_e is not e and other_c["sequence"] == s[::-1] and (other_e.get("sequence") or {}).get("helm"):
                    c["sequence"] = other_c["sequence"]
                    break

name_to_entry = {}
for e in entries:                      # exact names first, so a synonym never steals another drug's own name
    name_to_entry.setdefault(e["name"].upper(), e)
for e in entries:
    for n in e["_match"]:
        name_to_entry.setdefault(n, e)

# ---------------------------------------------------------------- Drugs@FDA: every application, filed under its ingredient(s)


def fda_date(s):
    return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if s and len(s) == 8 else None


fda_apps = load("drugsfda.json")
fda_only, app_count, novel_by_year = {}, 0, collections.Counter()
for a in fda_apps:
    products = a.get("products") or []
    if not products:
        continue
    app_count += 1
    number = a["application_number"]
    origs = [s for s in a.get("submissions", []) if s.get("submission_type") == "ORIG" and s.get("submission_status") in ("AP", "TA")]
    date = min((fda_date(s.get("submission_status_date")) for s in origs if s.get("submission_status_date")), default=None)
    is_nme = any("New Molecular Entity" in (s.get("submission_class_code_description") or "") for s in origs)
    if is_nme and date:
        novel_by_year[date[:4]] += 1
    ingredient_names = sorted({i["name"].strip() for p in products for i in p.get("active_ingredients", []) if i.get("name")})
    statuses = {p.get("marketing_status") for p in products}
    record = {"number": number, "kind": number[:3].replace("AND", "ANDA"), "sponsor": a.get("sponsor_name"),
              "brands": sorted({p["brand_name"] for p in products if p.get("brand_name")})[:4], "date": date, "nme": is_nme,
              "forms": sorted({(p.get("dosage_form") or "").capitalize() for p in products if p.get("dosage_form")})[:4],
              "routes": sorted({(p.get("route") or "").capitalize() for p in products if p.get("route")})[:4],
              "status": ("Prescription" if "Prescription" in statuses else "Over-the-counter" if "Over-the-counter" in statuses
                         else "Tentative approval" if "None (Tentative Approval)" in statuses else "Discontinued"),
              "with": [],
              "url": f"https://www.accessdata.fda.gov/scripts/cder/daf/index.cfm?event=overview.process&ApplNo={number[-6:]}"}
    targets = []
    for raw_name in ingredient_names:
        e = next((name_to_entry[k] for k in normalise_fda_name(raw_name) if k in name_to_entry), None)
        if e is None:
            parts = [x for x in re.split(r",|\bAND\b|\|\||;", raw_name.upper()) if x.strip()]
            found = [next((name_to_entry[k] for k in normalise_fda_name(x) if k in name_to_entry), None) for x in parts]
            if len(parts) > 1 and all(found):       # a combination typed as one string: file it under each ingredient
                targets += [f for f in found if f not in targets]
                continue
        if e is None:
            key = normalise_fda_name(raw_name)[1]
            e = fda_only.get(key)
            if e is None:
                e = fda_only[key] = {"name": title_case(key), "type": "Unknown", "chembl_id": None, "first_approval": None,
                                     "availability": None, "flags": {}, "names": {}, "stem": None, "atc": [], "mechanisms": [],
                                     "indications": [], "indication_count": 0, "warnings": [], "world": {"ema_epar": []},
                                     "sources": [], "_match": {key}, "_fda_only": True}
        if e not in targets:
            targets.append(e)
    for e in targets:
        rec = dict(record, **{"with": [t["name"] for t in targets if t is not e][:5]})
        e.setdefault("_apps", []).append(rec)
entries += list(fda_only.values())

for e in entries:
    apps = sorted(e.pop("_apps", []), key=lambda r: (r["date"] or "9999", r["number"]))
    if not apps:
        e["us"] = None
        continue
    originals = [r for r in apps if r["kind"] != "ANDA"]
    generics = [r for r in apps if r["kind"] == "ANDA"]
    dated = [r["date"] for r in apps if r["date"]]
    e["us"] = {
        "first_date": min(dated) if dated else None,
        "first_generic_date": min((r["date"] for r in generics if r["date"]), default=None),
        "counts": {"NDA": sum(r["kind"] == "NDA" for r in apps), "BLA": sum(r["kind"] == "BLA" for r in apps), "ANDA": len(generics)},
        "sponsors": len({r["sponsor"] for r in apps}),
        # brand names of single-ingredient products first, so a combination product's brand is not shown as this drug's name
        "brands": [b for b, _ in collections.Counter(b for r in ([x for x in originals if not x["with"]] or originals or apps)
                                                     for b in r["brands"]).most_common(10)],
        "status": ("Prescription" if any(r["status"] == "Prescription" for r in apps) else
                   "Over-the-counter" if any(r["status"] == "Over-the-counter" for r in apps) else
                   "Tentative approval" if any(r["status"] == "Tentative approval" for r in apps) else "Discontinued"),
        "application_cols": ["number", "kind", "sponsor", "brand", "date", "status", "combined_with"],
        "applications": [[r["number"], r["kind"], r["sponsor"], ", ".join(r["brands"][:2]), r["date"], r["status"], ", ".join(r["with"])]
                         for r in originals[:30] + generics[:10]],
        "forms": sorted({f for r in apps for f in r["forms"]})[:8], "routes": sorted({f for r in apps for f in r["routes"]})[:8],
        "application_url_template": "https://www.accessdata.fda.gov/scripts/cder/daf/index.cfm?event=overview.process&ApplNo={last6}",
        "applications_total": len(apps),
        "source": "FDA Drugs@FDA via openFDA", "source_url": "https://www.accessdata.fda.gov/scripts/cder/daf/",
        "data_date": META.get("drugsfda_last_updated")}
    e["sources"].append({"label": f"FDA Drugs@FDA (openFDA file dated {META.get('drugsfda_last_updated')})",
                         "url": originals[0]["url"] if originals else apps[0]["url"]})

# ---------------------------------------------------------------- European Union: EMA's table of centrally evaluated medicines
ema_file = RAW / "ema_medicines.json"
ema = json.loads(ema_file.read_text()) if ema_file.exists() else {"products": [], "generated": None, "page": None}
salt_form_of = {}                      # "OLEZARSEN" -> the entry named "Olezarsen Sodium"
for e in entries:
    for candidate in {e["name"].upper()} | set(e.get("_match", ())):
        words = candidate.split()
        while len(words) > 1 and words[-1] in SALT_WORDS:
            words = words[:-1]
            salt_form_of.setdefault(" ".join(words), e)
ema_only = {}
extra_file = RAW / "extra_chembl.json"           # ChEMBL records for names only a regulator lists (fetch_extra_chembl.py)
extra_chembl = json.loads(extra_file.read_text()) if extra_file.exists() else {}
extra_checked = datetime.date.fromtimestamp(extra_file.stat().st_mtime).isoformat() if extra_file.exists() else CHECKED
chembl_to_entry = {e["chembl_id"]: e for e in entries if e.get("chembl_id")}
same_molecule = set()                                   # (regulator's name, catalogue name) pairs filed together by ChEMBL identity
shared_brand = set()                                    # (EMA's name, catalogue name, brand) filed together because the product is the same
us_brand_owner = collections.defaultdict(list)          # first word of a US brand -> entries whose Drugs@FDA record carries it
for e in entries:
    for b in (e.get("us") or {}).get("brands") or []:
        w = re.sub(r"[^A-Z0-9]", "", b.upper().split(" ")[0])
        if len(w) >= 5 and e not in us_brand_owner[w]:
            us_brand_owner[w].append(e)


def by_shared_brand(name, product):
    """EMA's INN column names the active moiety ("isavuconazole"); Drugs@FDA names the substance ("isavuconazonium sulfate").
    When EMA's product name is a US brand of exactly one medicine whose name begins with the same six letters, it is that medicine."""
    w = re.sub(r"[^A-Z0-9]", "", product.upper().split(" ")[0])
    owners = [o for o in us_brand_owner.get(w, []) if o["name"][:6].lower() == name[:6].lower()]
    return owners[0] if len(owners) == 1 else None


def by_chembl_identity(name):
    """The catalogue entry that is the same ChEMBL molecule as this regulator's name, if fetch_extra_chembl.py found one."""
    c = extra_chembl.get(re.sub(r"\s+", " ", name).strip().upper())
    return chembl_to_entry.get(c["chembl_id"]) if c else None


def resolve_ema_substance(substance):
    clean = re.sub(r"\s+", " ", substance.replace("\xa0", " ")).strip()
    bare = re.sub(r"\s+", " ", re.sub(r"\s*\([^)]*\)\s*", " ", clean)).strip()
    keys = normalise_fda_name(clean) + normalise_fda_name(bare)
    return (next((name_to_entry[k] for k in keys if k in name_to_entry), None)
            or next((salt_form_of[k] for k in keys if k in salt_form_of), None)
            or next((fda_only[k] for k in keys if k in fda_only), None))


brand_map = {}                                          # decided over all products first, so every product with that name follows
for product in ema["products"]:
    for substance in product["substances"]:
        clean = re.sub(r"\s+", " ", substance.replace("\xa0", " ")).strip()
        if clean.upper() not in brand_map and not resolve_ema_substance(clean) and not by_chembl_identity(clean):
            owner = by_shared_brand(clean, product["product"])
            if owner is not None:
                brand_map[clean.upper()] = owner
                shared_brand.add((clean, owner["name"], product["product"]))
for product in ema["products"]:
    targets = []
    for substance in product["substances"]:
        clean = re.sub(r"\s+", " ", substance.replace("\xa0", " ")).strip()
        e = resolve_ema_substance(clean)
        if e is None:
            parts = [x.strip() for x in re.split(r",|\band\b|\bAND\b|/|\|\|", clean) if x.strip()]
            found = [resolve_ema_substance(x) for x in parts]
            if len(parts) > 1 and all(found):
                targets += [f for f in found if f not in targets]
                continue
        if e is None:
            e = by_chembl_identity(clean)
            if e is not None:
                same_molecule.add((clean, e["name"]))
        if e is None:
            e = brand_map.get(clean.upper())
        if e is None:
            key = clean.upper()
            e = ema_only.get(key)
            if e is None:
                kind, basis = classify_ema_type(clean, product)
                e = ema_only[key] = {"name": clean[0].upper() + clean[1:], "type": kind, "type_basis": basis,
                                     "chembl_id": None, "first_approval": None, "availability": None, "flags": {}, "names": {}, "stem": None, "atc": [],
                                     "mechanisms": [], "indications": [], "indication_count": 0, "warnings": [], "world": {"ema_epar": []},
                                     "sources": [], "us": None, "_match": {key}, "_ema_only": True}
                a = atc_by_code.get(product["atc"] or "")
                if a:
                    e["atc"].append({"code": product["atc"], "levels": [a["level1_description"].capitalize(), a["level2_description"].capitalize(),
                                                                        a["level3_description"].capitalize(), a["level4_description"]],
                                     "url": f"https://atcddd.fhi.no/atc_ddd_index/?code={product['atc']}"})
        if e not in targets:
            targets.append(e)
    for e in targets:
        e.setdefault("_eu", []).append(dict(product, combined_with=[t["name"] for t in targets if t is not e][:5]))
entries += list(ema_only.values())
for e in ema_only.values():                    # later sources (Canada, Japan) can then match medicines that only EMA lists
    for k in e["_match"]:
        name_to_entry.setdefault(k, e)
STATUS_ORDER = ["Authorised", "Suspended", "Opinion", "Withdrawn", "Lapsed", "Expired", "Revoked", "Refused", "Application withdrawn", "Withdrawn from rolling review"]
for e in entries:
    products = sorted(e.pop("_eu", []), key=lambda x: (x["authorised"] or "9999", x["product"]))
    if not products:
        e["eu"] = None
        continue
    dates = [x["authorised"] for x in products if x["authorised"]]
    statuses = {x["status"] for x in products}
    e["eu"] = {"status": next(st for st in STATUS_ORDER + sorted(statuses) if st in statuses), "first_authorised": min(dates) if dates else None,
               "products_total": len(products), "authorised_now": sum(x["status"] == "Authorised" for x in products),
               "product_cols": ["product", "number", "status", "authorised", "ended", "holder", "flags", "combined_with", "url"],
               "products": [[x["product"], x["number"], x["status"], x["authorised"], x["ended"] or x["refused"] or x["application_withdrawn"], x["holder"],
                             ", ".join(x["flags"]), ", ".join(x["combined_with"]), x["url"]] for x in products[:40]],
               "areas": sorted({a.strip() for x in products for a in (x["area"] or "").split(";") if a.strip()})[:12],
               "scope": "Medicines evaluated through the EU centralised procedure. Products licensed by a single EU country are not in this table.",
               "source": "EMA medicines data table", "source_url": ema["page"], "data_date": ema["generated"]}
    e["sources"].append({"label": f"EMA medicines data table (generated {ema['generated']})", "url": products[0]["url"]})

# ---------------------------------------------------------------- Canada (Health Canada DPD) and Japan (PMDA list): attached, never new entries


def resolve_parts(text):
    """Entries for one ingredient string; a combination ("A/B", "A and B") resolves only if every part does."""
    e = resolve_ema_substance(text)
    if e:
        return [e]
    parts = [x.strip() for x in re.split(r"/|\band\b|\bAND\b|,", text) if x.strip()]
    found = [resolve_ema_substance(x) for x in parts] if len(parts) > 1 else [None]
    return found if all(found) else []


ca_file, jp_file = RAW / "canada_dpd.json", RAW / "japan_approvals.json"
dpd = json.loads(ca_file.read_text()) if ca_file.exists() else {"products": []}
CA_ORDER = ["Marketed", "Approved", "Restricted Access", "Dormant", "Cancelled Post Market", "Cancelled Pre Market", "Cancelled (Unreturned Annual)",
            "Cancelled (Safety Issue)", "Cancelled (Transitioned To Biocides)", "Authorization By Interim Order Revoked", "Authorization By Interim Order Expired"]
ca_unmatched = collections.Counter()
ingredient_cache = {}
for prod in dpd["products"]:
    targets = []
    for ing in prod["ingredients"]:
        if ing not in ingredient_cache:
            # "MAGNESIUM (MAGNESIUM OXIDE)": the part in brackets is the substance actually in the product, so only it is
            # matched; matching the bare element would file magnesium oxide under any magnesium salt the catalogue has
            m = re.fullmatch(r"(.+?) \((.+)\)", ing)
            ingredient_cache[ing] = resolve_parts(m.group(2)) if m else resolve_parts(ing)
        found = ingredient_cache[ing]
        if not found:
            ca_unmatched[ing] += 1
        targets += [f for f in found if f not in targets]
    for e in targets:
        e.setdefault("_ca", []).append(dict(prod, combined_with=[x["name"] for x in targets if x is not e][:4]))
    if len(targets) == 1 and prod["status"] == "Marketed" and len(prod["ingredients"]) == 1:
        e = targets[0]
        if e["name"].upper().split()[0] not in prod["brand"]:            # "TEVA-ATORVASTATIN" adds nothing to a search for atorvastatin
            e.setdefault("_brands", set()).add(re.sub(r"\s+\d.*$", "", prod["brand"]).strip())


def ca_date(d):
    """DPD gives many older products 31 December of a year; show only the year for those."""
    return (d[:4], True) if d and d.endswith("-12-31") else (d, False)


for e in entries:
    prods = e.pop("_ca", [])
    if not prods:
        e["ca"] = None
        continue
    prods.sort(key=lambda x: (CA_ORDER.index(x["status"]) if x["status"] in CA_ORDER else 99, x["first_marketed"] or "9999", x["brand"]))
    dated = sorted(x["first_marketed"] for x in prods if x["first_marketed"])
    statuses = {x["status"] for x in prods}
    first, year_only = ca_date(dated[0]) if dated else (None, False)
    e["ca"] = {"status": next((st for st in CA_ORDER if st in statuses), sorted(s for s in statuses if s)[0] if any(statuses) else None),
               "first_marketed": first, "first_marketed_year_only": year_only,
               "products_total": len(prods), "marketed_now": sum(x["status"] == "Marketed" for x in prods),
               "product_cols": ["brand", "din", "status", "first_marketed", "company", "combined_with", "url"],
               "products": [[x["brand"], x["din"], x["status"], ca_date(x["first_marketed"])[0], x["company"], ", ".join(x["combined_with"]),
                             dpd["product_url"].format(code=x["code"])] for x in prods[:40]],
               "scope": "Human and radiopharmaceutical products with a Drug Identification Number in Health Canada's Drug Product Database, "
                        "including cancelled ones. The date is when a product was first marketed, not when it was approved; "
                        "where Health Canada records only a year (31 December), only the year is shown.",
               "source": "Health Canada Drug Product Database", "source_url": "https://health-products.canada.ca/dpd-bdpp/",
               "licence": dpd.get("licence"), "data_date": dpd.get("fetched_on")}
    e["sources"].append({"label": f"Health Canada Drug Product Database (downloaded {dpd.get('fetched_on')})", "url": e["ca"]["products"][0][6]})

jpl = json.loads(jp_file.read_text()) if jp_file.exists() else {"rows": []}


catalogue_names = {k for k in name_to_entry} | {k for k in salt_form_of} | {k for k in fda_only}
brand_owner = {}                                # first word of a brand name -> the entry whose US or EU record carries it
for e in entries:
    for b in ((e.get("us") or {}).get("brands") or []) + [p[0] for p in ((e.get("eu") or {}).get("products") or [])]:
        w = re.sub(r"[^A-Z0-9]", "", (b or "").upper().split(" ")[0]) if b else ""
        if len(w) >= 5:
            brand_owner.setdefault(w, e)
jp_unmatched, jp_only, jp_spelling, jp_brand_seen, jp_combination = collections.Counter(), {}, {}, {}, set()
for row in jpl["rows"]:
    texts = [x.strip() for x in re.split(r"\(?\d\)\s*|\b\d:\s*", row["ingredient"]) if x.strip(" (")] or [row["ingredient"]]
    targets = []
    for text in texts:
        found = resolve_parts(text) or resolve_parts(jp_clean(text))
        if not found:
            same = by_chembl_identity(normalise_fda_name(jp_clean(text))[-1].title())
            if same is not None:
                same_molecule.add((text, same["name"])); found = [same]
        if not found:
            jp_unmatched[text] += 1
            name = normalise_fda_name(jp_clean(text))[-1]          # without salt words: "ACOTIAMIDE HYDROCHLORIDE" -> "ACOTIAMIDE"
            words = name.split()
            # A new active ingredient that no other source lists becomes its own entry, if its name is a plain INN-like name
            if row["new_active_ingredient"] and 1 <= len(words) <= 3 and all(re.fullmatch(r"[A-Z][A-Z0-9-]*", w) for w in words) \
                    and not NOT_A_SINGLE_MEDICINE.search(name) and len(name) >= 6:
                close = next((k for k in catalogue_names if len(k) >= 6 and near(k, name)), None)
                if close:                                            # most likely PMDA's spelling of a medicine already listed: neither attach nor add
                    jp_spelling[name] = close
                    continue
                if len(words) > 1 and any(len(w) >= 5 and resolve_ema_substance(w) for w in words):
                    jp_combination.add(name)                         # a combination of listed medicines ("MIFEPRISTONE MISOPROSTOL"): not a new entry
                    continue
                owner = next((brand_owner[w] for w in (re.sub(r"[^A-Z0-9]", "", b.upper().split(" ")[0]) for b in row["brands"]) if w in brand_owner), None)
                if owner:                                            # same brand as a medicine already listed, under a Japanese name (JAN): not a new entry
                    jp_brand_seen[name] = owner["name"]
                    continue
                e = jp_only.get(name)
                if e is None:
                    kind, basis = classify_ema_type(name.lower(), {})
                    e = jp_only[name] = {"name": name.title() if " " in name else name.capitalize(), "type": kind, "type_basis": basis,
                                         "chembl_id": None, "first_approval": None, "availability": None, "flags": {}, "names": {}, "stem": None, "atc": [],
                                         "mechanisms": [], "indications": [], "indication_count": 0, "warnings": [], "world": {"ema_epar": []},
                                         "sources": [], "us": None, "eu": None, "ca": None, "_match": {name}, "_jp_only": True}
                found = [e]
        targets += [f for f in found if f not in targets]
    for e in targets:
        e.setdefault("_jp", []).append(row)
    if len(targets) == 1:
        for b in row["brands"][:3]:
            words = []
            for w in b.split():
                if re.search(r"\d", w) or w.strip(".").lower() in JP_FORM_WORDS:
                    break
                words.append(w)
            if words and len(" ".join(words)) >= 4:
                targets[0].setdefault("_brands", set()).add(" ".join(words))
entries += list(jp_only.values())
for e in list(ema_only.values()) + list(jp_only.values()):
    c = extra_chembl.get(e["name"].upper())
    if not c or c["chembl_id"] in chembl_to_entry:
        continue
    url = f"https://www.ebi.ac.uk/chembl/explore/compound/{c['chembl_id']}"
    phase = f"ChEMBL records phase {int(float(c['max_phase']))} for it, not this approval" if c.get("max_phase") else "ChEMBL does not record an approval for it"
    e["chembl_ref"] = {"id": c["chembl_id"], "url": url, "max_phase": c.get("max_phase"), "matched_by": c["matched_by"]}
    if c.get("molecule_type") and c["molecule_type"] != "Unknown" and e["type"] == "Unknown":
        e["type"], e["type_basis"] = c["molecule_type"], f"ChEMBL molecule type ({c['chembl_id']})"
    if c.get("structure"):
        e["structure"] = dict(c["structure"], source="ChEMBL", source_url=url, checked=extra_checked, note=phase)
        e["properties"] = c.get("properties")
    if c["mechanisms"] and not e["mechanisms"]:
        e["mechanisms"] = [dict(m, refs=m["refs"] or [{"type": "ChEMBL", "url": url}]) for m in c["mechanisms"]]
    e["sources"].append({"label": f"ChEMBL {c['chembl_id']}: structure and mechanism only ({phase})", "url": url})
for e in entries:
    rows = sorted(e.pop("_jp", []), key=lambda r: r["date"])
    if not rows:
        e["jp"] = None
        continue
    nai = [r["date"] for r in rows if r["new_active_ingredient"]]
    e["jp"] = {"first_new_ingredient": nai[0] if nai else None, "first_listed": rows[0]["date"], "entries_total": len(rows),
               "entry_cols": ["date", "brands", "applicant", "kind", "new_active_ingredient", "orphan", "category"],
               "entries": [[r["date"], "; ".join(r["brands"][:3]) + (" …" if len(r["brands"]) > 3 else ""), "; ".join(dict.fromkeys(r["applicants"]))[:120],
                            "/".join(r["kinds"]), r["new_active_ingredient"], r["orphan"], r["category"]] for r in rows[:30]],
               "scope": "New-drug approvals and partial changes reviewed by PMDA since April 2004. A date marked as a new active ingredient is the "
                        "ingredient's first approval in Japan; other dates are later changes. Medicines approved in Japan before April 2004 "
                        "appear only through later changes, and generics are not listed.",
               "source": jpl.get("title"), "source_url": jpl.get("pdf"), "page": jpl.get("page"), "data_date": jpl.get("fetched_on")}
    e["sources"].append({"label": f"Created by editing PMDA's {jpl.get('title')}", "url": jpl.get("pdf")})
(RAW / "canada_unmatched.json").write_text(json.dumps(ca_unmatched.most_common(), indent=0))
(RAW / "japan_unmatched.json").write_text(json.dumps(jp_unmatched.most_common(), indent=0))

# ---------------------------------------------------------------- curated overlays carried over from v4 (all sourced)


def legacy(name):
    f = RAW / "legacy" / f"{name}.json"
    return json.loads(f.read_text()) if f.exists() else []


def find(name):
    for k in normalise_fda_name(name):
        if k in name_to_entry:
            return name_to_entry[k]
    return fda_only.get(normalise_fda_name(name)[1])


for p in legacy("PEPTIDES_APPROVED"):
    e = find(p["gene"])
    if e:
        e["peptide_note"] = {"chemistry": p["mod_chem"], "target": p["target"], "route": p["route"], "use": p["ind"],
                             "source": p["src_title"], "source_url": p["url"]}
for g in legacy("GENE_MEDICINES"):
    e = find(g["gene"])
    if e:
        e["oligo_note"] = {"modality": g["mod"], "target": g["target"], "use": g["ind"], "status": g["status"],
                           "source": "FDA label or approval document", "source_url": g["url"]}
for key, lab in (legacy("DRUG_LABELS") or {}).items():
    e = find(key)
    if e:
        e["label_note"] = {"what_for": lab["indication"], "how": lab["mechanism"], "warning": lab["warning"],
                           "source": "FDA prescribing label", "source_url": lab["label_url"]}
for e in entries:
    e["stories"] = []
for d in legacy("MEDICAL_DISCOVERIES"):
    for e in entries:
        n = e["name"].lower()
        if len(n) >= 6 and " " not in n and re.search(rf"\b{re.escape(n)}\b", d["title"].lower()):
            e["stories"].append({"title": f"{d['year']}: {d['title']}", "who": d["discoverers"], "simple": d["simple"],
                                 "expert": d["expert"], "source": d["source_title"], "source_url": d["source_url"]})
for t in legacy("DISCOVERY_TIMELINES"):
    e = find(t["q"])
    if e:
        e["stories"].append({"title": f"{t['drug']}: {t['span']}", "who": None, "simple": t["sp"], "expert": t["sp"],
                             "source": "Primary source", "source_url": t["src"]})
# v5.18: where single medicines come from (curated, each statement from the sources listed with it)
_origin = json.loads((pathlib.Path(__file__).parent / "origin_stories.json").read_text(encoding="utf-8"))
for o in _origin["stories"]:
    e = find(o["medicine"])
    if e is None:
        sys.exit(f"origin_stories.json: {o['medicine']} is not in the catalogue")
    if not o["sources"] or not all(s["url"].startswith("https://") for s in o["sources"]):
        sys.exit(f"origin_stories.json: {o['medicine']} needs https source links")
    e["origin"] = {"category": o["category"], "simple": o["simple"], "expert": o["expert"], "sources": o["sources"], "checked": o.get("checked", _origin["checked"])}

# ---------------------------------------------------------------- PubChem cross-check (optional file)
pubchem_file = RAW / "pubchem.json"
pubchem = json.loads(pubchem_file.read_text()) if pubchem_file.exists() else {"by_inchikey": {}, "by_name": {}}
for e in entries:
    s = e.get("structure")
    if s:
        cid = pubchem["by_inchikey"].get(s["inchikey"])
        s["pubchem_cid"] = cid
        s["cross_check"] = ("Same InChIKey found in PubChem" if cid else "Not found in PubChem by InChIKey")
        if cid:
            e["sources"].append({"label": f"PubChem CID {cid}", "url": f"https://pubchem.ncbi.nlm.nih.gov/compound/{cid}"})
    elif e.get("_fda_only"):
        hit = pubchem["by_name"].get(e["name"].upper())
        if hit:
            url = f"https://pubchem.ncbi.nlm.nih.gov/compound/{hit['cid']}"
            e["structure"] = {"smiles": hit["smiles"], "inchikey": hit["inchikey"], "inchi": None, "source": "PubChem (matched by name)",
                              "source_url": url, "checked": CHECKED, "pubchem_cid": hit["cid"], "cross_check": "Name match only; not cross-checked"}
            e["properties"] = {"formula": hit.get("formula"), "weight": hit.get("weight")}
            e["type"] = "Small molecule"
            e["sources"].append({"label": f"PubChem CID {hit['cid']}", "url": url})

# ---------------------------------------------------------------- ids, then blocks from later pipeline steps (keyed by id or CID)
# WHO Model List of Essential Medicines, from WHO's eEML (fetch_who_eml.py). A name is matched the same way as EMA's;
# "Insulin (human, intermediate-acting)" is tried as "insulin human" and never as bare "insulin"; "Hydroxyurea (hydroxycarbamide)"
# tries both names. Class entries WHO lists by group ("Insulin (analogue, ...)") and vaccines are not matched to one medicine.
eml_file = RAW / "who_eml.json"
eml = json.loads(eml_file.read_text(encoding="utf-8")) if eml_file.exists() else {"medicines": []}
eml_unmatched = []


def eml_candidates(part):
    m = re.match(r"^(.*?)\s*\(([^)]*)\)\s*$", part)
    if not m:
        return [part]
    base, inner = m.group(1).strip(), m.group(2).strip()
    if "," in inner or inner.lower().startswith(("as ", "injection", "oral", "native", "pathogen", "seasonal")):
        first = inner.split(",")[0].strip().lower()
        if first in ("analogue",):
            return []
        return [f"{base} {first}"] if first in ("human",) else [base]
    return [base, inner]


for med in eml["medicines"]:
    found = []
    for part in med["parts"]:
        hit = None
        if not re.search(r"vaccine|antitoxin|immunoglobulin|antivenom|cryoprecipitate|plasma|medicines for", part, re.I):
            forms = [f"{part} {f}" for f in med.get("as_forms", [])] if not med["combination"] and "(" not in part else []
            for c in eml_candidates(part) + forms:
                hit = resolve_ema_substance(c)
                if hit is not None:
                    break
        found.append(hit)
        if hit is None:
            eml_unmatched.append(part)
    for i, e in enumerate(found):
        if e is None:
            continue
        entry = {"name": med["name"], "url": med["url"], "sections": med["sections"],
                 "with": [p for j, p in enumerate(med["parts"]) if j != i] if med["combination"] else []}
        if entry not in e.setdefault("_eml", []):
            e["_eml"].append(entry)
for e in entries:
    rows = e.pop("_eml", [])
    if rows:
        alone = [r for r in rows if not r["with"]]
        e["who_eml"] = {"listed_alone": bool(alone), "entries": (alone + [r for r in rows if r["with"]])[:8], "entries_total": len(rows),
                        "source": eml["source"], "page": eml["page"], "checked": eml["checked"], "licence": eml["licence"],
                        "licence_url": eml["licence_url"], "attribution": eml["attribution"], "binding_versions": eml["binding_versions"]}
        e["sources"].append({"label": f"WHO eEML: {rows[0]['name']} (checked {eml['checked']})", "url": rows[0]["url"]})

# ids are handed out to ChEMBL entries first, then FDA-only, then EMA-only, then PMDA-only, so adding a source never renames an existing page
used = set()
for e in sorted(entries, key=lambda e: (0 if e["chembl_id"] else 3 if e.get("_jp_only") else 2 if e.get("_ema_only") else 1, e["name"].lower())):
    base = slug(e["name"]) or "drug"
    sid = base if base not in used else f"{base}-{(e['chembl_id'] or ('pmda' if e.get('_jp_only') else 'ema' if e.get('_ema_only') else 'fda')).lower()}"
    used.add(sid); e["id"] = sid
entries.sort(key=lambda e: e["name"].lower())
# A medicine only EMA or PMDA lists, whose name is the start of another entry's name ("Mometasone" and "Mometasone Furoate",
# "Azilsartan" and "Azilsartan Medoxomil"): the two pages link to each other. Nothing is claimed about how they are related.
by_first_word = collections.defaultdict(list)
for e in entries:
    by_first_word[e["name"].lower().split()[0]].append(e)
for e in entries:
    if not (e.get("_ema_only") or e.get("_jp_only")) or e["chembl_id"]:
        continue
    n = e["name"].lower()
    for o in by_first_word[n.split()[0]]:
        if o is not e and o["name"].lower().startswith(n + " "):
            e.setdefault("see_also", []).append({"id": o["id"], "name": o["name"]})
            o.setdefault("see_also", []).append({"id": e["id"], "name": e["name"]})


def optional(name):
    f = RAW / name
    return json.loads(f.read_text()) if f.exists() else {}


binding, manufacturing, oligo_strands, peptide_strands = (
    optional("binding.json"), optional("manufacturing.json"), optional("oligo_sequences.json"), optional("peptide_sequences.json")
)
for e in entries:
    strands = oligo_strands.get(e["id"])
    if strands:        # FDA's substance registry is the one source for oligonucleotide strands (see fetch_oligo_sequences.py)
        e["sequence"] = {"helm": (e.get("sequence") or {}).get("helm"), "description": None, "components": strands["components"],
                         "chemistry": strands["chemistry"], "source": strands["source"], "source_url": strands["source_url"], "checked": CHECKED}
        e["sources"].append({"label": strands["source"], "url": strands["source_url"]})
        if e["type"] == "Unknown":
            e["type"], e["type_basis"] = "Oligonucleotide", "a strand sequence in FDA's substance registry"
    pstrands = peptide_strands.get(e["id"])
    if pstrands:
        old = e.get("sequence") or {}
        chembl_letters = sorted(c.get("sequence") or "" for c in old.get("components", []) if c.get("type") == "Protein")
        gsrs_letters = sorted(c["sequence"] for c in pstrands["components"])
        modified = pstrands.get("modification_count") != 0 or bool(pstrands.get("modifications")) or any(c.get("modified_sites") for c in pstrands["components"])
        e["sequence"] = {"helm": old.get("helm"), "description": old.get("description"), "components": pstrands["components"],
                         "modifications": pstrands.get("modifications"), "registry_unmodified": not modified,
                         "differs_from_chembl": bool(chembl_letters) and chembl_letters != gsrs_letters,
                         "residues_note": old.get("residues_note"),
                         "source": pstrands["source"], "source_url": pstrands["source_url"], "checked": CHECKED}
        e["sources"].append({"label": pstrands["source"], "url": pstrands["source_url"]})
    b = binding.get(e["id"])
    if b and (pathlib.Path(sys.argv[2]).parent / "bind" / f"{e['id']}.json").exists():
        e["binding"] = dict(b, checked=b.get("checked") or CHECKED)
        e["sources"].append({"label": f"PDB {b['pdb_id'].upper()} (drug bound to its target)", "url": b["url"]})
    cid = (e.get("structure") or {}).get("pubchem_cid")
    notes = manufacturing.get(str(cid)) if cid else None
    if notes and notes["notes"]:
        e["manufacturing"] = {"notes": notes["notes"], "mentions": notes["mentions"], "sources": notes["sources"], "checked": CHECKED,
                              "url": f"https://pubchem.ncbi.nlm.nih.gov/compound/{cid}#section=Methods-of-Manufacturing"}

# ---------------------------------------------------------------- files, index
(OUT / "drugs").mkdir(parents=True, exist_ok=True)
for old in (OUT / "drugs").glob("*.json"):
    old.unlink()
index, aliases = [], {}
stats = {"total": len(entries), "by_type": collections.Counter(), "with_structure": 0, "with_sequence": 0, "with_us_record": 0,
         "with_ema_link": 0, "withdrawn": 0, "chembl_only": 0, "fda_only": 0, "fda_applications": app_count,
         "by_decade": collections.Counter(), "by_atc": collections.Counter(), "us_novel_by_year": dict(sorted(novel_by_year.items())),
         "chembl_release": META["chembl_release"], "drugsfda_data_date": META.get("drugsfda_last_updated"), "fetched_on": CHECKED}
stats["eml_medicines"] = len(eml["medicines"])
stats["with_who_eml"] = sum(1 for e in entries if e.get("who_eml"))
stats["who_eml_alone"] = sum(1 for e in entries if (e.get("who_eml") or {}).get("listed_alone"))
stats["eml_unmatched"] = sorted(set(eml_unmatched))
stats["eml_checked"] = eml.get("checked")
for i, e in enumerate(entries):
    match, fda_flag = e.pop("_match"), e.pop("_fda_only", False)
    us_year = int(e["us"]["first_date"][:4]) if e["us"] and e["us"]["first_date"] else None
    eu_year = int(e["eu"]["first_authorised"][:4]) if e.get("eu") and e["eu"]["first_authorised"] else None
    jp_year = int(e["jp"]["first_new_ingredient"][:4]) if e.get("jp") and e["jp"]["first_new_ingredient"] else None
    year = min([y for y in (e["first_approval"], us_year, eu_year, jp_year) if y], default=None)
    e["first_year"] = year
    code = TYPE_CODES.get(e["type"], "un")
    atc1 = sorted({a["code"][0] for a in e["atc"]})
    brand = (e["us"]["brands"][0].title() if e["us"] and e["us"]["brands"] else (e["names"].get("trade") or [""])[0])
    if brand.lower() == e["name"].lower():
        brand = ""
    flags = (1 if e.get("structure") else 0) | (2 if e.get("sequence") else 0) | (4 if e["us"] else 0) | \
            (8 if e.get("eu") or e["world"]["ema_epar"] else 0) | (16 if e["flags"].get("withdrawn") else 0) | (32 if e["flags"].get("boxed_warning") else 0) | \
            (64 if e["stories"] else 0) | (128 if e.get("binding") else 0) | (256 if e.get("ca") else 0) | (512 if e.get("jp") else 0) | (1024 if e.get("who_eml") else 0)
    index.append([e["id"], e["name"], code, year, "".join(atc1), flags, brand])
    extra = {p[0].upper() for p in ((e.get("eu") or {}).get("products") or []) if not p[7]} | {b.upper() for b in e.pop("_brands", set())}
    for n in set(match) | {b.upper() for b in (e["us"]["brands"] if e["us"] else [])} | extra:
        if n != e["name"].upper() and 2 < len(n) < 60:
            aliases.setdefault(n.lower(), i)
    stats["by_type"][e["type"]] += 1
    stats["with_structure"] += bool(e.get("structure")); stats["with_sequence"] += bool(e.get("sequence"))
    stats["with_us_record"] += bool(e["us"]); stats["with_ema_link"] += bool(e["world"]["ema_epar"])
    stats["withdrawn"] += bool(e["flags"].get("withdrawn")); stats["fda_only"] += fda_flag
    stats["pmda_only"] = stats.get("pmda_only", 0) + e.pop("_jp_only", False)
    ema_only_flag = e.pop("_ema_only", False)
    stats["ema_only"] = stats.get("ema_only", 0) + ema_only_flag
    stats["with_eu_record"] = stats.get("with_eu_record", 0) + bool(e.get("eu"))
    stats["eu_authorised_now"] = stats.get("eu_authorised_now", 0) + bool(e.get("eu") and e["eu"]["authorised_now"])
    stats["us_and_eu"] = stats.get("us_and_eu", 0) + bool(e.get("eu") and e["us"])
    if e.get("eu") and e["eu"]["first_authorised"] and e["us"] and e["us"]["first_date"]:
        first = "us_first" if e["us"]["first_date"] < e["eu"]["first_authorised"] else "eu_first"
        stats.setdefault("first_to_approve", {"us_first": 0, "eu_first": 0})[first] += 1
    stats["chembl_only"] += bool(e["chembl_id"] and not e["us"])
    stats["with_binding_site"] = stats.get("with_binding_site", 0) + bool(e.get("binding"))
    stats["with_related_binding"] = stats.get("with_related_binding", 0) + bool((e.get("binding") or {}).get("related"))
    stats["with_ca_record"] = stats.get("with_ca_record", 0) + bool(e.get("ca"))
    stats["ca_marketed_now"] = stats.get("ca_marketed_now", 0) + bool(e.get("ca") and e["ca"]["marketed_now"])
    stats["with_jp_record"] = stats.get("with_jp_record", 0) + bool(e.get("jp"))
    stats["jp_new_ingredient"] = stats.get("jp_new_ingredient", 0) + bool(e.get("jp") and e["jp"]["first_new_ingredient"])
    stats["us_eu_ca_jp"] = stats.get("us_eu_ca_jp", 0) + bool(e["us"] and e.get("eu") and e.get("ca") and e.get("jp"))
    stats["with_mechanism"] = stats.get("with_mechanism", 0) + bool(e["mechanisms"])
    stats["with_manufacturing_notes"] = stats.get("with_manufacturing_notes", 0) + bool(e.get("manufacturing"))
    if year:
        stats["by_decade"][str(year // 10 * 10)] += 1
    for a in atc1:
        stats["by_atc"][a] += 1
    (OUT / "drugs" / f"{e['id']}.json").write_text(json.dumps(e, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
stats["by_decade"] = dict(sorted(stats["by_decade"].items()))
(OUT / "drug_index.json").write_text(json.dumps({"cols": ["id", "name", "type", "year", "atc", "flags", "brand"], "rows": index},
                                                ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
(OUT / "drug_aliases.json").write_text(json.dumps(aliases, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
# who reached a medicine first: US against the EU (central), Japan (new active ingredient) and Canada (first marketed).
# Only medicines new to both regions since 2005, when all four records are complete, so old approvals cannot skew it.
def region_dates(e):
    out = {"us": (e.get("us") or {}).get("first_date"), "eu": (e.get("eu") or {}).get("first_authorised"),
           "jp": (e.get("jp") or {}).get("first_new_ingredient")}
    ca = e.get("ca") or {}
    out["ca"] = ca.get("first_marketed") if ca.get("first_marketed") and not ca.get("first_marketed_year_only") else None
    return out


timing = {}
for other in ("eu", "jp", "ca"):
    gaps = []
    for e in entries:
        d = region_dates(e)
        if d["us"] and d[other] and min(d["us"], d[other]) >= "2005-01-01":
            gaps.append((datetime.date.fromisoformat(d[other]) - datetime.date.fromisoformat(d["us"])).days / 30.44)
    gaps.sort()
    timing[other] = {"n": len(gaps), "us_first": sum(g > 1 for g in gaps), "other_first": sum(g < -1 for g in gaps),
                     "same_month": sum(-1 <= g <= 1 for g in gaps), "median_months": round(gaps[len(gaps) // 2], 1) if gaps else None}
stats["region_timing"] = timing
stats["ca_products"], stats["ca_data_date"] = len(dpd["products"]), dpd.get("fetched_on")
stats["ca_ingredient_names_unmatched"] = len(ca_unmatched)
stats["jp_rows"], stats["jp_title"], stats["jp_data_date"] = len(jpl["rows"]), jpl.get("title"), jpl.get("fetched_on")
stats["jp_ingredients_unmatched"] = len(jp_unmatched)
stats["jp_spelling_variants_skipped"] = sorted(f"{k} ~ {v}" for k, v in jp_spelling.items())
stats["jp_same_brand_skipped"] = sorted(f"{k} ~ {v}" for k, v in jp_brand_seen.items())
stats["jp_combinations_skipped"] = sorted(jp_combination)
stats["filed_by_chembl_identity"] = sorted(f"{a} -> {b}" for a, b in same_molecule)
stats["filed_by_shared_brand"] = sorted(f"{a} -> {b} ({c})" for a, b, c in shared_brand)
(OUT / "catalogue_stats.json").write_text(json.dumps(stats, indent=1), encoding="utf-8")
print(json.dumps({k: v for k, v in stats.items() if k not in ("us_novel_by_year",)}, indent=1))
