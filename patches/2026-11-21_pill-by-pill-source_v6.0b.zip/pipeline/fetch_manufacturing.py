"""Pipeline step: what PubChem's "Methods of Manufacturing" notes say about each compound.

For every structure with a PubChem CID, read that section through PUG View (the notes come from sources such as the
Hazardous Substances Data Bank) and record only: how many notes there are, which sources they come from, and which
kinds of process their wording mentions (fermentation, natural source, semi-synthesis, chemical synthesis, recombinant).
The notes themselves are not copied: the site links to them. Writes raw/manufacturing.json.
Usage: python3 pipeline/fetch_manufacturing.py <raw dir> <data dir>
"""
import json, pathlib, re, sys, time, urllib.error, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
URL = "https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/{cid}/JSON?heading=Methods+of+Manufacturing"
MENTIONS = [  # label, pattern looked for in the notes
    ("fermentation", r"\bferment"),
    ("a natural source (plant, animal or microbe)", r"\b(isolated|extracted|obtained|derived) from\b|\bextraction (of|from)\b|\bnaturally occurring\b|\bnatural product\b"),
    ("semi-synthesis from a natural starting material", r"\bsemi-?synthe"),
    ("recombinant production", r"\brecombinant\b"),
    ("chemical synthesis", r"\bsynthe(sis|sized|sised|tic)\b|\bprepared (by|from)\b|\breact(ion|ing|ed)\b|\bcondens|\bacylat|\balkylat|\bhydrogenat|\besterif"),
]


def strings(section):
    for s in section.get("Section", []):
        for info in s.get("Information", []):
            for part in info.get("Value", {}).get("StringWithMarkup", []):
                yield info.get("ReferenceNumber"), part.get("String", "")
        yield from strings(s)


def main():
    out_file = RAW / "manufacturing.json"
    out = json.loads(out_file.read_text()) if out_file.exists() else {}
    cids = sorted({d["structure"]["pubchem_cid"] for d in (json.loads(f.read_text()) for f in (DATA / "drugs").glob("*.json"))
                   if d.get("structure") and d["structure"].get("pubchem_cid")})
    for n, cid in enumerate(cids):
        if str(cid) in out:
            continue
        try:
            with urllib.request.urlopen(URL.format(cid=cid), timeout=60) as r:
                record = json.loads(r.read())["Record"]
            notes = list(strings(record))
            text = " ".join(s for _, s in notes).lower()
            sources = {r["ReferenceNumber"]: r["SourceName"] for r in record.get("Reference", [])}
            out[str(cid)] = {"notes": len(notes), "mentions": [label for label, pattern in MENTIONS if re.search(pattern, text)],
                             "sources": sorted({sources.get(ref, "PubChem") for ref, _ in notes})}
        except urllib.error.HTTPError as e:
            if e.code == 404:
                out[str(cid)] = {"notes": 0, "mentions": [], "sources": []}   # PubChem has no manufacturing section for this compound
            else:
                time.sleep(3)
        except Exception:
            time.sleep(3)
        if n % 100 == 0:
            out_file.write_text(json.dumps(out)); print(n, "/", len(cids), flush=True)
        time.sleep(0.22)
    out_file.write_text(json.dumps(out))
    print("done", len(out), "with notes", sum(1 for v in out.values() if v["notes"]))


if __name__ == "__main__":
    main()
