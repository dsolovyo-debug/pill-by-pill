"""Pipeline step: amino-acid sequences and modification sites of peptide medicines from FDA's substance registry.

ChEMBL 37 has no sequence for 16 approved peptides (including liraglutide, octreotide, leuprolide, desmopressin, goserelin
and degarelix) and drops the non-standard [Aib8] residue in semaglutide's biocomponent string. FDA's Global Substance
Registration System (GSRS, https://gsrs.ncats.nih.gov) holds the registered subunit sequences and modification sites for
approved peptide substances with their official UNII record links.
Writes raw/peptide_sequences.json keyed by drug id. Nothing is typed by hand.
Usage: python3 pipeline/fetch_peptide_sequences.py <raw dir> <data dir>
"""
import json, pathlib, re, sys, time, urllib.parse, urllib.request

RAW, DATA = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
SEARCH = "https://gsrs.ncats.nih.gov/api/v1/substances/search?top=10&view=full&q="
SALT_SUFFIXES = r" (ACETATE|HYDROCHLORIDE|SODIUM|TRIFLUTATE|MESYLATE|PAMOATE|DIACETATE)$"


def get(url):
    for attempt in range(2):
        try:
            return json.loads(urllib.request.urlopen(url, timeout=40).read())
        except Exception:
            time.sleep(2 * (attempt + 1))
    return {}


def lookup(name):
    """The GSRS protein substance whose primary _name or official synonym in names[] matches name."""
    target = name.upper()
    for query in (f'root_names_name:"^{name}$"',):
        for s in get(SEARCH + urllib.parse.quote(query)).get("content", []):
            if s.get("substanceClass") != "protein":
                continue
            all_names = {(s.get("_name") or "").upper()} | {(n.get("name") or "").upper() for n in (s.get("names") or [])}
            if target in all_names:
                return s
    return None


def masked_sequence(seq, mod_sites):
    """Replace 1-based modified residue indices with X for Rule B PDB chain alignment."""
    chars = list(seq)
    for pos in mod_sites:
        if 1 <= pos <= len(chars):
            chars[pos - 1] = "X"
    return "".join(chars)


def main():
    out_file, tried_file = RAW / "peptide_sequences.json", RAW / "peptide_sequences_tried.json"
    out = json.loads(out_file.read_text()) if out_file.exists() else {}
    tried = set(json.loads(tried_file.read_text())) if tried_file.exists() else set()      # resumable: the run is slow
    for f in sorted((DATA / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        seq_block = d.get("sequence") or {}
        comps = [c for c in seq_block.get("components", []) if c.get("type") == "Protein"]
        if any(len(c.get("sequence") or "") > 60 for c in comps):
            continue
        is_peptide = bool(d.get("peptide_note")) or (d["type"] == "Protein" and (not comps or any(len(c.get("sequence") or "") <= 60 for c in comps)))
        if not is_peptide or d["id"] in tried or not d.get("mechanisms"):
            continue
        tried.add(d["id"])
        if len(tried) % 10 == 0:
            out_file.write_text(json.dumps(out, indent=1)); tried_file.write_text(json.dumps(sorted(tried))); print(len(tried), "tried,", len(out), "found", flush=True)
        base = re.sub(SALT_SUFFIXES, "", d["name"].upper())
        candidates = list(dict.fromkeys([d["name"].upper(), base]))
        s = next((hit for hit in (lookup(n) for n in candidates) if hit), None)
        if not s:
            continue
        prot = s.get("protein") or {}
        subunits = sorted(prot.get("subunits", []), key=lambda u: u.get("subunitIndex", 0))
        strands = [(u.get("subunitIndex", i + 1), (u.get("sequence") or "").strip()) for i, u in enumerate(subunits) if u.get("sequence")]
        if not strands or any(len(seq) > 60 for _, seq in strands):
            continue
        mods_by_sub = {}
        mod_notes = []
        # modifications are recorded on the substance, not inside "protein"; any kind (structural, agent, physical) counts
        all_mods = s.get("modifications") or {}
        other_mods = len(all_mods.get("agentModifications") or []) + len(all_mods.get("physicalModifications") or [])
        if other_mods:
            mod_notes.append(f"{other_mods} agent or physical modification(s) on record")
        for mod in all_mods.get("structuralModifications") or []:
            mtype = (mod.get("structuralModificationType") or "").replace("_", " ").lower()
            molec = (mod.get("molecularFragment") or {}).get("refPname") or ""
            sites = mod.get("sites") or []
            for site in sites:
                sub_idx = site.get("subunitIndex", 1)
                res_idx = site.get("residueIndex")
                if res_idx:
                    mods_by_sub.setdefault(sub_idx, set()).add(int(res_idx))
            if mtype or molec:
                mod_notes.append(f"{mtype}: {molec}".strip(": "))
        components = []
        for idx, (sub_idx, seq) in enumerate(strands):
            msites = sorted(mods_by_sub.get(sub_idx, ()))
            comp = {"type": "Protein", "note": f"chain {idx + 1} of {len(strands)}, {len(seq)} aa", "organism": None, "sequence": seq}
            if msites:
                comp["modified_sites"] = msites
                comp["aligned_sequence"] = masked_sequence(seq, msites)
            components.append(comp)
        out[d["id"]] = {
            "components": components,
            "modifications": "; ".join(dict.fromkeys(mod_notes)) or None,
            "modification_count": len(all_mods.get("structuralModifications") or []) + other_mods,
            "unii": s.get("approvalID"),
            "source": f"FDA Global Substance Registration System (UNII {s.get('approvalID')})",
            "source_url": f"https://gsrs.ncats.nih.gov/ginas/app/ui/substances/{s.get('approvalID')}",
        }
        time.sleep(0.3)
    out_file.write_text(json.dumps(out, indent=1)); tried_file.write_text(json.dumps(sorted(tried)))
    print("peptides with GSRS sequences:", len(out))


if __name__ == "__main__":
    main()
