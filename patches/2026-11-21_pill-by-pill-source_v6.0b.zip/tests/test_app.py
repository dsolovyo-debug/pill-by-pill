"""Parity checks: app.py must serve the same files and give the same answers as the static site.
Usage: python3 tests/test_app.py <site folder>"""
import asyncio, json, os, pathlib, sys

SITE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site").resolve()
os.environ["PBP_SITE"] = str(SITE)
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from fastapi.testclient import TestClient
import app as server
from browser import open_site, go

client, results = TestClient(server.app), []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


for rel in ["index.html", "js/app.js", "css/base.css", "data/drug_index.json", "data/drugs/aspirin.json", "mol/aspirin.json", "bind/atorvastatin.json", "config/monetization.json", "legacy/index.html"]:
    r = client.get("/" + rel)
    check(f"server serves identical bytes: {rel}", r.status_code == 200 and r.content == (SITE / rel).read_bytes())
check("server root is the site", client.get("/").content == (SITE / "index.html").read_bytes())
check("/api/drugs/{id} equals the drug file", client.get("/api/drugs/atorvastatin").json() == json.loads((SITE / "data/drugs/atorvastatin.json").read_text()))
check("/api/molecules/{id} equals the mol file", client.get("/api/molecules/aspirin").json() == json.loads((SITE / "mol/aspirin.json").read_text()))
check("/api/binding/{id} equals the bind file", client.get("/api/binding/atorvastatin").json() == json.loads((SITE / "bind/atorvastatin.json").read_text()))
check("/api/drugs flag=binding matches the index", client.get("/api/drugs?flag=binding&limit=1").json()["total"] == sum(1 for r in json.loads((SITE / "data/drug_index.json").read_text())["rows"] if r[5] & 128))
check("/api/topics/{key} equals the topic file", client.get("/api/topics/peptides").json() == json.loads((SITE / "data/topics/peptides.json").read_text()))
check("/api/stats equals the stats file", client.get("/api/stats").json() == json.loads((SITE / "data/catalogue_stats.json").read_text()))
index = json.loads((SITE / "data/drug_index.json").read_text())["rows"]
check("/api/drugs filter matches the index", client.get("/api/drugs?flag=boxed&limit=1").json()["total"] == sum(1 for r in index if r[5] & 32))
check("/api/drugs flag=eml (WHO Essential Medicines List) matches the index", client.get("/api/drugs?flag=eml&limit=1").json()["total"] == sum(1 for r in index if r[5] & 1024) > 400)
check("/api/drugs composite has filters (all4, euonly, both, nous) match the index",
      client.get("/api/drugs?has=all4&limit=1").json()["total"] == sum(1 for r in index if (r[5] & 4) and (r[5] & 8) and (r[5] & 256) and (r[5] & 512))
      and client.get("/api/drugs?has=euonly&limit=1").json()["total"] == sum(1 for r in index if (r[5] & 8) and not (r[5] & 4))
      and client.get("/api/drugs?has=both&limit=1").json()["total"] == sum(1 for r in index if (r[5] & 4) and (r[5] & 8))
      and client.get("/api/drugs?has=nous&limit=1").json()["total"] == sum(1 for r in index if not (r[5] & 4)))
check("v4 endpoint alias still answers", client.get("/stats/peptides").json() == client.get("/api/topics/peptides").json())
check("unknown drug is a 404", client.get("/api/drugs/not-a-drug").status_code == 404)
check("path traversal is refused", client.get("/api/drugs/..%2F..%2Fconfig%2Fmonetization").status_code == 404)


async def search_parity():
    async with open_site(SITE) as (pg, log):
        await go(pg, "#/ref")
        diffs = []
        for q in ["lipitor", "stat", "mab", "aspirin", "insulin", "ozempic", "peni", "zz"]:
            js = await pg.evaluate("q => import('./js/data.js').then(m => m.searchDrugs(q, 20)).then(r => r.map(d => d.id))", q)
            py = [d["id"] for d in client.get("/api/search", params={"q": q, "limit": 20}).json()]
            if js != py:
                diffs.append(q)
        check("search gives the same results in the browser and in app.py", not diffs, str(diffs))

asyncio.run(search_parity())
failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
