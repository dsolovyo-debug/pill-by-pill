"""Browser checks in headless Chromium, with the site served under a public-style host name.
Usage: python3 tests/test_site.py <site folder>"""
import re, asyncio, json, pathlib, sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from browser import open_site, go, go_path

SITE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site").resolve()
results = []

STUDENT_ROUTES = ["#/explore", "#/explore/medicines", "#/explore/medicines?type=ab", "#/explore/medicine/aspirin", "#/explore/medicine/aspirin/molecule",
                  "#/explore/medicine/aspirin/made", "#/explore/medicine/aspirin/works", "#/explore/medicine/atorvastatin/works", "#/explore/medicine/semaglutide", "#/explore/stories", "#/explore/topic/discoveries",
                  "#/explore/topic/discoveries/all", "#/explore/topic/stems", "#/explore/made", "#/explore/quiz"]
OTHER_ROUTES = ["#/", "#/explore/teach", "#/explore/history", "#/ref", "#/ref/clinician", "#/ref/chemist", "#/ref/industry", "#/ref/drugs", "#/ref/drugs?flag=boxed",
                "#/ref/drug/atorvastatin", "#/ref/drug/atorvastatin/structure", "#/ref/drug/atorvastatin/binding", "#/ref/drug/aspirin/binding", "#/ref/drug/medical-air/binding", "#/ref/drugs?has=binding", "#/ref/drug/atorvastatin/approvals", "#/ref/drug/atorvastatin/uses",
                "#/ref/drug/atorvastatin/names", "#/ref/drug/trastuzumab/structure", "#/ref/drug/mipomersen/structure", "#/ref/drug/nusinersen/structure", "#/ref/drug/medical-air/structure",
                "#/ref/topics", "#/ref/topic/peptides", "#/ref/topic/peptides/3", "#/ref/topic/pgx", "#/ref/topic/interactions", "#/ref/topic/excipients", "#/ref/drug/patisiran-sodium/structure", "#/explore/medicine/semaglutide/molecule", "#/ref/topic/stems", "#/ref/data", "#/fund"]


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


async def main():
    index_rows = json.loads((SITE / "data" / "drug_index.json").read_text())["rows"]
    cfg = json.loads((SITE / "config" / "monetization.json").read_text())
    preview = json.dumps(dict(cfg, preview=True))
    connected = json.loads(json.dumps(cfg)); connected["schemes"]["bookshop"]["affiliate_connected"] = True
    connected["schemes"]["kofi"]["url"] = "https://ko-fi.com/example"

    # 1. every page type renders, in the page hierarchy, with no script errors and no outside requests
    async with open_site(SITE) as (pg, log):
        broken = []
        for r in STUDENT_ROUTES + OTHER_ROUTES:
            await go(pg, r)
            h1 = await pg.inner_text("h1")
            level = await pg.evaluate("document.querySelector('[data-level]')?.dataset.level || (document.body.dataset.env === 'start' ? 'home' : '')")
            if "couldn't find" in h1 or not level:
                broken.append(r)
        check("all page types render with a level in the hierarchy", not broken, f"{len(STUDENT_ROUTES + OTHER_ROUTES)} routes {broken}")
        check("no script errors", not log["errors"], str(log["errors"][:2]))
        check("no requests leave the site", not log["external"], str(log["external"][:2]))
        check("no missing files", not log["missing"], str(log["missing"][:3]))

        # 2. hierarchy: breadcrumbs deepen, drug page has key facts above the fold and deep-dive links
        await go(pg, "#/ref/drug/atorvastatin")
        facts_top = await pg.evaluate("document.querySelector('.facts').getBoundingClientRect().bottom")
        deep = await pg.evaluate("[...document.querySelectorAll('.deep')].map(a => a.getAttribute('href'))")
        check("drug page: key facts above the fold", facts_top < 900, f"facts end at {round(facts_top)} px of 900")
        check("drug page: five deep-dive pages", sum(h.startswith("#/ref/drug/atorvastatin/") for h in deep) == 5, str(deep))
        words = len((await pg.inner_text("#main")).split())
        check("drug page is concise", words < 320, f"{words} words")
        await go(pg, "#/ref/drug/atorvastatin/structure")
        crumbs = await pg.evaluate("document.querySelectorAll('.crumbs li').length")
        check("deep-dive breadcrumb has four levels", crumbs == 4, str(crumbs))

        # 3. molecule graphics
        lines = await pg.evaluate("document.querySelectorAll('svg.mol2d line, svg.mol2d polygon').length")
        check("2D structure drawn (atorvastatin)", lines > 40, f"{lines} bond marks")
        check("3D model canvas present", await pg.evaluate("!!document.querySelector('canvas.mol3d')"))
        painted = await pg.evaluate("""() => { const c = document.querySelector('canvas.mol3d'); const d = c.getContext('2d').getImageData(0,0,c.width,c.height).data;
            let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i]) n++; return n; }""")
        check("3D model actually painted", painted > 2000, f"{painted} pixels")
        text = await pg.inner_text("#main")
        check("structure page shows source, InChIKey and checked date", all(x in text for x in ("XUKUURHRXDUEBC-KAYWLYCHSA-N", "ChEMBL", "2026-")))
        await go(pg, "#/ref/drug/trastuzumab/structure")
        check("antibody: sequence view, no skeletal drawing", await pg.evaluate("!document.querySelector('svg.mol2d') && document.querySelectorAll('.seq').length >= 2"))
        await go(pg, "#/ref/drug/mipomersen/structure")
        check("oligonucleotide with a ChEMBL sequence: strand view, no skeletal drawing", await pg.evaluate("document.querySelectorAll('.seq').length >= 1 && !document.querySelector('svg.mol2d')"))
        await go(pg, "#/ref/drug/nusinersen/structure")
        text = await pg.inner_text("#main")
        chips = await pg.evaluate("document.querySelectorAll('.res.nt').length")
        check("nusinersen: 18 base chips from FDA's registry, curated note kept, no skeletal drawing", chips == 18 and "Substance Registration" in text and "SMN2" in text and not await pg.evaluate("!!document.querySelector('svg.mol2d')"), f"{chips} chips")
        await go(pg, "#/ref/drug/semaglutide/names")
        text = await pg.inner_text("#main")
        check("Canada and Japan tables on the names page, with Health Canada's licence sentence and PMDA's 'created by editing' citation",
              "canada: products" in text.lower() and "OZEMPIC" in text and "Open Government Licence" in text and "japan: pmda" in text.lower() and "Created by editing" in text and "Not produced or endorsed by PMDA" in text)
        await go(pg, "#/ref/drugs?has=jp")
        shown = await pg.inner_text("#count")
        check("Japan filter count matches the data", f"{sum(1 for r in index_rows if r[5] & 512):,}" in shown, shown)
        await go(pg, "#/explore/medicine/semaglutide")
        text = await pg.inner_text("#main")
        years = await pg.evaluate("[...document.querySelectorAll('.world-line li b')].map(b => b.textContent)")
        check("Simple: around-the-world timeline, oldest first, with the Canada date labelled as first on sale", "around the world" in text.lower() and years == sorted(years) and len(years) == 4 and "first on sale" in text, str(years))
        await go(pg, "#/ref/drug/semaglutide/names")
        check("In-depth: first dates by region say what each date is", "first dates by region" in (await pg.inner_text("#main")).lower() and "first marketed (not the approval date)" in await pg.inner_text("#main"))
        await go(pg, "#/ref/industry")
        text = await pg.inner_text("#main")
        check("industry page compares the US with the EU, Japan and Canada, and says how", "who gets new medicines first" in text.lower() and "since 2005" in text and "Japan (PMDA, new active ingredient)" in text)
        await go(pg, "#/explore/medicine/semaglutide")
        check("peptide on Simple page: residue chips", await pg.evaluate("document.querySelectorAll('.res').length") >= 25)
        await go(pg, "#/ref/drug/medical-air/structure")
        text = await pg.inner_text("#main")
        check("no structure: says so and draws nothing", "nothing is drawn" in text and not await pg.evaluate("!!document.querySelector('svg.mol2d')"))

        # 3b. binding animations and schematics
        await go(pg, "#/ref/drug/atorvastatin/binding")
        await pg.wait_for_timeout(600)
        first = await pg.inner_text(".bind-caption")
        painted = await pg.evaluate("""() => { const c = document.querySelector('canvas.bind3d'); const d = c.getContext('2d').getImageData(0,0,c.width,c.height).data;
            let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i]) n++; return n; }""")
        await pg.click("[data-act=end]"); await pg.wait_for_timeout(300)
        last = await pg.inner_text(".bind-caption")
        site = json.loads((SITE / "bind" / "atorvastatin.json").read_text())
        rows = await pg.evaluate("[...document.querySelectorAll('table')].map(t => t.tBodies[0].rows.length)")
        text = await pg.inner_text("#main")
        check("binding animation paints and its caption advances", painted > 3000 and first != last and "contacts" in last, f"{painted} px; '{first[:40]}' -> '{last[:40]}'")
        check("binding page lists every contact and names the PDB entry, method and resolution", len(site["contacts"]) in rows and "1HWK" in text and "X-ray" in text and "Å" in text)
        check("binding page says what is experimental and what is illustration", "illustration" in text and "not computed energies" in text)
        check("schematic shown beside the real structure", await pg.evaluate("document.querySelectorAll('svg.sch').length") >= 1)
        await go(pg, "#/ref/drug/aspirin/binding")
        text = await pg.inner_text("#main")
        check("no bound structure: says so, shows a schematic only", "No deposited structure" in text and await pg.evaluate("!document.querySelector('canvas.bind3d') && !!document.querySelector('svg.sch-block')"))
        await go(pg, "#/ref/drug/medical-air/binding")
        check("no mechanism: no schematic and no animation", await pg.evaluate("!document.querySelector('canvas.bind3d') && !document.querySelector('svg.sch')"))
        await go(pg, "#/explore/medicine/atorvastatin/works")
        await pg.wait_for_timeout(400)
        check("Simple 'how it works' page: schematic, animation and plain caption", await pg.evaluate("!!document.querySelector('svg.sch') && !!document.querySelector('canvas.bind3d')") and "pocket" in await pg.inner_text(".bind-caption"))

        await go(pg, "#/ref/drug/pembrolizumab/binding"); await pg.wait_for_timeout(500)
        await pg.click("[data-act=end]"); await pg.wait_for_timeout(300)
        text = await pg.inner_text("#main")
        check("antibody interface animates and names residues on both sides", await pg.evaluate("!!document.querySelector('canvas.bind3d')") and "Programmed cell death protein 1" in text and "sequence matches" in text and "Only the residues at the interface" in text)
        await go(pg, "#/ref/drug/atorvastatin/binding"); await pg.wait_for_timeout(300)
        async with pg.expect_download(timeout=40000) as dl:
            await pg.click("[data-act=save]")
        video = await dl.value
        size = pathlib.Path(await video.path()).stat().st_size
        check("'Save as video' records one loop to a file in the browser", video.suggested_filename.startswith("atorvastatin-binding.") and size > 20000, f"{video.suggested_filename}, {size:,} bytes")
        await go(pg, "#/ref/topic/moa/0")
        text = await pg.inner_text("#main")
        check("mechanism walk-through ported: three scales with its source", await pg.evaluate("document.querySelectorAll('.tiers section').length") == 3 and "Source:" in text)
        await go(pg, "#/explore/topic/moa")
        check("Simple zoom-in page lists three scales per medicine", await pg.evaluate("document.querySelectorAll('.zoom').length") >= 6)

        # 3c. explorers (ported v4 simulators): sourced, and no prescribing content in the Simple environment
        await go(pg, "#/ref/topic/pgx"); await pg.wait_for_selector(".sim-cards")
        text = await pg.inner_text("[data-sim=pgx]")
        check("gene-variant explorer cites the FDA label and says it is not advice", "FDA label: Plavix" in text and "not advice" in text and await pg.evaluate("document.querySelector('[data-sim=pgx] .src a').href.startsWith('https://dailymed.nlm.nih.gov/')"))
        await pg.click("[data-case=tpmt-azathioprine]")
        check("explorer switches case", "Imuran" in await pg.inner_text("[data-sim=pgx]"))
        await go(pg, "#/ref/topic/interactions"); await pg.wait_for_selector(".sim-cards")
        check("interaction explorer shows a figure only where the label gives one", "More than 2-fold" in await pg.inner_text("[data-sim=interactions]"))
        await pg.click("[data-case=dairy-ciprofloxacin]")
        check("interaction without a label figure says so", "no single figure" in await pg.inner_text("[data-sim=interactions]"))
        gone = []
        for r in ("#/explore/topic/pgx", "#/explore/topic/interactions"):
            await go(pg, r)
            if await pg.evaluate("!!document.querySelector('[data-sim]')"):
                gone.append(r)
        check("Simple pages carry no prescribing explorers", not gone, str(gone))
        await go(pg, "#/explore/topic/excipients"); await pg.wait_for_selector(".sim-curve")
        check("release-profile curve is drawn and labelled an illustration", "illustration" in (await pg.inner_text("[data-sim=excipients]")).lower() and await pg.evaluate("document.querySelector('.sim-curve polyline').points.length") > 50)

        # 3d. EU records
        await go(pg, "#/ref/drug/semaglutide/names")
        text = await pg.inner_text("#main")
        check("EU products table with EMA links and its scope note", "Ozempic" in text and "EMEA/H/C/004174" in text and "centralised procedure" in text and await pg.evaluate("[...document.querySelectorAll('a')].some(a => a.href === 'https://www.ema.europa.eu/en/medicines/human/EPAR/ozempic')"))
        await go(pg, "#/ref/drug/atorvastatin/names")
        check("no EU central record: says so without claiming it is unapproved", "may still be licensed by individual EU countries" in await pg.inner_text("#main"))
        await go(pg, "#/ref/drugs?has=euonly")
        shown = await pg.inner_text("#count")
        check("EU-only filter count matches the data", f"{sum(1 for r in index_rows if r[5] & 8 and not r[5] & 4):,}" in shown, shown)
        await go(pg, "#/ref/drug/tegomil-fumarate")
        text = await pg.inner_text("#main")
        check("a medicine listed only by EMA has a page with its EMA source, and ChEMBL shown as structure only", "Tegomil fumarate" in text and "Authorised" in text
              and "structure and mechanism only" in text and await pg.evaluate("[...document.querySelectorAll('a')].some(a => a.href.startsWith('https://www.ema.europa.eu/'))"))
        await go(pg, "#/ref/drug/mometasone")
        text = await pg.inner_text("#main")
        check("a regulator-only name links to the entry with the longer name, and back", "similar name" in text.lower() and await pg.evaluate("!!document.querySelector('a[href=\"#/ref/drug/mometasone-furoate\"]')"))
        await go(pg, "#/explore/medicine/mometasone-furoate")
        check("Simple page shows the similar-name link", await pg.evaluate("!!document.querySelector('a[href=\"#/explore/medicine/mometasone\"]')"))
        await go(pg, "#/explore/medicine/semaglutide")
        check("Simple page says where the medicine is on record (US, EU, Canada, Japan)", "United States, European Union, Canada and Japan" in await pg.inner_text(".facts"))

        # 3e. related-protein animations are labelled in both environments
        await go(pg, "#/ref/drug/celecoxib/binding")
        text = await pg.inner_text("#main")
        check("In-depth: a stand-in structure says it is not the medicine's own target and names the organism", "Not this medicine's own target" in text and "Mus musculus" in text and "UniProt" in text and await pg.evaluate("!!document.querySelector('#bind canvas')"))
        await go(pg, "#/explore/medicine/celecoxib/works")
        check("Simple: the stand-in is explained in plain words", "close stand-in" in (await pg.inner_text("#main")).lower() and "Mus musculus" in await pg.inner_text("#main"))
        await go(pg, "#/ref/drug/atorvastatin/binding")
        check("a structure in the medicine's own target carries no stand-in notice", not await pg.evaluate("!!document.querySelector('#related-note')"))

        # 4. two separate environments
        await go(pg, "#/explore/medicine/aspirin")
        x = await pg.evaluate("({env: document.body.dataset.env, nav: [...document.querySelectorAll('.x-nav a')].map(a => a.textContent.trim()), size: getComputedStyle(document.body).fontSize, side: !!document.querySelector('.r-side'), tables: document.querySelectorAll('table').length})")
        await go(pg, "#/ref/drug/aspirin")
        r = await pg.evaluate("({env: document.body.dataset.env, nav: [...document.querySelectorAll('.r-side a')].map(a => a.textContent.trim()), size: getComputedStyle(document.body).fontSize, side: !!document.querySelector('.r-side'), tables: document.querySelectorAll('table').length})")
        check("Simple and In-depth use different shells, navigation and type size", x["env"] == "explore" and r["env"] == "ref" and not set(x["nav"]) & set(r["nav"]) and x["size"] != r["size"] and r["side"] and not x["side"], f"{x['size']} vs {r['size']}")
        check("Simple drug page has no data tables; In-depth has", x["tables"] == 0 and r["tables"] >= 1)

        # 5. role paths land on different pages
        heads = {}
        for role, route in {"student": "#/explore", "teacher": "#/explore/teach", "history": "#/explore/history", "clinician": "#/ref/clinician", "chemist": "#/ref/chemist", "industry": "#/ref/industry"}.items():
            await go(pg, route)
            heads[role] = (await pg.inner_text("h1"), tuple(await pg.evaluate("[...document.querySelectorAll('.deep')].map(a => a.getAttribute('href'))")))
        check("six roles, six different landing pages and next steps", len(set(heads.values())) == 6 and len({h for h, _ in heads.values()}) == 6)

        # 6. search
        await go(pg, "#/ref")
        await pg.fill("#r-q", "lipitor"); await pg.wait_for_selector("#r-suggest a")
        check("brand search finds the ingredient", "Atorvastatin" in await pg.inner_text("#r-suggest"))
        await go(pg, "#/ref/drugs?flag=boxed")
        shown = await pg.inner_text("#count")
        index = json.loads((SITE / "data" / "drug_index.json").read_text())["rows"]
        check("catalogue filter count matches the data", str(f"{sum(1 for r in index if r[5] & 32):,}") in shown, shown)

        # 7. quiz plays through
        await go(pg, "#/explore/quiz")
        for _ in range(10):
            await pg.click(".answer >> nth=0"); await pg.click("#next")
        check("quiz reaches a score", "out of 10" in await pg.inner_text("#quiz"))

    # 8. monetization rules, tested with preview on (the most that could ever show)
    async with open_site(SITE, overrides={"config/monetization.json": preview}) as (pg, log):
        leaks = []
        await go(pg, "#/explore")
        for r in STUDENT_ROUTES:
            await go(pg, r)
            if await pg.evaluate("!!document.querySelector('.money, .money-wrap, [data-scheme]')"):
                leaks.append(r)
        check("student pages never show monetization, even in preview", not leaks, str(leaks))
        seen = {}
        for role, route in {"teacher": "#/explore/teach", "history": "#/explore/history", "clinician": "#/ref/clinician", "chemist": "#/ref/chemist", "industry": "#/ref/industry"}.items():
            await go(pg, route)
            seen[role] = await pg.evaluate("[...document.querySelectorAll('[data-scheme]')].map(e => e.dataset.scheme)")
        want = {role: [k for k, s in cfg["schemes"].items() if s["on"] and not s.get("legal_hold") and role in s["roles"]] for role in seen}
        check("each paying role sees exactly its schemes", seen == want, json.dumps(seen))
        check("teachers see classroom packs; professionals see data-refresh sponsorship", "classroom_packs" in seen["teacher"] and all("pro_support" in seen[r] for r in ("clinician", "chemist", "industry")) and "classroom_packs" not in seen["clinician"])
        check("schemes on legal hold never show, even in preview", not any(k in v for v in seen.values() for k in ("licensing", "affiliations")), json.dumps(seen))
        await go(pg, "#/fund")
        check("funding page lists what is on hold and states the no-drug-maker rule", "not offered yet" in (await pg.inner_text("#main")).lower() and "no money from drug makers" in await pg.inner_text("#main"))
        await go(pg, "#/ref/drug/atorvastatin")
        check("no monetization inside factual drug pages", not await pg.evaluate("!!document.querySelector('[data-scheme]')"))
    async with open_site(SITE) as (pg, log):
        await go(pg, "#/explore/teach")
        live = await pg.evaluate("[...document.querySelectorAll('[data-scheme]')].map(e => e.dataset.scheme)")
        teach_books = await pg.inner_text("[data-scheme=bookshop]")
        await go(pg, "#/ref/chemist")
        chem_books = await pg.inner_text("[data-scheme=bookshop]")
        check("book lists differ by role and each book links a record of its details", "Breakthrough" in teach_books and "Breakthrough" not in chem_books and "Molecules That Changed the World" in chem_books
              and "Molecules That Changed the World" not in teach_books and await pg.evaluate("[...document.querySelectorAll('[data-scheme=bookshop] li')].every(li => li.querySelectorAll('a').length === 2)"))
        await go(pg, "#/explore/teach")
        hrefs = await pg.evaluate("[...document.querySelectorAll('[data-scheme=bookshop] a.buy')].map(a => [a.href, a.rel, a.textContent])")
        check("paid book links are on hold (Dmitry, 2026-11-20): book shelves still show, every link is an ordinary Bookshop.org link, none marked or tagged as paid",
              live == ["bookshop"] and len(hrefs) >= 4 and all(h.startswith("https://bookshop.org/") and "/a/131541/" not in h and "sponsored" not in r and "Paid link" not in t for h, r, t in hrefs), str(hrefs[:1]))
        check("the book shelf says plainly that the site earns nothing from these links", "earns nothing from them" in await pg.inner_text("[data-scheme=bookshop]"))
        await go(pg, "#/fund")
        check("funding page lists paid book links under 'Not offered yet' and says the site earns nothing", "paid links" in (await pg.inner_text("#main")).lower()
              and "earns nothing" in await pg.inner_text("#main"))
        for student_page in ("#/explore", "#/explore/medicine/aspirin", "#/explore/medicines"):
            await go(pg, student_page)
            check(f"no paid link on student page {student_page}", not await pg.evaluate("!!document.querySelector('[data-scheme]') || document.body.innerHTML.includes('bookshop.org/a/')"))
    connected["schemes"]["bookshop"].pop("paid_links_hold", None)
    async with open_site(SITE, overrides={"config/monetization.json": json.dumps(connected)}) as (pg, log):
        await go(pg, "#/explore/teach")
        check("a connected tip link appears", await pg.evaluate("document.querySelector('[data-scheme=kofi] a')?.href") == "https://ko-fi.com/example")
        hrefs = await pg.evaluate("[...document.querySelectorAll('[data-scheme=bookshop] a.buy')].map(a => [a.href, a.rel, a.textContent])")
        check("if the hold is lifted later, book links become affiliate links by ISBN, marked Paid link and rel=sponsored, with the disclosure beside them",
              all(re.fullmatch(r"https://bookshop\.org/a/131541/97[89]\d{10}", h) and "sponsored" in r and "Paid link" in t for h, r, t in hrefs if "/a/" in h) and any("/a/" in h for h, _, _ in hrefs)
              and "earns a commission" in await pg.inner_text("[data-scheme=bookshop]"), str(hrefs[:1]))
    connected["schemes"]["bookshop"]["paid_links_hold"] = "test"
    async with open_site(SITE, overrides={"config/monetization.json": json.dumps(connected)}) as (pg, log):
        await go(pg, "#/explore/teach")
        rels = await pg.evaluate("[...document.querySelectorAll('[data-scheme=bookshop] a.buy')].map(a => a.rel)")
        check("putting paid links on hold turns every book link back into an unpaid search link", "Paid link" not in await pg.inner_text("[data-scheme=bookshop]") and not any("sponsored" in x for x in rels))

    # 8b. v5.24: WHO Essential Medicines List, medicine families, comparison, FDA shortages link, covalent binding, quiz order
    async with open_site(SITE) as (pg, log):
        await go(pg, "#/ref/drug/amoxicillin")
        text = (await pg.inner_text("#main")).lower()
        check("WHO essential medicine fact on the In-depth page", "who essential medicine" in text and "yes" in text)
        await go(pg, "#/ref/drug/amoxicillin/names")
        text = await pg.inner_text("#main")
        check("names page: WHO list section with eEML links, binding PDF lists and CC BY 3.0 IGO attribution",
              "who model list of essential medicines" in text.lower() and "CC BY 3.0 IGO" in text and "binding versions" in text
              and await pg.evaluate("[...document.querySelectorAll('a')].some(a => a.href.startsWith('https://list.essentialmeds.org/medicines/'))"))
        await go(pg, "#/explore/medicine/amoxicillin")
        check("Simple page says the medicine is on WHO's list and links to WHO's entry", "essential medicines" in await pg.inner_text("#main")
              and await pg.evaluate("[...document.querySelectorAll('a')].some(a => a.href.startsWith('https://list.essentialmeds.org/'))"))
        await go(pg, "#/ref/drugs?has=eml")
        shown = await pg.inner_text("#count")
        check("WHO-list filter count matches the data", f"{sum(1 for r in index_rows if r[5] & 1024):,}" in shown, shown)
        await go(pg, "#/ref/drug/atorvastatin/uses")
        check("US medicine: FDA Drug Shortages link with the scope note", "does not copy or check" in await pg.inner_text("#main")
              and await pg.evaluate("[...document.querySelectorAll('a')].some(a => a.href.startsWith('https://www.accessdata.fda.gov/scripts/drugshortages/'))"))
        await go(pg, "#/ref/families?q=gliptin")
        text = await pg.inner_text("#main")
        check("families page: search finds the DPP-4 family in approval order, with compare links", "Sitagliptin" in text and "earliest in these records" in text
              and text.index("Sitagliptin") < text.index("Linagliptin") and await pg.evaluate("!!document.querySelector('a[href^=\"#/ref/compare/sitagliptin/\"]')"))
        await go(pg, "#/ref/compare/atorvastatin/rosuvastatin")
        text = await pg.inner_text("#main")
        check("compare page: both medicines in one table, swap link, dates explained", "Atorvastatin" in text and "Rosuvastatin" in text and "Swap sides" in text
              and "measure different things" in text and await pg.evaluate("document.querySelectorAll('table.cmp tbody tr').length >= 10"))
        await go(pg, "#/ref/compare")
        await pg.fill(".cmp-pick[data-slot=a] input", "lovast")
        await pg.wait_for_selector(".cmp-pick[data-slot=a] .suggest a", timeout=5000)
        check("compare picker suggests medicines", "lovastatin" in (await pg.inner_text(".cmp-pick[data-slot=a] .suggest")).lower())
        await go(pg, "#/ref/drug/sotorasib/binding")
        text = await pg.inner_text("#main")
        check("covalent medicine: binding page explains the covalent bond and the reacted ligand", "Covalent binding" in text and "Cys 12" in text and "reacted form" in text)
        await go(pg, "#/explore/quiz")
        firsts = set()
        for _ in range(6):
            await pg.reload(); await pg.wait_for_selector(".answer")
            firsts.add(await pg.evaluate("document.querySelector('.answer').dataset.k"))
        check("quiz shuffles the answers (the right one is not always first)", len(firsts) > 1, str(firsts))
        check("no script errors, missing files or outside requests on the v5.24 pages", not log["errors"] and not log["missing"] and not log["external"],
              str({k: v[:3] for k, v in log.items() if v}))

    # 8c. v5.25: real page addresses, link previews, share and cite, privacy, paid links off
    async with open_site(SITE) as (pg, log):
        await go_path(pg, "/medicine/aspirin/")
        check("a real medicine address opens the interactive Simple page", await pg.inner_text("h1") == "Aspirin" and await pg.evaluate("!!document.querySelector('.share-panel')"))
        html0 = (SITE / "medicine" / "aspirin" / "index.html").read_text()
        check("aspirin's static page: canonical, Open Graph image, Twitter card, JSON-LD and the facts with sources, before any script runs",
              '<link rel="canonical" href="' in html0 and 'og:image' in html0 and 'summary_large_image' in html0 and '"@type": "MedicalWebPage"' in html0
              and "<h1>Aspirin</h1>" in html0 and "How it works" in html0 and "https://www.ebi.ac.uk/chembl/" in html0)
        check("Simple page share panel: copy link and a citation, no social-network links for students",
              await pg.evaluate("!!document.querySelector('[data-share=copy]') && !!document.querySelector('[data-share=cite]') && !document.querySelector('.share-link')")
              and "/medicine/aspirin/" in await pg.inner_text(".cite-text"))
        await pg.focus(".skip"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(300)
        check("the skip link stays on the page (the page base is the site root)", pg.url.rstrip("#main").endswith("/medicine/aspirin/") and await pg.inner_text("h1") == "Aspirin", pg.url)
        await go(pg, "#/ref/drug/aspirin")
        check("In-depth page share panel: plain links to email and social networks (no scripts loaded) and an APA citation",
              await pg.evaluate("document.querySelectorAll('.share-link').length") >= 5 and "Retrieved" in await pg.inner_text(".cite-text")
              and await pg.evaluate("[...document.querySelectorAll('.share-link')].every(a => a.rel.includes('noopener'))"))
        await go(pg, "#/privacy")
        check("privacy page says there is no tracking and what stays on the device", "No cookies, no analytics" in await pg.inner_text("#main") and "local storage" in await pg.inner_text("#main"))
        await go(pg, "#/share")
        check("share page: one-line description, link code to copy, the share picture and the feed", "Link to it" in await pg.inner_text("#main")
              and await pg.evaluate("!!document.querySelector('img.og-preview') && !!document.querySelector('a[href=\"feed.xml\"]')"))
        await go_path(pg, "/medicines/")
        check("the A to Z address opens the medicine list", await pg.evaluate("location.pathname") == "/medicines/" and "Medicines" in await pg.inner_text("#main"))
        check("no script errors, missing files or outside requests on the v5.25 pages", not log["errors"] and not log["missing"] and not log["external"], str({k: v[:3] for k, v in log.items() if v}))

    # 8d. v5.26: one start-page grid of six lenses, neutral switcher, one retry on a dropped connection, records panel instead of a dead end
    fams = json.loads((SITE / "data" / "family_trees.json").read_text())["families"]
    in_family = {m["id"] for f in fams for m in f["members"]}
    no_story = None
    for f in sorted((SITE / "data" / "drugs").glob("*.json")):
        d = json.loads(f.read_text())
        if not d.get("stories") and not d.get("origin") and d["id"] in in_family and (d.get("us") or {}).get("first_generic_date") and (d.get("us") or {}).get("counts", {}).get("ANDA"):
            no_story = d
            break
    async with open_site(SITE) as (pg, log):
        await go(pg, "#/")
        cards = await pg.evaluate("[...document.querySelectorAll('.lens-grid a.role')].map(a => a.getAttribute('href'))")
        heads = await pg.evaluate("[...document.querySelectorAll('#main h2')].map(h => h.textContent.trim())")
        check("start page: all six lenses in one grid, no Simple / In-depth split (Option 2)", len(cards) == 6 and len(set(cards)) == 6 and not {"Simple", "In-depth"} & set(heads)
              and "How are you exploring today?" in await pg.inner_text("#main"), f"{cards} {heads}")
        await go(pg, "#/explore")
        to_ref = await pg.evaluate("document.querySelector('a.door')?.textContent.trim()")
        await go(pg, "#/ref")
        to_exp = await pg.evaluate("document.querySelector('a.door')?.textContent.trim()")
        check("switcher reads 'Reference →' and '← Explore'", to_ref == "Reference →" and to_exp == "← Explore", f"{to_ref} / {to_exp}")
        if no_story:
            await go(pg, f"#/explore/medicine/{no_story['id']}/made")
            text = await pg.inner_text("#main")
            years = sorted(str(x)[:4] for x in [(no_story.get("us") or {}).get("first_date"), (no_story.get("eu") or {}).get("first_authorised"),
                                                (no_story.get("ca") or {}).get("first_marketed"), (no_story.get("jp") or {}).get("first_new_ingredient")] if x)
            check("made page without a discovery story shows what the records say (oldest date, first generic, family) and sources",
                  await pg.evaluate("!!document.querySelector('#records-history .src a, #records-history a[href^=\"https://\"]')")
                  and "We have not written" not in text and f"The oldest date in our records is {years[0]}" in text
                  and f"first US generic copy was approved in {no_story['us']['first_generic_date'][:4]}" in text and "share the name ending" in text, no_story["id"])
        else:
            check("made page without a discovery story shows what the records say", False, "no suitable medicine found")
        check("v5.26 pages: no script errors, missing files or outside requests", not log["errors"] and not log["missing"] and not log["external"], str({k: v[:3] for k, v in log.items() if v}))
    async with open_site(SITE) as (pg, log):
        await go(pg, "#/")
        drops = {"n": 0}
        async def drop_once(r):
            if drops["n"] == 0:
                drops["n"] += 1
                return await r.abort()
            await r.fallback()
        await pg.route("**/data/drugs/ibuprofen.json", drop_once)
        await go(pg, "#/explore/medicine/ibuprofen")
        check("a dropped connection is tried once more and the page still opens", drops["n"] == 1 and (await pg.inner_text("h1")).strip() == "Ibuprofen", str(drops))
        async def drop_all(r):
            await r.abort()
        await pg.route("**/data/drugs/naproxen.json", drop_all)
        await go(pg, "#/explore/medicine/naproxen")
        h1 = (await pg.inner_text("h1")).strip()
        has_retry = await pg.evaluate("!!document.querySelector('#retry-route')")
        await pg.unroute("**/data/drugs/naproxen.json", drop_all)
        await pg.evaluate("document.getElementById('app').dataset.ready = ''")
        if has_retry:
            await pg.click("#retry-route")
            await pg.wait_for_function("h => document.getElementById('app').dataset.ready === h", arg="#/explore/medicine/naproxen", timeout=15000)
        check("when the connection stays down: 'Connection interrupted' with a Try again button that reloads the page",
              h1 == "Connection interrupted" and has_retry and (await pg.inner_text("h1")).strip() == "Naproxen", h1)
        await go(pg, "#/explore/medicine/not-a-medicine")
        check("a missing page still says it could not be found (not 'Connection interrupted')", "couldn't find" in await pg.inner_text("h1"))

    # 9. phone width: no page scrolls sideways, nothing is cut off at the edge (wide tables and the decade chart
    #    scroll inside their own box), and links and buttons that are not inline text are at least 24 px tall
    PHONE_PAGES = ["#/", "#/explore", "#/explore/medicines", "#/explore/medicine/aspirin", "#/explore/medicine/aspirin/molecule",
                   "#/explore/medicine/celecoxib/works", "#/explore/medicine/semaglutide", "#/explore/teach", "#/explore/history", "#/explore/quiz",
                   "#/explore/made", "#/ref", "#/ref/clinician", "#/ref/chemist", "#/ref/industry", "#/ref/drugs", "#/ref/drug/atorvastatin",
                   "#/ref/drug/atorvastatin/structure", "#/ref/drug/atorvastatin/binding", "#/ref/drug/pembrolizumab/binding",
                   "#/ref/drug/semaglutide/names", "#/ref/drug/atorvastatin/approvals", "#/ref/topics", "#/ref/data", "#/fund",
                   "#/ref/families", "#/ref/compare/atorvastatin/rosuvastatin", "#/ref/drug/amoxicillin/names", "#/ref/drug/sotorasib/binding",
                   "#/privacy", "#/share"] + ([f"#/explore/medicine/{no_story['id']}/made"] if no_story else [])
    async with open_site(SITE, width=390, height=844) as (pg, log):
        over, cut, small = {}, {}, {}
        for r in PHONE_PAGES:
            await go(pg, r)
            res = await pg.evaluate("""() => {
              const W = document.documentElement.clientWidth;
              const cut = [...document.querySelectorAll('body *')].filter(e => { const b = e.getBoundingClientRect(); return b.width > 0 && b.right > W + 1; })
                .filter(e => !e.closest('.tbl-wrap, .decades, details:not([open])')).map(e => e.tagName.toLowerCase());
              const small = [...document.querySelectorAll('a, button, select, input')].filter(e => { const b = e.getBoundingClientRect();
                return b.width > 0 && b.height > 0 && b.left >= 0 && b.height < 24 && getComputedStyle(e).display !== 'inline'; }).map(e => e.textContent.trim().slice(0, 20));
              return {over: document.documentElement.scrollWidth - W, cut, small}; }""")
            if res["over"] > 0: over[r] = res["over"]
            if res["cut"]: cut[r] = res["cut"][:3]
            if res["small"]: small[r] = res["small"][:3]
        check(f"phone width (390 px): no sideways scrolling on {len(PHONE_PAGES)} page types", not over, str(over))
        check("phone width: nothing cut off at the right edge (wide content scrolls inside its own box)", not cut, str(cut)[:200])
        check("phone width: links and buttons outside running text are at least 24 px tall", not small, str(small)[:200])
        check("phone width: no script errors", not log["errors"], str(log["errors"][:2]))

    # 9b. accessibility: axe-core (tests/vendor, MPL-2.0) finds no WCAG 2.2 A/AA violations, at desktop and phone width and in dark mode
    axe_js = (pathlib.Path(__file__).parent / "vendor" / "axe.min.js").read_text()
    AXE_RUN = "async () => (await axe.run(document, {runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']})).violations.map(v => v.id + ' x' + v.nodes.length)"
    for width, scheme in ((1280, "light"), (390, "light"), (1280, "dark")):
        found = {}
        async with open_site(SITE, width=width, height=900, color_scheme=scheme) as (pg, log):
            for r in PHONE_PAGES:
                await go(pg, r)
                if not await pg.evaluate("!!window.axe"):
                    await pg.add_script_tag(content=axe_js)
                v = await pg.evaluate(AXE_RUN)
                if v: found[r] = v
        check(f"accessibility (axe-core, WCAG 2.2 AA) at {width} px, {scheme} mode: no violations on {len(PHONE_PAGES)} page types", not found, str(found)[:300])

    # 10. classic labs page still runs
    async with open_site(SITE) as (pg, log):
        await pg.goto("https://pillbypill.test/legacy/index.html#how/moa-engine"); await pg.wait_for_timeout(1200)
        check("classic labs page loads without errors or outside requests", not log["errors"] and not log["external"] and not log["missing"], str((log["errors"] + log["missing"])[:2]))

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
    sys.exit(1 if failed else 0)


asyncio.run(main())
