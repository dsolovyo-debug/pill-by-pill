"""Offline unit tests for the pipeline's text handling: no network, no data files.
Each case is a real string from a source that once went wrong (or nearly did).
Usage: python3 tests/test_pipeline.py"""
import pathlib, sys

PIPE = pathlib.Path(__file__).resolve().parent.parent / "pipeline"
sys.path.insert(0, str(PIPE))
sys.argv = [sys.argv[0], "/tmp", "https://example.invalid/list.pdf"]      # read_pmda_list reads its arguments at import
import names                                          # noqa: E402
import read_pmda_list as pmda                         # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok)))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail and not ok else ""))


# salt words: strip counter-ions, never stop at a bare metal, keep esters
check("salt words: 'ATORVASTATIN CALCIUM' gives 'ATORVASTATIN'", "ATORVASTATIN" in names.normalise_fda_name("ATORVASTATIN CALCIUM"))
check("salt words: 'ZINC GLUCONATE' never becomes 'ZINC'", "ZINC" not in names.normalise_fda_name("ZINC GLUCONATE"))
check("salt words: 'POTASSIUM HYDROGEN CARBONATE' never becomes 'POTASSIUM'", "POTASSIUM" not in names.normalise_fda_name("POTASSIUM HYDROGEN CARBONATE"))
check("salt words: an ester is a different medicine ('MOMETASONE FUROATE' stays whole)", names.normalise_fda_name("MOMETASONE FUROATE")[-1] == "MOMETASONE FUROATE")
check("EMA's comma before a hydrate is read as a salt ('DANTROLENE SODIUM, HEMIHEPTAHYDRATE' gives 'DANTROLENE')",
      "DANTROLENE" in names.normalise_fda_name("DANTROLENE SODIUM, HEMIHEPTAHYDRATE"))
check("biosimilar suffix removed ('DENOSUMAB-BMWO')", "DENOSUMAB" in names.normalise_fda_name("DENOSUMAB-BMWO"))

# EMA-only types: only from ATC codes, conjugate payload words and WHO stems in short names
ct = names.classify_ema_type
check("two-word conjugate is a conjugate, not a plain antibody (brentuximab vedotin)", ct("brentuximab vedotin", {})[0] == "Antibody drug conjugate")
check("a payload word without an antibody is not called a conjugate", ct("vedotin", {})[0] != "Antibody drug conjugate")
check("ATC J07 is a vaccine component", ct("something", {"atc": "J07BB02"}) == ("Vaccine component", "EMA ATC code J07BB02"))
check("-mab, -cel, -vec, -siran stems", [ct(n, {})[0] for n in ("nimotuzumab", "lisocabtagene maraleucel", "nadofaragene firadenovec", "plozasiran")] ==
      ["Antibody", "Cell", "Gene", "Oligonucleotide"])
check("-ase is an enzyme, -cog a protein", ct("condoliase", {})[0] == "Enzyme" and ct("trenonacog alfa", {})[0] == "Protein")
check("defibrotide is not a peptide despite -tide", ct("defibrotide", {})[0] == "Unknown")
check("anamorelin is not a peptide (-relin is not used)", ct("anamorelin", {})[0] == "Unknown")
check("a long descriptive name is not typed from a stem ('... thymidine kinase gene')",
      ct("adenovirus-mediated herpes simplex virus-thymidine kinase gene", {})[0] == "Unknown")

# v5.18: ATC rules from the 2026-11-18 spec, narrowed where the WHO ATC groups are mixed (checked 2026-11-19 on atcddd.fhi.no)
check("ATC V09/V10 give a radiopharmaceutical and say which group", ct("Gallium (68Ga) chloride", {"atc": "V09X"}) == ("Radiopharmaceutical", "EMA ATC code V09X (diagnostic radiopharmaceuticals)")
      and ct("radium (223Ra) dichloride", {"atc": "V10XX03"})[0] == "Radiopharmaceutical")
check("a radiolabelled peptide under V10 is a radiopharmaceutical, not a peptide from -tide", ct("lutetium (177Lu) oxodotreotide", {"atc": "V10XX04"})[0] == "Radiopharmaceutical")
check("ATC V01 gives an allergen extract (EMA's peanut products)", ct("Arachis hypogaea extract", {"atc": "V01AA08"})[0] == "Allergen extract"
      and ct("Defatted powder of Arachis hypogaea L., semen (peanuts)", {"atc": "V01"})[0] == "Allergen extract")
check("gene therapies in ATC B02BD and A16AB stay gene or cell therapies (INN stems are read before those codes)",
      ct("etranacogene dezaparvovec", {"atc": "B02BD16"})[0] == "Gene" and ct("atidarsagene autotemcel", {"atc": "A16AB21"})[0] == "Cell"
      and ct("eladocagene exuparvovec", {"atc": "A16AB26"})[0] == "Gene")
check("a gene-therapy code with a descriptive name is not called a protein", ct("adeno-associated virus vector encoding factor IX", {"atc": "B02BD18"})[0] == "Unknown")
check("listed protein codes type descriptive names (factor VIII, albumin, enzyme)", ct("human coagulation factor VIII", {"atc": "B02BD02"})[0] == "Protein"
      and ct("human albumin solution", {"atc": "B05AA01"})[0] == "Protein" and ct("recombinant human enzyme", {"atc": "A16AB20"})[0] == "Enzyme")
check("B05AA plasma substitutes that are not proteins stay Unknown (gelatin, starch, dextran)",
      [ct(n, {"atc": a})[0] for n, a in (("succinylated gelatin", "B05AA06"), ("hydroxyethyl starch", "B05AA07"), ("dextran 70", "B05AA05"))] == ["Unknown"] * 3)
check("a code not on the list stays Unknown (no guessing from a group)", ct("human fibrinogen", {"atc": "B02BC30"})[0] == "Unknown" and ct("new factor", {"atc": "B02BD99"})[0] == "Unknown")
check("ATC L01XL alone does not say cell or gene, so a descriptive name stays Unknown", ct("autologous melanoma-derived tumor infiltrating lymphocytes, ex vivo-expanded", {"atc": "L01XL"})[0] == "Unknown")

# v5.18: origin stories are curated data with https sources, and each names one medicine
import json as _json                                  # noqa: E402
_orig = _json.loads((PIPE / "origin_stories.json").read_text(encoding="utf-8"))
check("origin stories: 60 entries (9 from v5.18, 24 checked in v5.24, 27 checked in v5.26), each with category, Simple and In-depth text and https sources", len(_orig["stories"]) == 60 and all(
      o["medicine"] and o["category"] and o["simple"] and o["expert"] and o["sources"] and all(s["url"].startswith("https://") and s["label"] for s in o["sources"]) for o in _orig["stories"]))
check("origin stories: statements the cited sources did not support are gone (Borneo, Norway, 'defend its territory', 'eats only a few times a year')",
      not any(w in (o["simple"] + o["expert"]).lower() for o in _orig["stories"] for w in ("borneo", "norway", "territory", "few times a year", "golf course in japan")))

# Japanese names
check("Japanese counter-ions removed ('Etrasimod L-arginine', 'Vorasidenib citric acid hydrate')",
      names.jp_clean("Etrasimod L-arginine") == "ETRASIMOD" and names.jp_clean("Vorasidenib citric acid hydrate") == "VORASIDENIB")
check("'alpha' read as 'alfa' ('Turoctocog alpha')", names.jp_clean("Turoctocog alpha") == "TUROCTOCOG ALFA")
check("one-letter check catches PMDA typos and spares different names",
      names.near("SILODOSHIN", "SILODOSIN") and names.near("DIQUAFOSOI", "DIQUAFOSOL") and not names.near("IMATINIB", "NILOTINIB") and not names.near("SITAGLIPTIN", "SAXAGLIPTIN"))

# PMDA list parsing
check("dates in all three PMDA styles", [pmda.parse_date(s) for s in ("May 19, 2025", "Jun. 24, 2025", "14-Feb-05")] == ["2025-05-19", "2025-06-24", "2005-02-14"])
check("unreadable date gives None, not a guess", pmda.parse_date("Spring 2005") is None)
check("glyph ids in older pages are parentheses", pmda.fix_glyphs("(cid:7330)Nihon Ciba-Geigy K.K.(cid:7331)") == "(Nihon Ciba-Geigy K.K.)")
check("doubled bold letters are undone ('Sertraline hhyyddrroocchhlloorriiddee')", pmda.undouble("Sertraline hhyyddrroocchhlloorriiddee") == "Sertraline hydrochloride")
check("ordinary words with double letters are left alone ('Rabbit', 'Hemophilia')", pmda.undouble("Rabbit Hemophilia accessory") == "Rabbit Hemophilia accessory")
raw, ingredient = pmda.clean_ingredient("Tralokinumab ((ggeenneettiiccaall recombination)")
check("'(genetical recombination)' removed even when doubled or cut off", ingredient == "Tralokinumab", ingredient)
check("a hyphen broken at a line end is rejoined ('Peginterferon alfa- 2b')", pmda.clean_ingredient("Peginterferon alfa- 2b")[1] == "Peginterferon alfa-2b")
brands, applicants = pmda.split_brands("58Femara\nFemara 2.5 mg Tablet\n(cid:7330)Novartis Pharma K.K.(cid:7331)")
check("row number glued to a brand is dropped, applicant read from glyph parentheses", brands == ["Femara", "Femara 2.5 mg Tablet"] and applicants == ["Novartis Pharma K.K."], f"{brands} {applicants}")
brands, _ = pmda.split_brands("Wegovy Subcutaneous Injection 0.25 mg SD (1) Wegovy Subcutaneous Injection 0.5 mg SD\n(Novo Nordisk Pharma Ltd.)")
check("'(1) ... (2) ...' lists are split into products", len(brands) == 2 and all(b.startswith("Wegovy") for b in brands), str(brands))
brands, _ = pmda.split_brands("Vabysmo Solution for Intravitreal Injection 120\nmg/mL\n(Chugai Pharmaceutical Co., Ltd.)")
check("a unit wrapped onto the next line is rejoined", brands == ["Vabysmo Solution for Intravitreal Injection 120 mg/mL"], str(brands))

# v5.17 checks: page-break continuations with wrapped brands, extra_chembl cache idempotency, composite has filters, and UI/doc parity
pages = [
    (10, [[
        ["Category 1", "May 19, 2025", "12", "Ozempic Subcutaneous Injection 0.25 mg SD\n(Novo Nordisk Pharma Ltd.)", "Approval", "Semaglutide (genetical", "A drug with a new active"]
    ]]),
    (11, [[
        ["", "", "", "Ozempic Subcutaneous Injection 0.5 mg SD\n(Novo Nordisk Pharma Ltd.)", "", "recombination)", "ingredient [Orphan drug]"]
    ]]),
]
merged_rows = pmda.rows_from_pages(pages)
check("page-break continuation merges wrapped brand lines, ingredient half and flags into the previous row",
      len(merged_rows) == 1 and merged_rows[0]["brands"] == ["Ozempic Subcutaneous Injection 0.25 mg SD", "Ozempic Subcutaneous Injection 0.5 mg SD"]
      and merged_rows[0]["applicants"] == ["Novo Nordisk Pharma Ltd."] and merged_rows[0]["ingredient"] == "Semaglutide"
      and merged_rows[0]["new_active_ingredient"] is True and merged_rows[0]["orphan"] is True, str(merged_rows))

same_page = [
    (10, [[
        ["Category 1", "May 19, 2025", "12", "Brand A\n(Company A)", "Approval", "Drug A", "A drug with a new active ingredient"],
        ["", "", "13", "Brand B\n(Company B)", "", "Drug B", ""],
    ]]),
]
same_page_rows = pmda.rows_from_pages(same_page)
check("two products on the same page with blank date and kind stay separate rows (never merged)",
      len(same_page_rows) == 2 and [r["ingredient"] for r in same_page_rows] == ["Drug A", "Drug B"], str(same_page_rows))

note_only = [
    (10, [[["Category 1", "May 19, 2025", "12", "Brand A\n(Company A)", "Approval", "Drug A", "A drug with a new active"]]]),
    (11, [[["", "", "", "", "", "", "ingredient [Orphan drug]"]]]),
]
note_rows = pmda.rows_from_pages(note_only)
check("a page-break row whose ingredient cell is blank (only the note wrapped) still joins the row above",
      len(note_rows) == 1 and note_rows[0]["ingredient"] == "Drug A" and note_rows[0]["new_active_ingredient"] is True
      and note_rows[0]["orphan"] is True, str(note_rows))
blank_mid = [
    (10, [[["Category 1", "May 19, 2025", "12", "Brand A\n(Company A)", "Approval", "Drug A", ""],
           ["", "", "", "", "", "", "stray text"]]]),
]
blank_rows = pmda.rows_from_pages(blank_mid)
check("a blank-ingredient row in the middle of a page is still skipped (never joined)",
      len(blank_rows) == 1 and blank_rows[0]["ingredient"] == "Drug A" and blank_rows[0]["new_active_ingredient"] is False, str(blank_rows))
numbered_new_page = [
    (10, [[["Category 1", "May 19, 2025", "12", "Brand A\n(Company A)", "Approval", "Drug A", ""]]]),
    (11, [[["", "", "13", "Brand B\n(Company B)", "", "Drug B", ""]]]),
]
numbered_rows = pmda.rows_from_pages(numbered_new_page)
check("a new page starting with a numbered product row (even with blank date and kind) stays a separate row",
      len(numbered_rows) == 2 and [r["ingredient"] for r in numbered_rows] == ["Drug A", "Drug B"], str(numbered_rows))

ROOT = PIPE.parent
fec_src = (ROOT / "pipeline" / "fetch_extra_chembl.py").read_text()
check("fetch_extra_chembl writes all cached ChEMBL matches so merged entries are not dropped on re-runs",
      'for k, v in sorted(cache.items()) if "chembl_id" in v' in fec_src)

sys.path.insert(0, str(ROOT))
import app as server  # noqa: E402
check("app.py composite has filters (nous, both, euonly, all4) match reference.js bitmask rules",
      server.HAS_FILTERS["nous"](8) and not server.HAS_FILTERS["nous"](4)
      and server.HAS_FILTERS["both"](4 | 8) and not server.HAS_FILTERS["both"](4)
      and server.HAS_FILTERS["euonly"](8) and not server.HAS_FILTERS["euonly"](4 | 8)
      and server.HAS_FILTERS["all4"](4 | 8 | 256 | 512) and not server.HAS_FILTERS["all4"](4 | 8 | 256))

ref_src = (ROOT / "site" / "js" / "reference.js").read_text()
exp_src = (ROOT / "site" / "js" / "explore.js").read_text()
arch_src = (ROOT / "ARCHITECTURE.md").read_text()
check("reference.js #/ref/drugs Records column includes CA and JP badges and PMDA in the First approved note",
      'd.flags & data.FLAG.ca && "CA"' in ref_src and 'd.flags & data.FLAG.jp && "JP"' in ref_src and "PMDA's list (new active ingredient)" in ref_src)
check("explore.js #/explore/history decade note mentions EMA's table and PMDA's list",
      "EMA's table or PMDA's list" in exp_src)
check("stale non-US approval and antibody-antigen debt notes are removed",
      "no per-country approval data outside the US" not in arch_src and "Antibody-antigen complexes are not animated yet" not in ref_src)

# v5.24: the eEML page parser, the covalent chemistry check, and the WHO name candidates
import importlib.util                                  # noqa: E402


def load(name):
    spec = importlib.util.spec_from_file_location(name, PIPE / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


eml = load("fetch_who_eml")
page = ('<h5 class="medicine-name" title="Abacavir + lamivudine"><a href="https://list.essentialmeds.org/medicines/947">General information</a></h5>'
        '<div class="section-name">Fixed-dose combinations &gt; Antiretrovirals</div><li>Oral &gt; Solid: 120 mg (as sulfate) + 60 mg</li>'
        '<h5 class="medicine-name" title="Hydroxyurea (hydroxycarbamide)"><a href="https://list.essentialmeds.org/medicines/12">General information</a></h5>'
        '<div class="section-name">Medicines for sickle-cell disease</div><div class="section-name">Medicines for sickle-cell disease</div>')
rows = eml.parse(page)
check("eEML parser: names, links, sections (deduplicated), combination parts and '(as ...)' salt forms",
      [r["name"] for r in rows] == ["Abacavir + lamivudine", "Hydroxyurea (hydroxycarbamide)"] and rows[0]["parts"] == ["Abacavir", "lamivudine"]
      and rows[0]["combination"] and rows[0]["url"].endswith("/947") and rows[0]["as_forms"] == ["sulfate"]
      and rows[1]["sections"] == ["Medicines for sickle-cell disease"] and not rows[1]["combination"], str(rows))
try:
    cov = load("fetch_binding_covalent")
    acryl = "C=CC(=O)Nc1ccc(Oc2ccccc2)cc1"                 # an acrylamide warhead on a small aromatic core
    reacted = "CCC(=O)Nc1ccc(Oc2ccccc2)cc1"                # the same molecule after the double bond has reacted
    check("covalent check: the reacted form of a medicine matches it; an unrelated compound does not",
          cov.same_chemistry(acryl, reacted) == 1.0 and cov.same_chemistry(acryl, "Cn1cnc2c1c(=O)n(C)c(=O)n2C") is None)
except ImportError as e:
    check("covalent check (needs rdkit and gemmi)", False, str(e))

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
