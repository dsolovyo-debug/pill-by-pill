#!/bin/sh
# Run every test against a built site folder (default: site). Needs: pip install playwright fastapi httpx && playwright install chromium
SITE=${1:-site}
python3 tests/test_pipeline.py && python3 tests/test_data.py "$SITE" && python3 tests/test_site.py "$SITE" && python3 tests/test_app.py "$SITE"
