"""Shared test helper: serve the built site to headless Chromium under a public-style host name (as on Netlify, not localhost)
and record script errors and any request that leaves the site."""
import mimetypes, os
from contextlib import asynccontextmanager
from playwright.async_api import async_playwright

HOST = "https://pillbypill.test/"


@asynccontextmanager
async def open_site(folder, width=1280, height=900, overrides=None, color_scheme="light"):
    """Yield (page, log). overrides maps a site path to replacement text (used to test monetization settings)."""
    overrides = overrides or {}
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(viewport={"width": width, "height": height}, color_scheme=color_scheme)
        page = await ctx.new_page()
        log = {"errors": [], "external": [], "missing": []}

        async def route(r):
            url = r.request.url
            if not url.startswith(HOST):
                log["external"].append(url)
                return await r.abort()
            rel = url[len(HOST):].split("?")[0].split("#")[0] or "index.html"
            if rel.endswith("/"):
                rel += "index.html"                     # as Netlify serves /medicine/aspirin/
            if rel in overrides:
                return await r.fulfill(body=overrides[rel], content_type="application/json")
            path = os.path.join(folder, rel)
            if os.path.isfile(path):
                ctype = "text/javascript" if rel.endswith(".js") else mimetypes.guess_type(path)[0] or "application/octet-stream"
                return await r.fulfill(path=path, content_type=ctype)
            log["missing"].append(rel)
            return await r.fulfill(status=404, body="not found")

        await page.route("**/*", route)
        page.on("pageerror", lambda e: log["errors"].append(str(e)))
        page.on("console", lambda m: log["errors"].append(m.text) if m.type == "error" and "404" not in m.text else None)
        try:
            yield page, log
        finally:
            await browser.close()


async def go_path(page, path):
    """Open a real page address (built by build_static_pages.py) and wait until the app has rendered it."""
    await page.goto(HOST + path.lstrip("/"))
    await page.wait_for_function("p => document.getElementById('app').dataset.ready === p", arg="/" + path.lstrip("/"), timeout=15000)


async def go(page, hash_route):
    """Open a route and wait until the router has finished rendering it."""
    if page.url.startswith(HOST):
        await page.evaluate("""h => { document.getElementById('app').dataset.ready = '';
            if (location.hash === h) dispatchEvent(new HashChangeEvent('hashchange')); else location.hash = h; }""", hash_route)
    else:
        await page.goto(HOST + "index.html" + hash_route)
    await page.wait_for_function("h => document.getElementById('app').dataset.ready === h", arg=hash_route, timeout=15000)
