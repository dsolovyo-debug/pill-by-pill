"""Data checks (no browser): every fact block must carry a source link, and the catalogue must hang together.
Usage: python3 tests/test_data.py <site folder>"""
import collections, re, json, pathlib, sys

SITE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site")
D = SITE / "data"
is_url = lambda u: isinstance(u, str) and u.startswith("https://")
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


index = json.loads((D / "drug_index.json").read_text())["rows"]
stats = json.loads((D / "catalogue_stats.json").read_text())
drugs = {f.stem: json.loads(f.read_text()) for f in (D / "drugs").glob("*.json")}

check("index and drug files agree", {r[0] for r in index} == set(drugs) and len(index) == stats["total"], f"{len(index)} medicines")
check("catalogue covers all of Drugs@FDA, ChEMBL approved and EMA's table", stats["total"] > 3300 and stats["fda_applications"] > 29000, f"{stats['fda_applications']} applications")
bad = [k for k, d in drugs.items() if not d["sources"] or not all(is_url(s["url"]) for s in d["sources"])]
check("every medicine has at least one https source link", not bad, f"{len(bad)} without")
bad = [k for k, d in drugs.items() if d.get("structure") and not (is_url(d["structure"]["source_url"]) and d["structure"]["checked"] and d["structure"]["inchikey"])]
check("every structure has a source link, InChIKey and checked date", not bad, f"{sum(1 for d in drugs.values() if d.get('structure'))} structures")
bad = [k for k, d in drugs.items() if d.get("graphics", {}).get("drawing") != (SITE / "mol" / f"{k}.json").exists()]
check("drawing flag matches the mol/ files", not bad, f"{len(list((SITE / 'mol').glob('*.json')))} files")
bad = [k for k, d in drugs.items() if d.get("graphics", {}).get("drawing") and not d.get("structure")]
check("nothing is drawn without a sourced structure", not bad)
bad = [k for k, d in drugs.items() for m in d["mechanisms"] if not m["refs"]]
check("mechanisms without a reference", len(bad) < 0.05 * sum(len(d["mechanisms"]) for d in drugs.values()), f"{len(bad)} of {sum(len(d['mechanisms']) for d in drugs.values())}")
bad = [k for k, d in drugs.items() for i in d["indications"] if not i["refs"]]
check("every listed indication has a label or regulator reference", not bad)
bad = [k for k, d in drugs.items() if d["us"] and not is_url(d["us"]["source_url"])]
check("every US block has a source link", not bad, f"{stats['with_us_record']} with US record")
matched = sum(1 for d in drugs.values() if d.get("structure") and d["structure"].get("pubchem_cid"))
check("most structures cross-checked in PubChem", matched > 0.9 * stats["with_structure"], f"{matched} of {stats['with_structure']}")
for name in ("aspirin", "atorvastatin", "semaglutide", "adalimumab", "nusinersen", "paclitaxel"):
    check(f"well-known drug present: {name}", name in drugs)
check("aspirin structure is aspirin", drugs["aspirin"]["structure"]["inchikey"] == "BSYNRYMUTXBXSQ-UHFFFAOYSA-N" and drugs["aspirin"]["structure"]["pubchem_cid"] == 2244)

bound = {k: d["binding"] for k, d in drugs.items() if d.get("binding")}
check("binding blocks match the bind/ files", set(bound) == {f.stem for f in (SITE / "bind").glob("*.json")}, f"{len(bound)} binding sites")
check("every binding site names its PDB entry, method, resolution, target and checked date",
      all(is_url(b["url"]) and b["pdb_id"] and b["resolution"] and b["method"] and b["target"] and b["checked"] for b in bound.values()))
limits = {"polar": 3.5, "nonpolar": 4.0, "metal": 2.8, "covalent": 2.3}
sites = {k: json.loads((SITE / "bind" / f"{k}.json").read_text()) for k in bound}
protein_sites = {k: s for k, s in sites.items() if s.get("kind") == "protein"}
check("antibody and protein interfaces: every medicine atom belongs to a labelled residue, and the chain is tied to the medicine",
      all(len(s["ligand"]["owner"]) == len(s["ligand"]["atoms"]) and max(s["ligand"]["owner"]) < len(s["ligand"]["labels"]) for s in protein_sites.values())
      and all("sequence matches" in bound[k]["match"] or "sequence is identical" in bound[k]["match"] or "named after" in bound[k]["match"] for k in protein_sites), f"{len(protein_sites)} interfaces")
check("pembrolizumab is shown on PD-1, matched by sequence", "pembrolizumab" in protein_sites and "Programmed cell death protein 1" in bound["pembrolizumab"]["target"] and "sequence" in bound["pembrolizumab"]["match"])
bad = [k for k, s in sites.items() if not s["contacts"] or any(c[4] > limits[c[3]] or c[4] < 1.0 for c in s["contacts"])
       or any(c[0] >= len(s["ligand"]["atoms"]) or c[2] >= len(s["residues"][c[1]]["atoms"]) for c in s["contacts"])]
check("every contact is within its stated distance rule and points at real atoms", not bad, f"{sum(len(s['contacts']) for s in sites.values())} contacts")
check("binding sites exist only for drugs with a mechanism and a sourced structure or protein chain", all(drugs[k]["mechanisms"] and (drugs[k].get("structure") or k in protein_sites) for k in bound))
check("atorvastatin is shown in HMG-CoA reductase", "atorvastatin" in bound and "reductase" in bound["atorvastatin"]["target"].lower())
made_notes = [d["manufacturing"] for d in drugs.values() if d.get("manufacturing")]
check("manufacturing notes link to their PubChem section", all(is_url(m["url"]) and m["notes"] > 0 for m in made_notes), f"{len(made_notes)} drugs")

oligos = {k: d["sequence"] for k, d in drugs.items() if d.get("sequence") and "Substance Registration" in (d["sequence"].get("source") or "")}
check("oligonucleotide strands come from FDA's substance registry with a record link", len(oligos) >= 20 and all(is_url(s["source_url"]) and s["checked"] for s in oligos.values()), f"{len(oligos)} oligonucleotides")
pat = [c["sequence"] for c in drugs["patisiran-sodium"]["sequence"]["components"]] if "patisiran-sodium" in drugs else []
check("patisiran strands are the registry's (a hand-typed version differed by one base per strand)", sorted(pat) == ["AUGGAAUACUCUUGGUUACTT", "GUAACCAAGAGUAUUCCAUTT"], str(pat))
check("every sequence block names its source", all(is_url(d["sequence"]["source_url"]) for d in drugs.values() if d.get("sequence")))
sims = json.loads((D / "simulators.json").read_text())
sim_rows = sims["gene_variants"] + sims["interactions"]
check("every explorer statement links to its FDA label and to a drug in the catalogue", all(r["url"].startswith("https://dailymed.nlm.nih.gov/") and r["drug"] in drugs for r in sim_rows), f"{len(sim_rows)} statements")
check("release-profile curves are declared an illustration", "illustration" in sims["release_profiles"]["note"].lower())

eu = {k: d["eu"] for k, d in drugs.items() if d.get("eu")}
check("EU blocks come from EMA's table: every product links to its EMA page and the block names its scope and date",
      len(eu) > 1000 and all(e["data_date"] and "centralised" in e["scope"] and all(p[8].startswith("https://www.ema.europa.eu/") for p in e["products"]) for e in eu.values()), f"{len(eu)} medicines")
sema = drugs["semaglutide"]["eu"]
check("semaglutide: Ozempic authorised in the EU on 2018-02-08", sema["status"] == "Authorised" and sema["first_authorised"] == "2018-02-08" and sema["products"][0][0] == "Ozempic")
check("a nationally licensed medicine (atorvastatin) is not given an EU central record", drugs["atorvastatin"]["eu"] is None)
check("medicines listed only by EMA are in the catalogue with a source", stats["ema_only"] > 100 and all(d["sources"] for d in drugs.values()))

topics = json.loads((D / "topics.json").read_text())
for t in topics:
    rows = json.loads((D / "topics" / f"{t['key']}.json").read_text())
    bad = [r for r in rows if not str(r.get(t["url_field"]) or "").startswith("http")]
    if bad or len(rows) != t["count"]:
        check(f"topic {t['key']}: every row has a source link", False, f"{len(bad)} without")
check("every topic row has a source link", all(str(r.get(t["url_field"]) or "").startswith("http") for t in topics
      for r in json.loads((D / "topics" / f"{t['key']}.json").read_text())), f"{len(topics)} topics, {sum(t['count'] for t in topics)} rows")
quiz = json.loads((D / "quiz.json").read_text())
check("every quiz question has a source link", all(q["url"].startswith("http") for q in quiz), f"{len(quiz)} questions")
made = json.loads((D / "how_made.json").read_text())["types"]
check("how-it-is-made text is sourced or says it is not", all(t["sources"] or "not yet" in t["simple"] or "cannot yet" in t["simple"] for t in made.values()))
money = json.loads((SITE / "config" / "monetization.json").read_text())
check("no monetization scheme lists the student role", all("student" not in s["roles"] for s in money["schemes"].values()))
pep = [drugs[k].get("binding") for k in ("calcitonin-salmon", "glucagon-hydrochloride", "secretin-synthetic-human", "ziconotide-acetate")]
check("peptide interfaces are tied to the medicine by name and a 100% identical chain", all(b and b["kind"] == "protein" and "100% identical over 100%" in b["match"] for b in pep))
exact = [k for k in protein_sites if "sequence is identical" in bound[k]["match"]]
check("a peptide matched by letters alone is known to be unmodified (plain HELM, or FDA's registry lists no modifications)",
      len(exact) >= 3 and all(drugs[k]["sequence"].get("registry_unmodified") or ((drugs[k]["sequence"].get("helm") or "") and "[" not in drugs[k]["sequence"]["helm"].replace("[am]", "").replace("[ac]", "")) for k in exact), str(exact))
sema, lira = drugs["semaglutide"]["sequence"], drugs["liraglutide"]["sequence"]
check("semaglutide and liraglutide share their letters, so the registry's modification sites are what tells them apart",
      sema["components"][0]["modified_sites"] == [2, 20] and lira["components"][0]["modified_sites"] == [20] and not sema["registry_unmodified"] and "gsrs.ncats.nih.gov" in sema["source_url"]
      and not drugs["insulin-detemir"]["sequence"]["registry_unmodified"] and not drugs["insulin-degludec"]["sequence"]["registry_unmodified"])
check("a similar but different peptide is not given another peptide's structure (porcine secretin)", not drugs["secretin-synthetic-porcine"].get("binding"))
rel = {k: d["binding"] for k, d in drugs.items() if (d.get("binding") or {}).get("related")}
check("related-protein animations: same gene, a different protein record than the target, organism named, UniProt link", len(rel) >= 25 and stats["with_related_binding"] == len(rel) and
      all(b["kind"] == "related" and b["related"]["gene"] and b["related"]["organism"] and b["related"]["organism"] != b["organism"] and b["related"]["uniprot_url"].startswith("https://www.uniprot.org/") for b in rel.values()), f"{len(rel)} medicines")
check("celecoxib is shown in mouse COX-2 and says so; TEM beta-lactamase inhibitors get no stand-in from the ambiguous gene name bla",
      rel["celecoxib"]["related"]["organism"] == "Mus musculus" and "sulbactam" not in rel and "tazobactam" not in rel)
check("exenatide's sequence reads N to C (ChEMBL's component string is reversed; its HELM notation is used)", drugs["exenatide"]["sequence"]["components"][0]["sequence"].startswith("HGEGTFTSDL"))
typed = [d for d in drugs.values() if d.get("type_basis")]
check("EMA-only types come only from EMA's ATC code or a WHO INN stem, and say which", len(typed) > 50 and all(re.match(r"EMA ATC code [A-Z]\d|WHO INN stem -|the word '|a strand sequence in FDA's substance registry|ChEMBL molecule type \(CHEMBL\d+\)", d["type_basis"]) for d in typed), f"{len(typed)} typed")
new_types = [d for d in drugs.values() if d["type"] in ("Radiopharmaceutical", "Allergen extract")]
check("v5.18 radiopharmaceutical and allergen types come only from EMA's ATC code (V09, V10, V01)", new_types and all(re.match(r"EMA ATC code V(09|10|01)", d.get("type_basis") or "") for d in new_types), f"{len(new_types)} typed")
check("every type in the catalogue has a how-it-is-made entry and a type code", all(t in made for t in stats["by_type"]))
orig = [d for d in drugs.values() if d.get("origin")]
check("origin stories (v5.18 + v5.24 + v5.26): 60 medicines, each with https sources and a checked date", len(orig) == 60 and all(d["origin"]["sources"] and all(is_url(s["url"]) for s in d["origin"]["sources"]) and d["origin"]["checked"] for d in orig), str(len(orig)))
imet = drugs["imetelstat-sodium"]
check("imetelstat: strand read from FDA's registry name matches ChEMBL (TAGGGTTAGACAA), backbone kept word for word, typed from the registry",
      imet["sequence"]["components"][0]["sequence"] == "TAGGGTTAGACAA" and "3'-amino-3'-deoxy-P-thio" in imet["sequence"]["chemistry"]["as_named"]
      and "gsrs.ncats.nih.gov" in imet["sequence"]["source_url"] and imet["type"] == "Oligonucleotide")
payload = re.compile(r"\b(vedotin|deruxtecan|emtansine|ozogamicin|govitecan|mafodotin|ravtansine|tesirine)\b")
adcs = [d for d in drugs.values() if d.get("type_basis") and payload.search(d["name"].lower()) and re.search(r"\w+mab\b", d["name"].lower())]
check("EMA-only two-word antibody-drug conjugates are typed as conjugates, not plain antibodies", all(d["type"] == "Antibody drug conjugate" for d in adcs), f"{len(adcs)} found")
check("defibrotide is not typed as a peptide from its -tide ending", all(d["type"] != "Protein" for d in drugs.values() if "defibrotide" in d["name"].lower()))
sb = drugs["semaglutide"].get("binding") or {}
check("semaglutide is shown in PDB 4ZGM, found once the name search ignored capital letters, matched by name and sequence",
      sb.get("pdb_id") == "4zgm" and "named after the medicine" in sb.get("match", "") and "modified residues" in sb.get("match", ""))
check("antibody structures whose titles capitalise the name are now found (dostarlimab, secukinumab)", all((drugs[k].get("binding") or {}).get("kind") == "protein" for k in ("dostarlimab", "secukinumab")))
check("liraglutide has no binding animation (no deposited structure of it bound to its target)", not drugs["liraglutide"].get("binding"))
# Canada and Japan
ca = {k: d["ca"] for k, d in drugs.items() if d.get("ca")}
check("Canadian records: every product links its Health Canada page, and every block names the source and the Open Government Licence",
      len(ca) > 1500 and all(e["licence"] == "https://open.canada.ca/en/open-government-licence-canada" and e["data_date"] and
                             all(re.fullmatch(r"https://health-products\.canada\.ca/dpd-bdpp/info\?lang=eng&code=\d+", p[6]) for p in e["products"]) for e in ca.values()), f"{len(ca)} medicines")
sc = drugs["semaglutide"]["ca"]
check("semaglutide in Canada: marketed, first marketed 2018-02-22, Ozempic DIN 02471469", sc["marketed_now"] > 0 and sc["first_marketed"] == "2018-02-22" and any(p[0] == "OZEMPIC" and p[1] == "02471469" for p in sc["products"]))
check("a mineral salt does not collect every product of the same metal (zinc gluconate is not filed under zinc chloride)",
      drugs["zinc-chloride"]["ca"]["products_total"] < 100 and drugs["magnesium-acetate"]["ca"]["products_total"] < 100)
check("year-only Canadian dates (recorded as 31 December) are shown as a year", all((len(e["first_marketed"]) == 4) == e["first_marketed_year_only"] for e in ca.values() if e["first_marketed"]))
jp = {k: d["jp"] for k, d in drugs.items() if d.get("jp")}
check("Japanese records cite PMDA's list (PDF and list page) and say what the list leaves out",
      len(jp) > 800 and all(e["source_url"].startswith("https://www.pmda.go.jp/files/") and e["page"].startswith("https://www.pmda.go.jp/") and "April 2004" in e["scope"] for e in jp.values()))
check("semaglutide in Japan: new active ingredient approved 2018-03-23 (Ozempic)", drugs["semaglutide"]["jp"]["first_new_ingredient"] == "2018-03-23" and "Ozempic" in drugs["semaglutide"]["jp"]["entries"][0][1])
check("imatinib, approved in Japan before 2004, is not given a later change as its first approval", drugs["imatinib"]["jp"]["first_new_ingredient"] is None and drugs["imatinib"]["jp"]["entries_total"] >= 1)
pmda_only = [d for d in drugs.values() if d.get("jp") and not d.get("chembl_id") and not d.get("us") and not d.get("eu")]
check("medicines listed only by PMDA: each is a new active ingredient with PMDA as source (valemetostat among them); no spelling variants or combinations",
      stats["pmda_only"] == len(pmda_only) >= 30 and all(d["jp"]["first_new_ingredient"] and any("pmda.go.jp" in s["url"] for s in d["sources"]) for d in pmda_only)
      and "valemetostat" in drugs and "silodoshin" not in drugs and not any(" " in d["name"] and d["name"].split()[0].lower() in drugs for d in pmda_only), f"{len(pmda_only)} entries")
withref = [d for d in pmda_only if d.get("chembl_ref")]
check("Japan-only medicines found in ChEMBL say ChEMBL does not record the approval, and are not counted as ChEMBL-approved",
      len(withref) >= 30 and all("not this approval" in s["label"] or "does not record" in s["label"] for d in withref for s in d["sources"] if "ChEMBL" in s["label"])
      and all((d.get("structure") or {}).get("note", "").startswith("ChEMBL") for d in withref if d.get("structure")) and not any(d.get("chembl_id") for d in pmda_only), f"{len(withref)} of {len(pmda_only)}")
ema_only = [d for d in drugs.values() if d.get("eu") and not d.get("chembl_id") and not d.get("us")]
ema_ref = [d for d in ema_only if d.get("chembl_ref")]
check("EU-only medicines found in ChEMBL carry ChEMBL's structure with the phase note, never a ChEMBL id of their own",
      len(ema_ref) >= 20 and all(d["chembl_ref"]["url"].startswith("https://www.ebi.ac.uk/chembl/") for d in ema_ref)
      and all(any("ChEMBL" in s["label"] and ("not this approval" in s["label"] or "does not record" in s["label"]) for s in d["sources"]) for d in ema_ref)
      and all(d["structure"]["source"] == "ChEMBL" and d["structure"]["note"].startswith("ChEMBL") for d in ema_ref if d.get("structure")), f"{len(ema_ref)} of {len(ema_only)}")
merged = stats.get("filed_by_chembl_identity", [])
name_count = collections.Counter(d["name"].lower() for d in drugs.values())
by_name = {d["name"].lower(): d for d in drugs.values()}
check("regulator names that are a catalogue medicine under another ChEMBL name are filed under it (each listed, one page each)",
      all(" -> " in m and m.split(" -> ")[1].lower() in by_name and name_count[m.split(" -> ")[0].lower()] <= 1
          and (by_name[m.split(" -> ")[1].lower()].get("eu") or by_name[m.split(" -> ")[1].lower()].get("jp")) for m in merged)
      and not any(m.split(" -> ")[0].lower() in by_name and by_name[m.split(" -> ")[0].lower()] is not by_name[m.split(" -> ")[1].lower()] for m in merged),
      str(merged[:6]))
check("EMA's active-moiety names are filed under the US medicine with the same brand (Cresemba, Vosevi, Filsuvez and Episalvan), and listed",
      drugs["isavuconazonium"]["eu"] and "Cresemba" in [p[0] for p in drugs["isavuconazonium"]["eu"]["products"]] and "isavuconazole" not in drugs
      and {"Filsuvez", "Episalvan"} <= {p[0] for p in drugs["birch-triterpenes"]["eu"]["products"]} and "voxilaprevi" not in drugs
      and any(m.startswith("isavuconazole -> ") for m in stats["filed_by_shared_brand"]), str(stats["filed_by_shared_brand"]))
check("'dantrolene sodium, hemiheptahydrate' (EMA) is filed under dantrolene", "Agilus" in [p[0] for p in drugs["dantrolene"]["eu"]["products"]] and "dantrolene-sodium-hemiheptahydrate" not in drugs)
sa = [(d["id"], o["id"]) for d in drugs.values() for o in d.get("see_also", [])]
check("similar-name links go both ways and point at real pages", sa and all(o in drugs and (o, i) in sa for i, o in sa) and ("mometasone", "mometasone-furoate") in sa, str(sa[:6]))
# v5.24: WHO Essential Medicines List (eEML), origin stories, quiz, how-made text, families, covalent binding sites
eml = {k: d for k, d in drugs.items() if d.get("who_eml")}
check("WHO list: 450+ medicines matched, each entry links to its eEML page, with attribution and the binding PDF lists",
      len(eml) >= 450 and stats["with_who_eml"] == len(eml) and all(r["url"].startswith("https://list.essentialmeds.org/medicines/") for d in eml.values() for r in d["who_eml"]["entries"])
      and all("CC BY 3.0 IGO" in d["who_eml"]["attribution"] and d["who_eml"]["binding_versions"]["EML 2025"].startswith("https://iris.who.int/") for d in eml.values()), str(len(eml)))
check("WHO list: flag bit 1024 set exactly for the medicines with a WHO record", all(bool(r[5] & 1024) == bool(drugs[r[0]].get("who_eml")) for r in index))
check("WHO list: amoxicillin on its own; clavulanic acid only with amoxicillin; no vaccine or blood product matched to one medicine",
      drugs["amoxicillin"]["who_eml"]["listed_alone"] and not drugs["clavulanic-acid"]["who_eml"]["listed_alone"]
      and any("amoxicillin" in w.lower() for r in drugs["clavulanic-acid"]["who_eml"]["entries"] for w in r["with"])
      and not any(re.search(r"vaccine|immunoglobulin|plasma", r["name"], re.I) for d in eml.values() for r in d["who_eml"]["entries"]))
orig = json.loads((pathlib.Path(__file__).resolve().parent.parent / "pipeline" / "origin_stories.json").read_text())
with_origin = [d for d in drugs.values() if d.get("origin")]
check("origin stories: 60 attached, every source https, nothing held back; cisplatin and artesunate (v5.26) now have theirs",
      len(orig["stories"]) == 60 == len(with_origin) and all(x["url"].startswith("https://") for d in with_origin for x in d["origin"]["sources"])
      and not orig.get("held_back") and drugs["cisplatin"].get("origin") and drugs["artesunate"].get("origin"), str(len(with_origin)))
check("v5.26 origin stories carry their own checked date (2026-11-21); the 33 older ones keep 2026-11-20",
      sum(d["origin"]["checked"] == "2026-11-21" for d in with_origin) == 27 and sum(d["origin"]["checked"] == "2026-11-20" for d in with_origin) == 33)
check("v5.26 origin stories: claims their sources did not support stay out (chlorpromazine 1950, Horwitz 1964, Kelsey, 2SD4, top-selling 1968, Michele/Barnett)",
      not any(re.search(r"in 1950 by Paul|Horwitz|Kelsey|2SD4|1968 to 1982|Michele|Barnett|over 90%|ISIS 396443|deadly nightshade", d["origin"]["simple"] + d["origin"]["expert"]) for d in with_origin)
      and "December 11, 1951" in drugs["chlorpromazine"]["origin"]["expert"])
check("v5.26 origin stories: no source is a paper about something else (folic-acid AZT conjugates, drug-repurposing review, siRNA prices)",
      not any(x["url"].rstrip("/").endswith(("PMC2729114", "PMC11019736", "PMC11054365", "PMC6466519", "PMC1369014")) for d in with_origin for x in d["origin"]["sources"]))
check("PubChem cross-check ran (v5.26: a fresh build used to skip it): aspirin and most ChEMBL structures have a PubChem CID",
      drugs["aspirin"]["structure"]["pubchem_cid"] == 2244 and sum(bool((d.get("structure") or {}).get("pubchem_cid")) for d in drugs.values()) > 2000)
check("origin stories: claims the sources did not support stay out (no 'Madagascar periwinkle', '14-membered', '150 analogues', 'Novolin, 1991')",
      not any(re.search(r"Madagascar|14-membered|150 (synthetic )?analogues|1991|woolly|goat's rue", d["origin"]["simple"] + d["origin"]["expert"]) for d in with_origin))
quiz = json.loads((D / "quiz.json").read_text())
check("quiz: 50 questions, no repeats, every answer index valid and every source https",
      len(quiz) == 50 and len({q["q"] for q in quiz}) == 50 and all(0 <= q["right"] < len(q["answers"]) and q["url"].startswith("https://") for q in quiz))
made = json.loads((D / "how_made.json").read_text())["types"]
check("how-made: the sugar-chain class now has sourced text; no class claims more than its sources", "not yet added" not in made["Oligosaccharide"]["simple"]
      and len(made["Oligosaccharide"]["sources"]) == 2 and "not covered by these sources" in made["Oligosaccharide"]["expert"])
fam = json.loads((D / "family_trees.json").read_text())
statins = next(f for f in fam["families"] if any(m["id"] == "atorvastatin" for m in f["members"]))
check("families: 200+ groups of 2 or more, members in year order, earliest first, every member a real page; statins start before atorvastatin",
      fam["count"] >= 200 and all(len(f["members"]) >= 2 and [m["year"] for m in f["members"]] == sorted(m["year"] for m in f["members"]) and f["earliest"] == f["members"][0]["id"]
                                  and all(m["id"] in drugs for m in f["members"]) for f in fam["families"])
      and [m["id"] for m in statins["members"]].index("lovastatin") < [m["id"] for m in statins["members"]].index("atorvastatin"), str(fam["count"]))
cov = {k: d["binding"] for k, d in drugs.items() if (d.get("binding") or {}).get("covalent")}
check("covalent binding sites: sotorasib on KRAS Cys 12, zanubrutinib on BTK Cys 481; every covalent residue is in the drawn site",
      cov.get("sotorasib", {}).get("covalent", {}).get("protein_residue") == "Cys 12" and cov.get("zanubrutinib", {}).get("covalent", {}).get("protein_residue") == "Cys 481"
      and all(b["covalent"]["protein_residue"] in b["residues"] for b in cov.values()), str(len(cov)))
# v5.25: pages for search engines and link previews, sitemap, feed, robots, headers; paid book links on hold
cfg_site = json.loads((SITE / "config" / "site.json").read_text())
base = cfg_site["base_url"].rstrip("/")
pages = {p.parent.name: p for p in (SITE / "medicine").glob("*/index.html")}
sample = [pages[k].read_text() for k in ("aspirin", "sotorasib", "amoxicillin", "insulin-human") if k in pages]
check("one static page per medicine, each with its own canonical address, Open Graph and Twitter tags, JSON-LD and a script that opens the app",
      set(pages) == set(drugs) and len(sample) == 4 and all(f'<link rel="canonical" href="{base}/medicine/' in t and 'property="og:image"' in t and "summary_large_image" in t
                                                            and "application/ld+json" in t and 'src="js/app.js"' in t and '<base href="/">' in t for t in sample), str(len(pages)))
check("static pages never show text the data does not hold (no 'None', 'undefined' or empty source links)",
      not any(re.search(r">None<|undefined|href=\"\"", t) for t in sample))
sm = (SITE / "sitemap.xml").read_text()
check("sitemap lists the start page, A to Z and every medicine page under the configured address", sm.count("<loc>") == len(drugs) + 2 and f"<loc>{base}/medicine/aspirin/</loc>" in sm)
check("robots.txt allows crawling and points at the sitemap", f"Sitemap: {base}/sitemap.xml" in (SITE / "robots.txt").read_text())
feed = (SITE / "feed.xml").read_text()
check("Atom feed of the newest first approvals: 40 entries, newest first, each linking a medicine page",
      feed.count("<entry>") == 40 and all(f"{base}/medicine/" in x for x in re.findall(r'<link href="([^"]+)"/>', feed)[1:])
      and re.findall(r"<updated>(\d{4}-\d\d-\d\d)T", feed)[1:] == sorted(re.findall(r"<updated>(\d{4}-\d\d-\d\d)T", feed)[1:], reverse=True))
check("share picture, icons, manifest, 404 page and Netlify headers are in place", all((SITE / f).exists() for f in ("img/og-card.png", "img/icon-192.png", "img/icon-512.png",
      "img/apple-touch-icon.png", "favicon.svg", "manifest.webmanifest", "404.html", "_headers")) and "noindex" in (SITE / "404.html").read_text())
mon = json.loads((SITE / "config" / "monetization.json").read_text())
check("paid book links are on hold (Dmitry, 2026-11-20): the hold is set and its reason says the site earns nothing from book links",
      "earns nothing" in mon["schemes"]["bookshop"].get("paid_links_hold", ""))
rt = stats["region_timing"]
check("region timing: US compared with the EU, Japan and Canada, each from medicines new to both since 2005, counts add up",
      all(rt[k]["n"] > 100 and rt[k]["us_first"] + rt[k]["other_first"] + rt[k]["same_month"] == rt[k]["n"] and rt[k]["median_months"] is not None for k in ("eu", "jp", "ca")), str({k: rt[k]["n"] for k in rt}))
aliases = json.loads((D / "drug_aliases.json").read_text())
names_by_index = [r[1] for r in json.loads((D / "drug_index.json").read_text())["rows"]]
check("search finds medicines by Japanese and EU brand names (Twymeeg -> imeglimin, Glivec -> imatinib, Kostaive -> zapomeran)",
      names_by_index[aliases["twymeeg"]] == "Imeglimin" and names_by_index[aliases["glivec"]] == "Imatinib" and names_by_index[aliases["kostaive"]] == "Zapomeran")
check("combination products do not lend their brand to one of their ingredients (Diane-35)", "diane-35" not in aliases)
books = money["schemes"]["bookshop"]["items"]
by_role = {r: tuple(b["title"] for b in books if r in b["roles"]) for r in money["schemes"]["bookshop"]["roles"]}
check("every role has its own book list (4 to 6 books, no two lists the same, never students)", all(4 <= len(v) <= 6 for v in by_role.values()) and len(set(by_role.values())) == len(by_role) and "student" not in by_role, str({r: len(v) for r, v in by_role.items()}))
check("every book names its publisher and year and links a record where they can be checked", all(b["publisher"] and b["year"] and b["record"]["url"].startswith("https://") and b["url"].startswith("https://bookshop.org/") for b in books), f"{len(books)} books")
check("schemes needing legal review are on hold", money["schemes"]["licensing"].get("legal_hold") and money["schemes"]["affiliations"].get("legal_hold"))
check("paid book links: released on the owner's instruction, with his affiliate ID, and every ISBN is a 13-digit ISBN",
      money["schemes"]["bookshop"]["affiliate_id"] == "131541" and "Dmitry" in money["schemes"]["bookshop"]["paid_links_released"]
      and all(len(b["isbn"]) == 13 and b["isbn"][:3] in ("978", "979") for b in books if b.get("isbn")) and sum(1 for b in books if b.get("isbn")) == 15)
check("the no-drug-maker-money rule is in the config", money["policy"]["no_drug_maker_money"] is True)
html_files = [SITE / "index.html", *(SITE / "js").glob("*.js"), *(SITE / "css").glob("*.css")]
import re
def loads_from(text):
    """Addresses the page would load (src=, and <link> other than canonical/alternate); a canonical link or <a href> is not a load."""
    text = re.sub(r"<link[^>]+rel=\"(?:canonical|alternate)\"[^>]*>", "", text)
    return re.findall(r"""(?:src|href)=["'](https?://[^"']+)""", re.sub(r"<a\s[^>]*>", "", text))
external = [(f.name, u) for f in html_files + [SITE / "medicine" / "aspirin" / "index.html", SITE / "medicines" / "index.html"] for u in loads_from(f.read_text())]
check("the page shell loads nothing from another site", not external, str(external[:3]))
check("index.html stays small", (SITE / "index.html").stat().st_size < 5000, f"{(SITE / 'index.html').stat().st_size} bytes (v4.0.3 was 773,180)")

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
