// Small HTML helpers shared by every page. All text goes through esc() unless wrapped in raw().

const ENTITIES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ENTITIES[c]);

class Raw {
  constructor(s) { this.s = s; }
  toString() { return this.s; }
}
export const raw = (s) => new Raw(String(s ?? ""));

function render(v) {
  if (v == null || v === false || v === true) return "";
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(render).join("");
  return esc(v);
}

/** Tagged template: html`<p>${text}</p>` escapes every value except raw()/html results and arrays of them. */
export function html(strings, ...values) {
  let out = "";
  strings.forEach((s, i) => { out += s + (i < values.length ? render(values[i]) : ""); });
  return new Raw(out);
}

export const isUrl = (u) => /^https?:\/\//.test(String(u || ""));

/** External link that opens in a new tab; returns plain text if the URL is not http(s). */
export function ext(url, text) {
  return isUrl(url) ? html`<a href="${url}" target="_blank" rel="noopener">${text}<span class="ext" aria-hidden="true"> ↗</span></a>` : html`${text}`;
}

/** Source line used under every fact block. */
export function sourceLine(items, checked) {
  const links = (items || []).filter((s) => isUrl(s.url)).map((s, i) => html`${i ? raw(" · ") : ""}${ext(s.url, s.label || s.type || "Source")}`);
  if (!links.length) return html``;
  return html`<p class="src">Source: ${links}${checked ? html` <span class="checked">Checked ${checked}</span>` : ""}</p>`;
}

export const fmtDate = (iso) => {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return m ? `${Number(d)} ${months[Number(m) - 1]} ${y}` : y;
};

export const num = (n) => Number(n).toLocaleString("en-US");

/** localStorage that never throws (private mode, blocked storage). */
export const store = {
  get(k) { try { return localStorage.getItem("pbp." + k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem("pbp." + k, v); } catch (e) { /* storage unavailable: fine */ } },
};
