// Interactive explorers shown above three data sets (ported from the v4 labs by Gemini, re-sourced in v5.4).
//   pgx            what FDA labels say for carriers of certain gene variants      (In-depth only)
//   interactions   what FDA labels say about four food and drug interactions      (In-depth only)
//   excipients     illustrative release-profile curves for an imaginary drug       (both environments)
// All text lives in data/simulators.json with its label link; nothing is typed here. These describe labels; they are not advice.
import { html, raw, ext, sourceLine } from "./ui.js";
import { getJSON } from "./data.js";

const WHERE = { pgx: ["ref"], interactions: ["ref"], excipients: ["ref", "explore"] };
const TITLES = { pgx: "Gene variants: what the label says", interactions: "Interactions: what the label says", excipients: "How the formulation shapes the curve" };

/** Placeholder for a topic's explorer, or "" when the topic has none in this environment. */
export function renderTopicSimulator(key, env = "ref") {
  if (!WHERE[key] || !WHERE[key].includes(env)) return "";
  return html`<section class="x-panel sim-box" data-sim="${key}"><h2>${TITLES[key]}</h2><div class="sim-body"><p class="muted">Loading…</p></div></section>`;
}

export async function mountTopicSimulator(root, key) {
  const box = root.querySelector(`[data-sim="${key}"] .sim-body`);
  if (!box) return;
  const data = await getJSON("data/simulators.json");
  const chips = (items, attr) => html`<div class="chips-row">${items.map((c, i) => html`<button type="button" class="chip${i === 0 ? " on" : ""}" data-${attr}="${c.key}">${c.label || c.name}</button>`)}</div>`;
  const wire = (attr, show) => {
    box.querySelectorAll(`[data-${attr}]`).forEach((b) => b.addEventListener("click", () => {
      box.querySelectorAll(`[data-${attr}]`).forEach((x) => x.classList.toggle("on", x === b));
      show(b.dataset[attr]);
    }));
  };
  const disclaimer = html`<p class="sim-note">This reports what a US label says. It is not advice: prescribing decisions belong with a clinician and the current label.</p>`;

  if (key === "pgx") {
    box.innerHTML = html`${chips(data.gene_variants, "case")}<div class="sim-out"></div>${disclaimer}`;
    const show = (k) => {
      const c = data.gene_variants.find((x) => x.key === k);
      box.querySelector(".sim-out").innerHTML = html`<div class="sim-cards">${c.statuses.map((s) => html`<div><b>${s.who}</b><p>${s.says}</p></div>`)}</div>
        <p><a href="#/ref/drug/${c.drug}">Open ${c.drug} in the catalogue →</a></p>${sourceLine([{ label: c.source, url: c.url }], data.checked)}`;
    };
    wire("case", show); show(data.gene_variants[0].key);
  }

  if (key === "interactions") {
    box.innerHTML = html`${chips(data.interactions, "case")}<div class="sim-out"></div>${disclaimer}`;
    const show = (k) => {
      const c = data.interactions.find((x) => x.key === k);
      box.querySelector(".sim-out").innerHTML = html`<div class="sim-cards"><div><b>Exposure to ${c.drug}</b><p>${c.direction === "up" ? "Goes up ↑" : "Goes down ↓"}${c.figure ? html`<br><b>${c.figure}</b>` : html`<br><span class="muted">The label gives no single figure.</span>`}</p></div>
        <div><b>What the label says</b><p>${c.says}</p></div></div>
        <p><a href="#/ref/drug/${c.drug}">Open ${c.drug} in the catalogue →</a></p>${sourceLine([{ label: c.source, url: c.url }], data.checked)}`;
    };
    wire("case", show); show(data.interactions[0].key);
  }

  if (key === "excipients") {
    const R = data.release_profiles;
    box.innerHTML = html`${chips(R.profiles, "profile")}<div class="sim-out"></div><p class="sim-note">${R.note}</p>`;
    const show = (k) => {
      const p = R.profiles.find((x) => x.key === k);
      const points = [];
      let peak = 0;
      for (let step = 0; step <= 96; step++) {
        const t = (step / 96) * 24, dt = Math.max(0, t - p.lag);
        const c = dt <= 0 ? 0 : (p.ka / (p.ka - p.ke)) * (Math.exp(-p.ke * dt) - Math.exp(-p.ka * dt));
        peak = Math.max(peak, c); points.push([t, c]);
      }
      const line = points.map(([t, c]) => `${Math.round(45 + (t / 24) * 480)},${Math.round(170 - (c / (peak || 1)) * 130 * p.height)}`).join(" ");
      box.querySelector(".sim-out").innerHTML = html`<svg class="sim-curve" viewBox="0 0 550 200" role="img" aria-label="Illustrative concentration over 24 hours: ${p.name}">
          <rect x="45" y="55" width="480" height="65" fill="#d3f9d8" opacity="0.45"/>
          <line x1="45" y1="55" x2="525" y2="55" stroke="#fa5252" stroke-dasharray="4,4"/><text x="52" y="50" font-size="11" fill="#c92a2a">too much</text>
          <line x1="45" y1="120" x2="525" y2="120" stroke="#2b8a3e" stroke-dasharray="4,4"/><text x="52" y="134" font-size="11" fill="#2b8a3e">too little</text>
          <line x1="45" y1="170" x2="525" y2="170" stroke="#495057"/><line x1="45" y1="20" x2="45" y2="170" stroke="#495057"/>
          <polyline fill="none" stroke="#1c7ed6" stroke-width="3.5" points="${raw(line)}"/>
          <text x="285" y="192" text-anchor="middle" font-size="12" fill="#495057">hours after the dose (0 to 24)</text></svg><p><b>${p.name}.</b> ${p.says}</p>`;
    };
    wire("profile", show); show(R.profiles[0].key);
  }
}
