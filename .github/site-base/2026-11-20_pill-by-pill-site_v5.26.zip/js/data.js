// Data access. Every file is fetched once and cached. Nothing leaves the site's own origin.

const cache = new Map();

export function getJSON(path) {
  if (!cache.has(path)) {
    cache.set(path, fetch(path).then((r) => {
      if (!r.ok) throw new Error(`${path}: ${r.status}`);
      return r.json();
    }).catch((e) => { cache.delete(path); throw e; }));
  }
  return cache.get(path);
}

export const TYPE_NAMES = { sm: "Small molecule", pr: "Protein", ab: "Antibody", adc: "Antibody drug conjugate", en: "Enzyme",
  ol: "Oligonucleotide", os: "Oligosaccharide", ge: "Gene", ce: "Cell", va: "Vaccine component", rp: "Radiopharmaceutical", al: "Allergen extract", un: "Unknown" };
export const FLAG = { structure: 1, sequence: 2, us: 4, ema: 8, withdrawn: 16, boxed: 32, story: 64, binding: 128, ca: 256, jp: 512, eml: 1024 };

let indexPromise;
/** The whole catalogue as light objects: {id, name, type, year, atc, flags, brand}. */
export function drugIndex() {
  indexPromise ??= getJSON("data/drug_index.json").then((d) =>
    d.rows.map(([id, name, type, year, atc, flags, brand]) => ({ id, name, type, year, atc, flags, brand, lower: name.toLowerCase() })));
  return indexPromise;
}

export const drug = (id) => getJSON(`data/drugs/${encodeURIComponent(id)}.json`);
export const molecule = (id) => getJSON(`mol/${encodeURIComponent(id)}.json`);
export const bindingSite = (id) => getJSON(`bind/${encodeURIComponent(id)}.json`);
export const stats = () => getJSON("data/catalogue_stats.json");
export const topics = () => getJSON("data/topics.json");
export const topicRows = (key) => getJSON(`data/topics/${encodeURIComponent(key)}.json`);
export const howMade = () => getJSON("data/how_made.json");
export const quiz = () => getJSON("data/quiz.json");
export const families = () => getJSON("data/family_trees.json");
let familyIndex = null;
/** The family (same ChEMBL stem and first target) a medicine belongs to, or undefined. */
export async function familyOf(id) {
  if (!familyIndex) {
    familyIndex = new Map();
    try { for (const f of (await families()).families) for (const m of f.members) familyIndex.set(m.id, f); } catch (e) { /* no family file: no family facts */ }
  }
  return familyIndex.get(id);
}

/** Name search: names that start with the text first, then names containing it, then brand and other names. */
export async function searchDrugs(text, limit = 20) {
  const q = text.trim().toLowerCase();
  if (q.length < 2) return [];
  const index = await drugIndex();
  const starts = [], contains = [], brands = [];
  for (const d of index) {
    if (d.lower.startsWith(q)) starts.push(d);
    else if (d.lower.includes(q)) contains.push(d);
    else if (d.brand && d.brand.toLowerCase().startsWith(q)) brands.push(d);
  }
  let found = [...starts, ...contains, ...brands];
  if (found.length < limit && q.length >= 3) {
    const aliases = await getJSON("data/drug_aliases.json");
    const seen = new Set(found.map((d) => d.id));
    for (const [alias, i] of Object.entries(aliases)) {
      if (alias.startsWith(q) && !seen.has(index[i].id)) {
        seen.add(index[i].id);
        found.push({ ...index[i], via: alias });
        if (found.length >= limit) break;
      }
    }
  }
  return found.slice(0, limit);
}

/** Find a catalogue entry by a name from a curated data set (exact name, then alias). */
export async function findDrugByName(name) {
  const q = String(name || "").trim().toLowerCase();
  if (!q) return null;
  const index = await drugIndex();
  const hit = index.find((d) => d.lower === q);
  if (hit) return hit;
  const aliases = await getJSON("data/drug_aliases.json");
  return q in aliases ? index[aliases[q]] : null;
}
