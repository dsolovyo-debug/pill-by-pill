// Monetization. Everything is driven by config/monetization.json: one on/off switch per scheme, plain outbound links, no scripts.
// Rules enforced here (and checked in tests/):
//   1. Student pages never show any scheme.
//   2. A scheme shows only when it is on and its link exists, unless preview mode is on.
//   3. Affiliate links carry a visible "Paid link" label and rel="sponsored".
//   5. Books are chosen per role (each item lists its roles) and each needs a "record" link where its details can be checked.
//   4. A scheme with "legal_hold" never shows, even in preview; "paid_links_hold" keeps book links unpaid.
import { html, isUrl } from "./ui.js";
import { getJSON } from "./data.js";

export const PAYING_ROLES = ["teacher", "history", "clinician", "chemist", "industry"];
let previewOverride = false;
export const setPreview = (on) => { previewOverride = on; };
export const config = () => getJSON("config/monetization.json");

function card(key, s, preview, role) {
  const pending = html`<p class="money-pending">Not connected yet: add the link in config/monetization.json.</p>`;
  if (s.kind === "affiliate") {
    const items = (s.items || []).filter((b) => isUrl(b.url) && b.record && isUrl(b.record.url) && (b.roles || []).includes(role));
    if (!items.length) return "";
    const connected = s.affiliate_connected && s.affiliate_id && !s.paid_links_hold;
    const paidFor = (b) => connected && /^97[89]\d{10}$/.test(b.isbn || "");
    const paid = connected && (s.items || []).some(paidFor);
    const book = (b) => html`<li><b>${b.title}</b> <span class="muted">by ${b.by} (${b.publisher}, ${b.year})</span><br>${b.about}<br>
      <a class="buy" href="${paidFor(b) ? `https://bookshop.org/a/${s.affiliate_id}/${b.isbn}` : b.url}" target="_blank" rel="noopener${paidFor(b) ? " sponsored" : ""}">${paidFor(b) ? "Buy at Bookshop.org" : "Search Bookshop.org"}${paidFor(b) ? html` <span class="paid">Paid link</span>` : ""} ↗</a>
      · <a href="${b.record.url}" target="_blank" rel="noopener">Book details: ${b.record.label} ↗</a></li>`;
    return html`<section class="money" data-scheme="${key}" aria-label="${s.title}">
      <h3>${s.title} ${paid ? html`<span class="paid">Paid links</span>` : ""}</h3>
      <p class="money-text">${s.text}${paid ? " If you buy through a link marked Paid link, this site earns a commission from Bookshop.org. It does not change the price." : " These are ordinary links: this site earns nothing from them yet."}</p>
      ${(s.role_text || {})[role] ? html`<p class="money-text"><b>${s.role_text[role]}</b></p>` : ""}
      <ul class="books">${items.slice(0, 3).map(book)}</ul>
      ${items.length > 3 ? html`<details><summary>${items.length - 3} more</summary><ul class="books">${items.slice(3).map(book)}</ul></details>` : ""}
      ${s.checked ? html`<p class="src">Titles, authors, publishers and years checked against the linked records on ${s.checked}.</p>` : ""}</section>`;
  }
  if (s.kind === "affiliation") {
    const items = (s.items || []).filter((p) => isUrl(p.url));
    if (!items.length && !preview) return "";
    return html`<section class="money" data-scheme="${key}" aria-label="${s.title}"><h3>${s.title}</h3><p class="money-text">${s.text}</p>
      ${items.length ? html`<ul>${items.map((p) => html`<li><a href="${p.url}" target="_blank" rel="noopener sponsored">${p.name} ↗</a> <span class="paid">Partner</span></li>`)}</ul>` : pending}</section>`;
  }
  if (!isUrl(s.url) && !preview) return "";
  return html`<section class="money" data-scheme="${key}" aria-label="${s.title}"><h3>${s.title}</h3><p class="money-text">${s.text}</p>
    ${isUrl(s.url) ? html`<a class="btn" href="${s.url}" target="_blank" rel="noopener">${s.button} ↗</a>` : pending}</section>`;
}

/** Cards for one role. Returns an empty string for students and for unknown roles. */
export async function moneyFor(role, only) {
  if (!PAYING_ROLES.includes(role)) return html``;
  const cfg = await config();
  const preview = cfg.preview || previewOverride;
  const cards = Object.entries(cfg.schemes)
    .filter(([key, s]) => s.on && !s.legal_hold && s.roles.includes(role) && (!only || only.includes(key)))
    .map(([key, s]) => card(key, s, preview, role)).filter(String);
  if (!cards.length) return html``;
  return html`<aside class="money-wrap" aria-label="Ways to support this site"><p class="money-head">Support and extras <a href="#/fund">How this site is funded</a></p>${cards}</aside>`;
}

/** Schemes parked until a legal question is settled, for the funding page. */
export async function heldSchemes() {
  const cfg = await config();
  return Object.values(cfg.schemes).flatMap((s) => [s.legal_hold && [s.title, s.legal_hold], s.paid_links_hold && [`${s.title}: paid links`, s.paid_links_hold]].filter(Boolean));
}
