// The In-depth environment ("Reference"): dense, filterable, cited pages for clinicians, chemists, researchers and industry.
// Every function returns { html, mount? }.
import { html, raw, ext, sourceLine, num, fmtDate, isUrl } from "./ui.js";
import * as data from "./data.js";
import { page, ROLES } from "./layout.js";
import { draw2D, mount3D, sequenceView } from "./molecule.js";
import { worldRows, usSummary, howTaken, worldTimeline } from "./drugfacts.js";
import { moneyFor } from "./money.js";
import { mountBinding, schematic } from "./binding.js";
import { renderTopicSimulator, mountTopicSimulator } from "./simulators.js";
import { wireSearch } from "./search.js";
import { sharePanel, mountShare, medicineUrl } from "./share.js";

const HOME = ["Reference", "#/ref"];
const GROUPS = { clinical: "Clinical", safety: "Safety", modalities: "Modalities", chemistry: "Chemistry and naming", world: "Regulation worldwide",
  market: "Market", stories: "History", people: "People" };
const ATC = { A: "Alimentary and metabolism", B: "Blood", C: "Cardiovascular", D: "Dermatological", G: "Genito-urinary and sex hormones", H: "Systemic hormones",
  J: "Anti-infectives", L: "Antineoplastic and immunomodulating", M: "Musculo-skeletal", N: "Nervous system", P: "Antiparasitic", R: "Respiratory", S: "Sensory organs", V: "Various" };

function table(headers, rows, cls = "") {
  return html`<div class="tbl-wrap" tabindex="0" role="region" aria-label="Table, scrolls sideways"><table class="tbl ${cls}"><thead><tr>${headers.map((h) => html`<th scope="col">${h}</th>`)}</tr></thead>
    <tbody>${rows.map((r) => html`<tr>${r.map((c) => html`<td>${c}</td>`)}</tr>`)}</tbody></table></div>`;
}
const refLinks = (refs) => (refs || []).map((r, i) => html`${i ? " · " : ""}${ext(r.url, r.type || "ref")}`);
const bars = (entries, hrefFor) => { const max = Math.max(...entries.map(([, n]) => n));
  return html`<ul class="bars">${entries.map(([k, n]) => html`<li><a href="${hrefFor(k)}"><span>${k}</span><i style="width:${Math.max(2, Math.round(100 * n / max))}%"></i><b>${num(n)}</b></a></li>`)}</ul>`; };
const topicLinks = (list, groups) => html`<ul class="link-list">${list.filter((t) => groups.includes(t.group)).map((t) =>
  html`<li><a href="#/ref/topic/${t.key}">${t.title}</a> <span class="muted">${t.count} rows · ${t.intro}</span></li>`)}</ul>`;

// ------------------------------------------------------------------------------------------------ overview and role landings
export async function overview() {
  const st = await data.stats();
  const body = html`
    <div class="r-cards">${["clinician", "chemist", "industry"].map((r) => html`<a class="r-card" href="${ROLES[r].path}"><b>${ROLES[r].icon} ${ROLES[r].name}</b><span>${ROLES[r].line}</span></a>`)}</div>
    <h2>Coverage</h2>
    ${table(["Measure", "Count", "Source"], [
      ["Medicines (one per active ingredient, salts merged)", num(st.total), "ChEMBL approved drugs + FDA Drugs@FDA"],
      ["With a US application in Drugs@FDA", num(st.with_us_record), html`${num(st.fda_applications)} applications, file dated ${st.drugsfda_data_date}`],
      ["Approved somewhere but with no US application found", num(st.chembl_only), st.chembl_release.replace("_", " ")],
      ["With a record in EMA's table of centrally evaluated medicines", html`${num(st.with_eu_record)} (${num(st.eu_authorised_now)} authorised now)`, "EMA medicines data table"],
      ["With both a US and an EU record", num(st.us_and_eu), "Drugs@FDA and EMA"],
      ["Listed only by EMA (no ChEMBL or Drugs@FDA match)", num(st.ema_only), "EMA medicines data table"],
      ["With products in Health Canada's Drug Product Database", html`${num(st.with_ca_record)} (${num(st.ca_marketed_now)} marketed now)`, html`${num(st.ca_products)} human products, downloaded ${st.ca_data_date}`],
      ["In PMDA's list of new-drug approvals in Japan since 2004", html`${num(st.with_jp_record)} (${num(st.jp_new_ingredient)} first approved there as a new active ingredient)`, st.jp_title],
      ["Listed only by PMDA (new active ingredients no other source lists)", num(st.pmda_only), st.jp_title],
      ["On the WHO Model List of Essential Medicines", html`<a href="#/ref/drugs?has=eml">${num(st.with_who_eml || 0)}</a> (${num(st.who_eml_alone || 0)} on their own, the rest only in combinations)`, "WHO eEML"],
      ["EU names filed under a medicine listed under another name: same ChEMBL molecule, or EMA's product is that medicine's US brand",
        html`${num((st.filed_by_chembl_identity || []).length + (st.filed_by_shared_brand || []).length)}<br><small>${[...(st.filed_by_chembl_identity || []), ...(st.filed_by_shared_brand || [])].join("; ")}</small>`,
        "ChEMBL names and synonyms; Drugs@FDA brands"],
      ["With a record in all four: US, EU, Canada and Japan", html`<a href="#/ref/drugs?has=all4">${num(st.us_eu_ca_jp)}</a>`, "Drugs@FDA, EMA, Health Canada, PMDA"],
      ["With a chemical structure", num(st.with_structure), "ChEMBL; PubChem for FDA-only names"],
      ["With a 2D drawing / computed 3D model", `${num(st.graphics.drawing)} / ${num(st.graphics.model3d)}`, "Laid out with RDKit"],
      ["With an animated binding site from an experimental structure", num(st.with_binding_site), "Protein Data Bank, found through PDBe"],
      ["of which shown in the same protein of another species, and labelled so", num(st.with_related_binding), "Protein Data Bank; gene names from ChEMBL and PDBe"],
      ["With a mechanism schematic", num(st.with_mechanism), "ChEMBL mechanisms"],
      ["With manufacturing notes in PubChem", num(st.with_manufacturing_notes), "PubChem (mostly HSDB)"],
      ["With an amino-acid or nucleotide sequence", num(st.with_sequence), "ChEMBL"],
      ["Flagged withdrawn in at least one country", num(st.withdrawn), "ChEMBL"]])}
    <p class="muted">Data pulled ${st.fetched_on}. What is not covered is listed under <a href="#/ref/data">Sources and method</a>.</p>`;
  return { html: page({ level: "landing", kicker: "In-depth", title: "Drug reference", lede: "Approved drugs worldwide with structures, mechanisms, uses, warnings and every US application, each linked to its source record.",
    keyFacts: [["Medicines", num(st.total)], ["US applications", num(st.fda_applications)], ["Structures", num(st.with_structure)], ["Data pulled", st.fetched_on]],
    body, more: [{ title: "Drug catalogue", text: "Filter by type, class, decade and flags.", href: "#/ref/drugs" }, { title: "Data sets", text: "33 curated, sourced tables.", href: "#/ref/topics" }] }) };
}

export async function landing(role) {
  const [st, index, topics] = await Promise.all([data.stats(), data.drugIndex(), data.topics()]);
  const R = ROLES[role], trail = [HOME, [R.name]];
  const count = (flag) => index.filter((d) => d.flags & flag).length;
  let keyFacts, body, more;
  if (role === "clinician") {
    const newest = [...index].filter((d) => d.year).sort((a, b) => b.year - a.year || a.name.localeCompare(b.name)).slice(0, 10);
    keyFacts = [["Boxed warnings", html`<a href="#/ref/drugs?flag=boxed">${num(count(data.FLAG.boxed))}</a>`], ["Withdrawn somewhere", html`<a href="#/ref/drugs?flag=withdrawn">${num(count(data.FLAG.withdrawn))}</a>`], ["Medicines", num(st.total)]];
    body = html`<h2>Most recent first approvals</h2>${table(["Drug", "Brand", "First approved"], newest.map((d) => [html`<a href="#/ref/drug/${d.id}">${d.name}</a>`, d.brand, d.year]))}
      <h2>Clinical data sets</h2>${topicLinks(topics, ["clinical", "safety"])}`;
    more = [{ title: "Boxed-warning drugs", text: "All drugs ChEMBL flags with a US boxed warning.", href: "#/ref/drugs?flag=boxed" },
      { title: "Withdrawn drugs", text: "With country, year and reason where recorded.", href: "#/ref/drugs?flag=withdrawn" },
      { title: "Interactive labs (classic)", text: "CYP interactions, paediatric dosing and PGx simulators from v4.", href: "legacy/index.html#how", external: true }];
  } else if (role === "chemist") {
    const codes = Object.fromEntries(Object.entries(data.TYPE_NAMES).map(([c, n]) => [n, c]));
    keyFacts = [["Structures", num(st.with_structure)], ["2D drawings", num(st.graphics.drawing)], ["3D models", num(st.graphics.model3d)], ["Binding-site animations", html`<a href="#/ref/drugs?has=binding">${num(st.with_binding_site)}</a>`], ["Sequences", num(st.with_sequence)]];
    body = html`<h2>Modalities</h2>${bars(Object.entries(st.by_type).sort((a, b) => b[1] - a[1]), (k) => `#/ref/drugs?type=${codes[k]}`)}
      <h2>Chemistry and modality data sets</h2>${topicLinks(topics, ["modalities", "chemistry"])}
      <p class="muted">Structures come from ChEMBL and are cross-checked against PubChem by InChIKey. 3D models are computed (RDKit ETKDGv3 + MMFF94), not experimental.</p>`;
    more = [{ title: "Small molecules", text: "With drawings, properties and identifiers.", href: "#/ref/drugs?type=sm&has=structure" },
      { title: "Peptides and proteins", text: "With sequences.", href: "#/ref/drugs?type=pr" }, { title: "Oligonucleotides", text: "Strand sequences as recorded.", href: "#/ref/drugs?type=ol" },
      { title: "Mechanism-of-action engine (classic)", text: "Eight drugs from whole body to binding pocket.", href: "legacy/index.html#how", external: true }];
  } else {
    keyFacts = [["US applications", num(st.fda_applications)], ["With EU record", html`<a href="#/ref/drugs?has=ema">${num(st.with_eu_record)}</a>`], ["US and EU", html`<a href="#/ref/drugs?has=both">${num(st.us_and_eu)}</a>`],
      ["EU record, no US application", html`<a href="#/ref/drugs?has=euonly">${num(st.with_eu_record - st.us_and_eu)}</a>`],
      ["Canada record", html`<a href="#/ref/drugs?has=ca">${num(st.with_ca_record)}</a>`], ["Japan record", html`<a href="#/ref/drugs?has=jp">${num(st.with_jp_record)}</a>`]];
    body = html`<h2>First approvals by decade</h2>${bars(Object.entries(st.by_decade).map(([k, n]) => [k + "s", n]), (k) => `#/ref/drugs?decade=${k.slice(0, 4)}`)}
      <h2>By therapeutic area (ATC level 1)</h2>${bars(Object.entries(st.by_atc).sort((a, b) => b[1] - a[1]).map(([k, n]) => [`${k} ${ATC[k] || ""}`, n]), (k) => `#/ref/drugs?atc=${k[0]}`)}
      <h2>Who gets new medicines first</h2>${st.region_timing ? html`${table(["Compared with the US", "Medicines", "US first", "Other first", "Within a month", "Median gap"],
        [["European Union (EMA, central)", "eu"], ["Japan (PMDA, new active ingredient)", "jp"], ["Canada (first marketed)", "ca"]].map(([label, k]) => {
          const r = st.region_timing[k];
          return [label, num(r.n), num(r.us_first), num(r.other_first), num(r.same_month), r.median_months == null ? "" : `${r.median_months > 0 ? "+" : ""}${r.median_months} months`];
        }))}
        <p class="muted">Medicines with a date in both records, counting only those new to both since 2005, when all four records are complete. A positive gap means the other region came later than the US.
          The dates measure different things (the earliest approval in FDA's records; EU central authorisation; Japan's first approval of the ingredient; Canada's first sale), and medicines licensed nationally in Europe are not in EMA's table.
          Computed from Drugs@FDA, EMA, PMDA and Health Canada data on this site.</p>` : ""}
      <h2>Regulatory and market data sets</h2>${topicLinks(topics, ["world", "market", "modalities"])}`;
    more = [{ title: "Approved elsewhere, not in Drugs@FDA", text: "Drugs with no US application found.", href: "#/ref/drugs?has=nous" },
      { title: "When agencies disagreed", text: "14 cross-agency case studies.", href: "#/ref/topic/divergences" }, { title: "Late-stage pipeline", text: "Peptide and oligonucleotide candidates.", href: "#/ref/topic/pipeline" }];
  }
  return { html: page({ level: "landing", trail, kicker: `${R.icon} ${R.name}`, title: { clinician: "Clinical reference", chemist: "Chemistry and structures", industry: "Approvals, regulation and markets" }[role],
    lede: R.line, keyFacts, body, more, money: await moneyFor(role) }) };
}

// ------------------------------------------------------------------------------------------------ catalogue
export async function drugs(query) {
  const index = await data.drugIndex();
  const f = { q: query.get("q") || "", type: query.get("type") || "", atc: query.get("atc") || "", decade: query.get("decade") || "", flag: query.get("flag") || "", has: query.get("has") || "", sort: query.get("sort") || "name" };
  const q = f.q.toLowerCase();
  let list = index.filter((d) => (!q || d.lower.includes(q) || (d.brand || "").toLowerCase().includes(q)) && (!f.type || d.type === f.type) && (!f.atc || d.atc.includes(f.atc)) &&
    (!f.decade || (d.year && Math.floor(d.year / 10) * 10 === Number(f.decade))) && (!f.flag || d.flags & data.FLAG[f.flag]) &&
    (!f.has || (f.has === "nous" ? !(d.flags & data.FLAG.us) : f.has === "both" ? (d.flags & data.FLAG.us) && (d.flags & data.FLAG.ema)
      : f.has === "all4" ? (d.flags & data.FLAG.us) && (d.flags & data.FLAG.ema) && (d.flags & data.FLAG.ca) && (d.flags & data.FLAG.jp)
      : f.has === "euonly" ? (d.flags & data.FLAG.ema) && !(d.flags & data.FLAG.us) : d.flags & data.FLAG[f.has])));
  if (f.sort === "newest") list = [...list].sort((a, b) => (b.year || 0) - (a.year || 0));
  if (f.sort === "oldest") list = [...list].sort((a, b) => (a.year || 9999) - (b.year || 9999));
  const opt = (v, label, cur) => html`<option value="${v}"${v === cur ? raw(" selected") : ""}>${label}</option>`;
  const decades = [...new Set(index.filter((d) => d.year).map((d) => Math.floor(d.year / 10) * 10))].sort();
  const row = (d) => html`<tr><td><a href="#/ref/drug/${d.id}">${d.name}</a></td><td>${d.brand}</td><td>${data.TYPE_NAMES[d.type]}</td><td class="n">${d.year || ""}</td><td class="mono">${d.atc}</td>
    <td>${[d.flags & data.FLAG.us && "US", d.flags & data.FLAG.ema && "EU", d.flags & data.FLAG.ca && "CA", d.flags & data.FLAG.jp && "JP", d.flags & data.FLAG.eml && "WHO"].filter(Boolean).join(" ")}</td><td>${d.flags & data.FLAG.structure ? "2D" : d.flags & data.FLAG.sequence ? "seq" : ""}</td>
    <td>${d.flags & data.FLAG.boxed ? html`<span class="tag warn">boxed</span>` : ""}${d.flags & data.FLAG.withdrawn ? html`<span class="tag bad">withdrawn</span>` : ""}</td></tr>`;
  const body = html`
    <form id="filters" class="filters">
      <label>Name or brand <input name="q" type="search" value="${f.q}"></label>
      <label>Type <select name="type">${opt("", "Any", f.type)}${Object.entries(data.TYPE_NAMES).map(([c, n]) => opt(c, n, f.type))}</select></label>
      <label>ATC group <select name="atc">${opt("", "Any", f.atc)}${Object.entries(ATC).map(([c, n]) => opt(c, `${c} ${n}`, f.atc))}</select></label>
      <label>First approved <select name="decade">${opt("", "Any decade", f.decade)}${decades.map((d) => opt(String(d), d + "s", f.decade))}</select></label>
      <label>Flag <select name="flag">${opt("", "Any", f.flag)}${opt("boxed", "Boxed warning", f.flag)}${opt("withdrawn", "Withdrawn somewhere", f.flag)}${opt("story", "Has a discovery story", f.flag)}</select></label>
      <label>Has <select name="has">${opt("", "Anything", f.has)}${opt("structure", "Structure", f.has)}${opt("sequence", "Sequence", f.has)}${opt("us", "US application", f.has)}${opt("ema", "EU (EMA) record", f.has)}${opt("both", "US and EU records", f.has)}${opt("ca", "Canada (Health Canada) record", f.has)}${opt("jp", "Japan (PMDA) record", f.has)}${opt("all4", "US, EU, Canada and Japan", f.has)}${opt("euonly", "EU record, no US application", f.has)}${opt("eml", "On the WHO Essential Medicines List", f.has)}${opt("binding", "Binding-site animation", f.has)}${opt("nous", "No US application", f.has)}</select></label>
      <label>Sort <select name="sort">${opt("name", "Name", f.sort)}${opt("newest", "Newest first", f.sort)}${opt("oldest", "Oldest first", f.sort)}</select></label>
      <a href="#/ref/drugs">Clear</a></form>
    <p id="count"><b>${num(list.length)}</b> of ${num(index.length)} drugs</p>
    <div class="tbl-wrap" tabindex="0" role="region" aria-label="Drug catalogue table"><table class="tbl" id="drug-table"><thead><tr><th>Drug</th><th>Brand</th><th>Type</th><th>First approved</th><th>ATC</th><th>Records</th><th>Graphic</th><th>Flags</th></tr></thead>
      <tbody>${list.slice(0, 100).map(row)}</tbody></table></div>
    ${list.length > 100 ? html`<p><button class="btn" id="more" type="button">Show 100 more</button></p>` : ""}
    <p class="src">“First approved” is the earliest year in ChEMBL, Drugs@FDA, EMA's table or PMDA's list (new active ingredient). “Records”: US = application in Drugs@FDA, EU = in EMA's table of centrally evaluated medicines (or an EMA report linked from ChEMBL), CA = in Health Canada's Drug Product Database, JP = in PMDA's list of approved drugs since April 2004, WHO = on the WHO Model List of Essential Medicines (as shown in WHO's eEML).</p>`;
  return {
    html: page({ trail: [HOME, ["Drug catalogue"]], title: "Drug catalogue", lede: "One row per active ingredient. Salts are merged into the parent drug.", body }),
    mount(root) {
      const form = root.querySelector("#filters");
      const apply = () => { const p = new URLSearchParams(new FormData(form)); [...p.keys()].forEach((k) => { if (!p.get(k) || (k === "sort" && p.get(k) === "name")) p.delete(k); });
        location.hash = "#/ref/drugs" + (p.toString() ? "?" + p : ""); };
      form.addEventListener("change", apply);
      form.addEventListener("submit", (e) => { e.preventDefault(); apply(); });
      let shown = 100;
      root.querySelector("#more")?.addEventListener("click", (e) => {
        root.querySelector("#drug-table tbody").insertAdjacentHTML("beforeend", list.slice(shown, shown + 100).map(row).join("")); shown += 100;
        if (shown >= list.length) e.target.remove();
      });
    },
  };
}

// ------------------------------------------------------------------------------------------------ one drug
const SHORTAGES_URL = "https://www.accessdata.fda.gov/scripts/drugshortages/default.cfm";     // checked 2026-11-20; idea from Gemini's v5.24 patch
const SUBS = { structure: "Structure and properties", binding: "Target binding", approvals: "US applications", uses: "Uses and safety", names: "Names and worldwide records" };

export async function drugPage(id, sub) {
  const d = await data.drug(id);
  const base = `#/ref/drug/${d.id}`, trail = [HOME, ["Drug catalogue", "#/ref/drugs"], [d.name, base]];
  const badges = html`${d.flags.boxed_warning ? html`<span class="tag warn">Boxed warning</span>` : ""}${d.flags.withdrawn ? html`<span class="tag bad">Withdrawn somewhere</span>` : ""}
    ${d.flags.first_in_class ? html`<span class="tag">First in class</span>` : ""}${d.flags.prodrug ? html`<span class="tag">Prodrug</span>` : ""}${d.flags.orphan ? html`<span class="tag">Orphan</span>` : ""}`;
  const s = d.structure;
  const hasGraphic = d.graphics && d.graphics.drawing;
  const mol = hasGraphic ? await data.molecule(d.id) : null;
  const fam = (await data.familyOf(d.id)) || null;
  const shareUrl = await medicineUrl(d.id);

  if (sub === "structure") {
    const p = d.properties || {};
    const body = html`
      ${mol ? html`<div class="struct-grid"><figure class="mol-fig"><div class="mol-box">${draw2D(mol.d2, { maxWidth: 640, maxHeight: 460, title: d.name })}</div><figcaption>2D layout by RDKit from the ${s.source} SMILES.</figcaption></figure>
        ${mol.d3 ? html`<figure class="mol-fig"><div id="m3d"></div><figcaption>${d.graphics.model3d_method}.</figcaption></figure>` : html`<p class="muted">No 3D model: ${d.graphics.note || `more than 110 heavy atoms (${d.graphics.heavy_atoms})`}.</p>`}</div>`
        : s ? html`<p class="muted">Not drawn: ${d.graphics.note || "structure too large for a skeletal drawing"}.</p>` : ""}
      ${d.sequence ? html`<h2>Sequence</h2>${sequenceView(d.sequence)}${sourceLine([{ label: d.sequence.source || "ChEMBL", url: d.sequence.source_url }], d.sequence.checked)}` : ""}
      ${!s && !d.sequence ? html`<p>No structure or sequence is available from ChEMBL or PubChem for this entry, so nothing is drawn.</p>` : ""}
      ${d.biologic_description ? html`<h2>Description</h2><p>${d.biologic_description.text}</p>${sourceLine([{ label: "ChEMBL", url: d.biologic_description.source_url }])}` : ""}
      ${d.peptide_note ? html`<h2>Chemistry note</h2><p>${d.peptide_note.chemistry}</p>${sourceLine([{ label: d.peptide_note.source, url: d.peptide_note.source_url }])}` : ""}
      ${d.oligo_note ? html`<h2>Oligonucleotide note</h2>${table(["", ""], [["Modality", d.oligo_note.modality], ["Target", d.oligo_note.target], ["Use", d.oligo_note.use]], "kv")}${sourceLine([{ label: d.oligo_note.source, url: d.oligo_note.source_url }])}` : ""}
      ${s ? html`<h2>Identifiers</h2>${table(["Field", "Value"], [["SMILES", html`<span class="mono wrap">${s.smiles}</span>`], ["InChIKey", html`<span class="mono">${s.inchikey}</span>`],
          ...(s.inchi ? [["InChI", html`<span class="mono wrap">${s.inchi}</span>`]] : []), ["Structure source", html`${ext(s.source_url, s.source)}${s.note ? html` <span class="muted">(${s.note})</span>` : ""}`],
          ["PubChem", s.pubchem_cid ? ext(`https://pubchem.ncbi.nlm.nih.gov/compound/${s.pubchem_cid}`, `CID ${s.pubchem_cid}`) : "No match"], ["Cross-check", s.cross_check], ["Checked", s.checked]], "kv")}` : ""}
      ${d.origin ? html`<h2>Origin</h2><p><b>${d.origin.category}.</b> ${d.origin.expert}</p>${sourceLine(d.origin.sources, d.origin.checked)}
        <p class="muted small">Curated from the sources above; they describe the organism, the discovery or the chemistry, not a manufacturer's current process.</p>` : ""}
      ${d.manufacturing ? html`<h2>Manufacturing notes</h2><p>PubChem holds ${d.manufacturing.notes} manufacturing note${d.manufacturing.notes === 1 ? "" : "s"} for this compound (${d.manufacturing.sources.join(", ")}).
        ${d.manufacturing.mentions.length ? html`Their wording mentions: <b>${d.manufacturing.mentions.join("; ")}</b>.` : "No process keyword was recognised in them."} ${ext(d.manufacturing.url, "Read the notes on PubChem")}</p>
        <p class="muted small">Keyword match on the notes, checked ${d.manufacturing.checked}. The notes may describe historical as well as current processes.</p>` : ""}
      ${Object.keys(p).length ? html`<h2>Properties</h2>${table(["Property", "Value"], [["Formula", p.formula], ["Molecular weight", p.weight], ["AlogP", p.alogp], ["H-bond donors", p.hbd], ["H-bond acceptors", p.hba],
          ["Polar surface area", p.psa], ["Rotatable bonds", p.rotatable_bonds], ["Rule-of-five violations", p.ro5_violations], ["Aromatic rings", p.aromatic_rings], ["Heavy atoms", p.heavy_atoms]].filter((r) => r[1] != null), "kv")}
        ${sourceLine([{ label: "ChEMBL calculated properties", url: d.sources[0].url }])}` : ""}`;
    return { html: page({ level: "deep", trail: [...trail, [SUBS.structure]], kicker: "Deep dive", title: `${d.name}: structure and properties`, body, more: otherSubs(d, base, sub) }),
      mount(root) { const el = root.querySelector("#m3d"); return el && mol.d3 ? mount3D(el, mol.d3) : undefined; } };
  }

  if (sub === "binding") {
    const b = d.binding, site = b ? await data.bindingSite(d.id) : null;
    const body = html`
      ${b && b.related ? html`<p class="callout" id="related-note"><b>Not this medicine's own target.</b> No deposited structure shows ${d.name} in ${b.target} (${b.organism}).
        This one shows it in ${b.related.protein} from <i>${b.related.organism}</i>${b.related.fusion ? " (an engineered fusion protein)" : ""}: the ${b.related.basis}. Residue numbers and some contacts can differ from the ${b.organism} protein.</p>` : ""}
      ${b && b.covalent ? html`<p class="callout"><b>Covalent binding.</b> ${d.name} reacts with its target and stays chemically joined to it: here to ${b.covalent.protein_residue} (atom ${b.covalent.protein_atom}) of chain ${b.covalent.protein_chain}.
        The deposited ligand (${b.covalent.ligand_code}) is the reacted form, so a few of its bonds differ from the medicine before it reacts.</p>` : ""}
      ${b ? html`<div id="bind"></div>
        <p class="muted">The final position of the drug and every contact line come from the deposited structure. The route the drug takes into the pocket is an illustration, and contacts are distance criteria (polar: N or O within 3.5 Å; non-polar: carbon within 4.0 Å; metal: within 2.8 Å), not computed energies.${b.kind === "protein" ? " Only the residues at the interface are drawn, not the whole proteins." : ""}${/modified residues/.test(b.match || "") ? " The chain matches the medicine's recorded sequence except at its modified positions, where the deposited structure may carry the unmodified residue; check the entry before relying on contacts made by those positions." : ""}</p>
        <h2>Structure used</h2>${table(["", ""], [["PDB entry", ext(b.url, b.pdb_id.toUpperCase())], ["Title", b.title], ["Method", b.method], ["Resolution", `${b.resolution} Å`],
          ...(b.related ? [["Protein in the structure", html`${b.related.protein}, <i>${b.related.organism}</i> (${ext(b.related.uniprot_url, `UniProt ${b.related.accession}`)}); ${b.related.basis}`]] : []),
          [b.related ? "Medicine's target (not in this structure)" : "Target", html`${b.target} (${ext(`https://www.ebi.ac.uk/chembl/explore/target/${b.target_chembl_id}`, b.target_chembl_id)}), ${b.organism || ""}`],
          [b.kind === "protein" ? "Medicine in the entry" : "Ligand code", html`${b.ligand_code} <span class="muted">(${b.match})</span>`], ["Checked", b.checked]], "kv")}
        <h2>Contacts shown</h2>${table(["Type", "Drug atom", "Residue", "Distance"], site.contacts.map(([li, ri, , kind, dist]) =>
          [kind, site.kind === "protein" ? site.ligand.labels[site.ligand.owner[li]] : `${site.ligand.atoms[li][0]}${li + 1}`, `${site.residues[ri].label} (chain ${site.residues[ri].chain})`, `${dist.toFixed(2)} Å`]))}
        ${sourceLine([{ label: `RCSB PDB ${b.pdb_id.toUpperCase()}`, url: b.url }, { label: "Entry found through PDBe search", url: `https://www.ebi.ac.uk/pdbe/entry/pdb/${b.pdb_id}` }], b.checked)}`
        : html`<p>No deposited structure of ${d.name} bound to a ChEMBL mechanism target was found in the Protein Data Bank, so there is no binding-site animation. ${d.mechanisms.length ? "The mechanism is shown as a schematic instead." : ""}</p>`}
      ${d.mechanisms.length ? html`<h2>Mechanism${d.mechanisms.length > 1 ? "s" : ""} as a schematic</h2><div class="struct-grid">${d.mechanisms.slice(0, 4).map((m) =>
        html`<div>${schematic(m, d.name)}<p class="small"><b>${m.text}</b> ${refLinks(m.refs)}</p></div>`)}</div>` : html`<p class="muted">ChEMBL records no mechanism for this entry, so no schematic is shown.</p>`}`;
    return { html: page({ level: "deep", trail: [...trail, [SUBS.binding]], kicker: "Deep dive", title: `${d.name}: target binding`, body, more: otherSubs(d, base, sub) }),
      mount(root) { const el = root.querySelector("#bind"); return el ? mountBinding(el, site, b, { drugName: d.name }) : undefined; } };
  }

  if (sub === "approvals") {
    const us = d.us;
    const body = us ? html`<p>${usSummary(us)} from ${num(us.sponsors)} sponsor${us.sponsors === 1 ? "" : "s"}. Showing ${us.applications.length} of ${num(us.applications_total)}: brand and biologic applications first, then the earliest generics.</p>
      ${table(["Application", "Type", "Sponsor", "Brand", "Original approval", "Status", "Combined with"], us.applications.map(([number, kind, sponsor, brand, date, status, combined]) =>
        [ext(us.application_url_template.replace("{last6}", number.slice(-6)), number), kind, sponsor, brand, date ? fmtDate(date) : "not recorded", status, combined]))}
      <p class="muted">Dosage forms: ${us.forms.join(", ") || "not recorded"}. Routes: ${us.routes.join(", ") || "not recorded"}.</p>
      ${sourceLine([{ label: us.source, url: us.source_url }], us.data_date)}` : html`<p>No application was found in Drugs@FDA under this ingredient name or its ChEMBL synonyms. It may be approved outside the US only, be a biologic licensed before the data set begins, or be listed under a different name.</p>`;
    return { html: page({ level: "deep", trail: [...trail, [SUBS.approvals]], kicker: "Deep dive", title: `${d.name}: US applications`, body, more: otherSubs(d, base, sub) }) };
  }

  if (sub === "uses") {
    const body = html`
      ${d.label_note ? html`<h2>Label summary</h2>${table(["", ""], [["Use", d.label_note.what_for], ["Mechanism", d.label_note.how], ["Main warning", d.label_note.warning]], "kv")}${sourceLine([{ label: d.label_note.source, url: d.label_note.source_url }])}` : ""}
      <h2>Indications</h2>${d.indications.length ? html`${table(["Indication (MeSH or EFO term)", "Reference"], d.indications.map((i) => [i.term, refLinks(i.refs)]))}
        <p class="muted">${d.indication_count > d.indications.length ? `Showing ${d.indications.length} of ${d.indication_count}. ` : ""}Only uses that ChEMBL ties to a label or regulator reference (DailyMed, FDA, EMA, ATC) are listed. Some come from labels of combination products that contain this drug.</p>` : html`<p class="muted">None recorded with a label or regulator reference.</p>`}
      <h2>Warnings and withdrawals</h2>${d.warnings.length ? table(["Type", "Class", "Where", "Year", "Note", "Reference"], d.warnings.map((w) => [w.type, w.class, w.country, w.year, w.note, refLinks(w.refs)])) : html`<p class="muted">None recorded in ChEMBL.</p>`}
      ${sourceLine([{ label: "ChEMBL drug indications and warnings", url: d.sources[0].url }])}
      ${d.us ? html`<h2>US supply</h2><p>For shortages and discontinuations that manufacturers have reported, search FDA's own list:
        ${ext(SHORTAGES_URL, "FDA Drug Shortages")} (search by generic name or active ingredient). This site does not copy or check that list, and says nothing about stock in any pharmacy.</p>` : ""}`;
    return { html: page({ level: "deep", trail: [...trail, [SUBS.uses]], kicker: "Deep dive", title: `${d.name}: uses and safety`, body, more: otherSubs(d, base, sub) }) };
  }

  if (sub === "names") {
    const n = d.names || {};
    const line = worldTimeline(d);
    const body = html`<h2>Where it is recorded</h2>${table(["Place", "Record", "Source"], worldRows(d))}
      ${line.length ? html`<h2>First dates by region</h2>${table(["Place", "Date", "What the date is", "Source"], line.map((r) => [r.place, r.yearOnly ? r.date : fmtDate(r.date), r.kind, ext(r.url, r.source)]))}
        <p class="muted">The four records measure different things, so the order is a guide, not a ruling on who approved it first. Dates before each record began (Japan's list: April 2004) are missing.</p>` : ""}
      <p class="muted">A name in a national list shows the drug was named there, not that it is on sale there. Approval records here cover the US, the EU's central procedure, Canada and Japan's new-drug list; other countries are not in this data.</p>
      ${d.eu ? html`<h2>EU: products evaluated centrally by EMA</h2>${table(["Product", "EMA number", "Status", "Authorised", "Ended, refused or withdrawn", "Holder or applicant", "Notes"],
        d.eu.products.map(([product, number, status, authorised, ended, holder, flags, combined, url]) =>
          [ext(url, product), number, status, authorised ? fmtDate(authorised) : "", ended ? fmtDate(ended) : "", holder, [flags, combined && `with ${combined}`].filter(Boolean).join("; ")]))}
        <p class="muted">${d.eu.products_total > d.eu.products.length ? `Showing ${d.eu.products.length} of ${d.eu.products_total}. ` : ""}${d.eu.scope}${d.eu.areas.length ? ` Therapeutic areas: ${d.eu.areas.join("; ")}.` : ""}</p>
        ${sourceLine([{ label: "European Medicines Agency: Download medicine data", url: d.eu.source_url }], `table generated ${d.eu.data_date}`)}` : ""}
      ${d.ca ? html`<h2>Canada: products in Health Canada's Drug Product Database</h2>${table(["Brand", "DIN", "Status", "First marketed", "Company", "Combined with"],
        d.ca.products.map(([brand, din, status, first, company, combined, url]) => [ext(url, brand), din, status, first ? (first.length === 4 ? first : fmtDate(first)) : "", company, combined]))}
        <p class="muted">${d.ca.products_total > d.ca.products.length ? `Showing ${d.ca.products.length} of ${d.ca.products_total}, marketed products first. ` : ""}${d.ca.scope}</p>
        ${sourceLine([{ label: "Health Canada Drug Product Database", url: d.ca.source_url }], `downloaded ${d.ca.data_date}`)}
        <p class="muted small">Contains information licensed under the ${ext(d.ca.licence, "Open Government Licence – Canada")}.</p>` : ""}
      ${d.jp ? html`<h2>Japan: PMDA's list of approved drugs</h2>${table(["Date", "Products", "Applicant", "Approval or change", "New active ingredient", "Review category"],
        d.jp.entries.map(([date, brands, applicant, kind, nai, orphan, category]) => [fmtDate(date), brands, applicant, kind || "", nai ? "Yes" : "", category + (orphan ? " · orphan drug" : "")]))}
        <p class="muted">${d.jp.entries_total > d.jp.entries.length ? `Showing ${d.jp.entries.length} of ${d.jp.entries_total}. ` : ""}${d.jp.scope}</p>
        <p class="src">Created by editing the ${ext(d.jp.source_url, d.jp.source)} (Pharmaceuticals and Medical Devices Agency, PMDA) (${ext(d.jp.page, "list page")}), read ${d.jp.data_date}. Not produced or endorsed by PMDA.</p>` : ""}
      ${d.who_eml ? html`<h2 id="who-eml">WHO Model List of Essential Medicines</h2>
        <p>${d.who_eml.listed_alone ? `${d.name} is on WHO's list of essential medicines.` : `${d.name} is on WHO's list of essential medicines only as part of a combination.`}
          Essential medicines are those WHO lists as meeting the priority health-care needs of a population.</p>
        ${table(["As WHO lists it", "List sections", "Combined with"], d.who_eml.entries.map((r) => [ext(r.url, r.name), r.sections.join("; "), r.with.join(", ")]))}
        <p class="muted">${d.who_eml.entries_total > d.who_eml.entries.length ? `Showing ${d.who_eml.entries.length} of ${d.who_eml.entries_total}. ` : ""}Read from WHO's electronic list (eEML) on ${d.who_eml.checked}. WHO says the PDF lists are the binding versions:
          ${ext(d.who_eml.binding_versions["EML 2025"], "EML 2025")} and ${ext(d.who_eml.binding_versions["EMLc 2025"], "EMLc 2025 (children)")}.</p>
        <p class="src">${d.who_eml.attribution} ${ext(d.who_eml.licence_url, "Licence terms")}. WHO does not endorse this site.</p>` : ""}
      <h2>Names</h2>${table(["Kind", "Names"], [["Trade names", (n.trade || []).join(", ")], ["US brand names (Drugs@FDA)", d.us ? d.us.brands.join(", ") : ""], ["Salt forms merged here", (n.salt_forms || []).join(", ")], ["Research codes", (n.research_codes || []).join(", ")]].filter((r) => r[1]), "kv")}
      ${d.stem ? html`<p>USAN stem <b>${d.stem.stem}</b>: ${d.stem.meaning}.</p>` : ""}
      <h2>ATC classification</h2>${d.atc.length ? table(["Code", "Classification"], d.atc.map((a) => [ext(a.url, a.code), a.levels.join(" › ")])) : html`<p class="muted">No ATC code in ChEMBL.</p>`}
      ${sourceLine(d.sources)}`;
    return { html: page({ level: "deep", trail: [...trail, [SUBS.names]], kicker: "Deep dive", title: `${d.name}: names and worldwide records`, body, more: otherSubs(d, base, sub) }) };
  }

  const body = html`<div class="overview-grid"><div>
      <h2>Mechanism</h2>${d.mechanisms.length ? table(["Mechanism of action", "Action", "Target", "Reference"], d.mechanisms.slice(0, 6).map((m) =>
        [m.text, (m.action || "").toLowerCase(), m.target_chembl_id ? ext(`https://www.ebi.ac.uk/chembl/explore/target/${m.target_chembl_id}`, m.target_chembl_id) : "", refLinks(m.refs)])) : html`<p class="muted">No mechanism recorded in ChEMBL.</p>`}
      <h2>Indications listed in ChEMBL</h2>${d.indications.length ? html`<ul class="tags">${d.indications.slice(0, 10).map((i) => html`<li>${i.term}</li>`)}</ul>` : html`<p class="muted">None recorded with a label or regulator reference.</p>`}
      ${d.stories.length ? html`<h2>History</h2>${d.stories.map((x) => html`<p><b>${x.title}.</b> ${x.expert} ${ext(x.source_url, x.source)}</p>`)}` : ""}
    </div><aside>${mol ? html`<a href="${base}/structure" class="mol-box small" aria-label="Structure and properties">${draw2D(mol.d2, { maxWidth: 300, maxHeight: 220, title: d.name })}</a>` :
      html`<div class="mol-box small none">${d.sequence ? "Sequence available" : "No structure available"}</div>`}
      ${s ? html`<p class="mono small wrap">${s.inchikey}</p>` : ""}</aside></div>${sourceLine(d.sources)}`;
  return { html: page({ trail, kicker: d.type, title: html`${d.name} ${badges}`, lede: d.us && d.us.brands.length ? `US brands: ${d.us.brands.slice(0, 5).join(", ")}` : (d.names.trade || []).slice(0, 5).join(", "),
    keyFacts: [["First approval", d.first_year], ...(d.type_basis ? [["Type", html`${d.type}, from ${d.type_basis}${/WHO INN stem/.test(d.type_basis) ? html` (${ext("https://www.who.int/publications/i/item/9789240099388", "WHO stem book")})` : ""}`]] : []), ["US", d.us ? d.us.status : "No application found"],
      ["EU (central)", d.eu ? `${d.eu.status}${d.eu.first_authorised ? " · " + d.eu.first_authorised.slice(0, 4) : ""}` : "Not in EMA's table"],
      ["Canada", d.ca ? (d.ca.marketed_now ? `Marketed${d.ca.first_marketed ? " · since " + d.ca.first_marketed.slice(0, 4) : ""}` : d.ca.status) : "No product found"],
      ["Japan", d.jp ? (d.jp.first_new_ingredient ? `Approved ${d.jp.first_new_ingredient.slice(0, 4)}` : "Approved before 2004") : "Not in PMDA's list"], ["Routes", howTaken(d.flags)], ["ATC", d.atc.map((a) => a.code).slice(0, 3).join(", ")],
      ["ChEMBL", d.chembl_id ? ext(d.sources[0].url, d.chembl_id) : d.chembl_ref ? html`${ext(d.chembl_ref.url, d.chembl_ref.id)}, structure and mechanism only (${d.chembl_ref.max_phase ? `ChEMBL records phase ${parseInt(d.chembl_ref.max_phase, 10)}` : "no approval recorded"})` : null],
      ["Similar name", d.see_also && d.see_also.length ? html`${d.see_also.map((o, i) => html`${i ? ", " : ""}<a href="#/ref/drug/${o.id}">${o.name}</a>`)}` : null], ["Formula", d.properties && d.properties.formula],
      ["Bound structure", d.binding ? html`<a href="${base}/binding">PDB ${d.binding.pdb_id.toUpperCase()}</a>` : null],
      ["WHO essential medicine", d.who_eml ? html`<a href="${base}/names">${d.who_eml.listed_alone ? "Yes" : "In a combination"}</a>` : null],
      ["Family", fam ? html`<a href="#/ref/families?f=${fam.id}">${fam.stem} · ${fam.target_name}</a> (${fam.members.length})` : null]],
    body: html`${body}${sharePanel(d, shareUrl)}`, more: [...otherSubs(d, base, null), { title: "Plain-language page", text: "The Simple version of this drug.", href: `#/explore/medicine/${d.id}` }] }),
    mount(root) { mountShare(root, d, shareUrl); } };
}

function otherSubs(d, base, current) {
  const notes = { binding: d.binding ? `Animated binding site from PDB ${d.binding.pdb_id.toUpperCase()}.` : d.mechanisms.length ? "Mechanism schematic (no bound structure found)." : "No mechanism or bound structure recorded.",
    structure: d.structure ? "2D, 3D, identifiers, properties." : d.sequence ? "Sequence." : "What is and is not available.",
    approvals: d.us ? `${num(d.us.applications_total)} Drugs@FDA application${d.us.applications_total === 1 ? "" : "s"}.` : "No US application found.",
    uses: `Indications: ${d.indication_count}. Warnings: ${d.warnings.length}.`, names: "Names, and records in the EU, Canada and Japan." };
  return [...Object.keys(SUBS).filter((k) => k !== current).map((k) => ({ title: SUBS[k], text: notes[k], href: `${base}/${k}` })),
    ...(current ? [{ title: "Back to overview", text: d.name, href: base }] : [])];
}

// ------------------------------------------------------------------------------------------------ data sets
export async function topicsPage(role) {
  const list = await data.topics();
  const body = Object.entries(GROUPS).map(([g, label]) => html`<h2>${label}</h2>${topicLinks(list, [g])}`);
  return { html: page({ trail: [HOME, ["Data sets"]], title: "Data sets", lede: "Curated tables. Every row carries a source link; rows without one are not shown.", body, money: await moneyFor(role, ["bookshop", "affiliations"]) }) };
}

export async function topic(key, n) {
  const t = (await data.topics()).find((x) => x.key === key);
  if (!t) throw new Error("No such data set");
  const rows = await data.topicRows(key);
  const trail = [HOME, ["Data sets", "#/ref/topics"], [t.title, `#/ref/topic/${key}`]];
  if (n != null && rows[n]) {
    const r = rows[n], drug = t.drug_field ? await data.findDrugByName(r[t.drug_field]) : null;
    const fields = [...new Set([...t.columns, t.simple_field, t.expert_field].filter(Boolean))];
    const tiers = r.tiers ? html`<h2>From whole body to binding pocket</h2><div class="tiers">${Object.values(r.tiers).map((tier) => html`<section class="x-panel"><h3>${tier.scale}</h3>
        <p class="mono wrap small">${tier.visual}</p><p>${tier.xp}</p>${tier.bonds ? html`<p class="small muted">${typeof tier.bonds === "string" ? tier.bonds : ""}</p>` : ""}</section>`)}</div>
      <p class="muted small">Carried over from the v4 mechanism engine: one source for the whole walk-through (below).</p>` : "";
    const body = html`${table(["Field", "Value"], fields.filter((f) => r[f] != null && r[f] !== "").map((f) => [t.labels[f] || f.replace(/_/g, " "), String(r[f])]), "kv")}${tiers}
      ${sourceLine([{ label: (t.source_field && r[t.source_field]) || "Source", url: r[t.url_field] }])}`;
    return { html: page({ level: "deep", trail: [...trail, [String(r[t.title_field])]], kicker: "Deep dive", title: String(r[t.title_field]), body,
      more: [drug ? { title: `${drug.name} in the catalogue`, text: "Structure, approvals, uses.", href: `#/ref/drug/${drug.id}` } : null,
        drug && drug.flags & data.FLAG.binding ? { title: "Binding animation", text: "From the experimental structure.", href: `#/ref/drug/${drug.id}/binding` } : null, { title: `Back to ${t.title}`, text: `${rows.length} rows.`, href: `#/ref/topic/${key}` }] }) };
  }
  const cols = t.columns.slice(0, 7);
  const body = html`${renderTopicSimulator(key, "ref")}<label class="filter-one">Filter rows <input id="row-filter" type="search"></label>
    <div class="tbl-wrap" tabindex="0" role="region" aria-label="Data set table"><table class="tbl" id="topic-table"><thead><tr>${cols.map((c) => html`<th>${t.labels[c] || c}</th>`)}<th>Source</th></tr></thead>
    <tbody>${rows.map((r, i) => html`<tr>${cols.map((c, k) => html`<td>${k === 0 ? html`<a href="#/ref/topic/${key}/${i}">${r[c]}</a>` : (r[c] == null ? "" : String(r[c]).length > 220 ? String(r[c]).slice(0, 200) + "…" : r[c])}</td>`)}
      <td>${isUrl(r[t.url_field]) ? ext(r[t.url_field], "source") : ""}</td></tr>`)}</tbody></table></div>`;
  return {
    html: page({ trail, title: t.title, lede: t.intro, keyFacts: [["Rows", rows.length], ["Columns", t.columns.length]], body,
      more: [t.lab ? { title: "Interactive lab (classic)", text: "The v4 version of this topic, with its simulators.", href: `legacy/index.html#${t.lab[0]}/${t.lab[1]}`, external: true } : null,
        { title: "Plain-language version", text: "The same topic in the Simple environment.", href: `#/explore/topic/${key}` }] }),
    mount(root) {
      mountTopicSimulator(root, key);
      root.querySelector("#row-filter").addEventListener("input", (e) => { const q = e.target.value.toLowerCase();
        root.querySelectorAll("#topic-table tbody tr").forEach((tr) => { tr.hidden = !!q && !tr.textContent.toLowerCase().includes(q); }); });
    },
  };
}

// ------------------------------------------------------------------------------------------------ sources and method
export async function dataPage() {
  const st = await data.stats();
  const body = html`
    <h2>Sources</h2>${table(["Source", "What it provides", "Version", "Licence"], [
      [ext("https://www.ebi.ac.uk/chembl/", "ChEMBL (EMBL-EBI)"), "Approved drugs worldwide (maximum phase 4), structures, sequences, mechanisms, indications, warnings, ATC codes, international names, EMA cross-references", st.chembl_release.replace("_", " "), ext("https://creativecommons.org/licenses/by-sa/3.0/", "CC BY-SA 3.0")],
      [ext("https://open.fda.gov/apis/drug/drugsfda/", "FDA Drugs@FDA via openFDA"), `Every US application (${num(st.fda_applications)}), sponsors, brands, approval dates, marketing status`, `File dated ${st.drugsfda_data_date}`, "US government public data"],
      [ext("https://www.ema.europa.eu/en/medicines/download-medicine-data", "European Medicines Agency"), `EU status, dates, holders and flags for ${num(st.with_eu_record)} medicines evaluated through the centralised procedure`, "Table regenerated nightly by EMA", ext("https://www.ema.europa.eu/en/about-us/about-website/legal-notice", "Reuse allowed with EMA acknowledged as the source")],
      [ext("https://health-products.canada.ca/dpd-bdpp/", "Health Canada Drug Product Database"), `Products, status and first market dates in Canada for ${num(st.with_ca_record)} medicines (${num(st.ca_products)} human and radiopharmaceutical products; homeopathic-only products left out)`, `Downloaded ${st.ca_data_date} from the DPD API`, ext("https://open.canada.ca/en/open-government-licence-canada", "Open Government Licence – Canada")],
      [ext("https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html", "Pharmaceuticals and Medical Devices Agency (PMDA), Japan"), `New-drug approvals and changes in Japan for ${num(st.with_jp_record)} medicines, read from the ${st.jp_title} (dates, products, applicants, new-active-ingredient and orphan flags; PMDA's notes are not copied). Created by editing PMDA's list; the PDF is saved by hand because PMDA does not permit automated downloads`, `Read ${st.jp_data_date}`, ext("https://www.pmda.go.jp/english/0013.html", "Public Data License 1.0 (PMDA site policy)")],
      [ext("https://list.essentialmeds.org/", "WHO electronic Essential Medicines List (eEML)"), `Which medicines are on the WHO Model List of Essential Medicines, and in which sections: ${num(st.eml_medicines || 0)} entries read, ${num(st.with_who_eml || 0)} catalogue medicines matched by name (${num(st.who_eml_alone || 0)} listed on their own). WHO says the 2025 PDF lists are the binding versions`, `Read ${st.eml_checked || ""}`, ext("https://list.essentialmeds.org/licencing", "CC BY 3.0 IGO (no use with advertising of commercial products)")],
      [ext("https://pubchem.ncbi.nlm.nih.gov/", "PubChem (NIH)"), "Cross-check of each structure by InChIKey; structures for FDA-only ingredient names", `Queried ${st.fetched_on}`, "US government public data"],
      [ext("https://www.rcsb.org/", "Protein Data Bank (RCSB, PDBe)"), `Experimental structures of ${num(st.with_binding_site)} drugs bound to their targets (${num(st.with_related_binding)} of them in the same protein of another species, labelled on the page): binding-site coordinates and measured contacts`, `Queried ${st.fetched_on}`, ext("https://creativecommons.org/publicdomain/zero/1.0/", "CC0")],
      [ext("https://www.rdkit.org/", "RDKit"), "2D layouts and computed 3D models, generated from the sourced SMILES", "2026.09", "BSD"]])}
    <p>Data from ChEMBL is used under CC BY-SA 3.0; the per-drug files in this site that derive from ChEMBL are shared under the same licence.</p>
    <h2>Method</h2>
    <ul><li>One entry per active ingredient. ChEMBL salt forms are merged into their parent molecule.</li>
      <li>Drugs@FDA ingredient names are matched to ChEMBL names and synonyms, after removing salt words and biosimilar suffixes. ${num(st.fda_only)} ingredient names had no ChEMBL match and appear as FDA-only entries.</li>
      <li>Nothing is drawn without a sourced structure. ${st.graphics.not_drawn.length} structures were too large to draw.</li>
      <li>Uses are listed only where ChEMBL ties them to a label or regulator reference.</li></ul>
    <h2>What is not covered</h2>
    <ul><li>Approval status outside the US, the EU's centralised procedure, Canada and Japan. Medicines licensed by individual EU countries are not in EMA's table; Japan's list starts in April 2004 and leaves out generics; there are no national registers for China, the UK, India, Australia or others. ChEMBL shows only that a drug is approved somewhere.</li>
      <li>Canadian and Japanese records are matched by ingredient name. Japanese names (JAN) that differ from the international name are not matched unless the same name appears in another source: ${num((st.jp_same_brand_skipped || []).length + (st.jp_spelling_variants_skipped || []).length + (st.jp_combinations_skipped || []).length)} PMDA names were set aside rather than guessed.</li>
      <li>Medicines approved only outside the US and absent from ChEMBL.</li><li>The synthesis route of each individual drug. Explanations are given per kind of medicine, plus a pointer to PubChem's manufacturing notes where they exist, and a short sourced origin note for a few medicines.</li>
      <li>Binding animations for drugs with no deposited structure bound to their own target (or the same protein in another species); those get a symbolic schematic.</li>
      <li>Vaccines, blood products and most cell and gene therapies beyond the entries ChEMBL lists.</li><li>Doses, prices and current availability.</li></ul>`;
  return { html: page({ trail: [HOME, ["Sources and method"]], title: "Sources, licences and coverage", lede: "Where every number comes from, and what is missing.",
    keyFacts: [["Data pulled", st.fetched_on], ["Medicines", num(st.total)], ["ChEMBL", st.chembl_release.replace("_", " ")]], body }) };
}

// ------------------------------------------------------------------------------------------------ families and comparison
// Ideas from Gemini's v5.22-v5.23 patches, rebuilt on the catalogue's own fields.
export async function familiesPage(query) {
  const all = await data.families();
  const pick = query.get("f") || "", q = (query.get("q") || "").toLowerCase();
  const list = all.families.filter((f) => (!pick || f.id === pick) && (!q || f.stem.toLowerCase().includes(q) || f.target_name.toLowerCase().includes(q)
    || f.members.some((m) => m.name.toLowerCase().includes(q))));
  const card = (f) => html`<section class="family"><h2>${f.stem} · ${f.target_name}</h2>
    <p class="muted">${f.stem_meaning ? html`Stem <b>${f.stem}</b>: ${f.stem_meaning}. ` : ""}First target in ChEMBL: ${ext(f.target_url, f.target_name)}. ${f.members.length} medicines, ${f.first_year} to ${f.last_year}.</p>
    <ol class="fam-line">${f.members.map((m, i) => html`<li><b>${m.year}</b> <a href="#/ref/drug/${m.id}">${m.name}</a>${m.binding ? html` <span class="tag">3D</span>` : ""}${m.eml ? html` <span class="tag">WHO</span>` : ""}
      ${i ? html`<a class="small" href="#/ref/compare/${f.members[0].id}/${m.id}">compare with ${f.members[0].name}</a>` : html`<span class="small muted">earliest in these records</span>`}</li>`)}</ol></section>`;
  const body = html`<form id="fam-form" class="filters"><label>Stem, target or medicine <input name="q" type="search" value="${query.get("q") || ""}"></label>
      ${pick ? html`<a href="#/ref/families">Show all families</a>` : html`<a href="#/ref/families">Clear</a>`}</form>
    <p id="count"><b>${num(list.length)}</b> of ${num(all.count)} families</p>
    <div id="fam-list">${list.slice(0, 30).map(card)}</div>
    ${list.length > 30 ? html`<p><button class="btn" id="more" type="button">Show 30 more</button></p>` : ""}
    <p class="src">${all.note} Tags: 3D = binding-site animation; WHO = on the WHO Essential Medicines List. Built ${all.built} from ChEMBL stems and targets and the catalogue's approval records.</p>`;
  return {
    html: page({ trail: [HOME, ["Medicine families"]], title: "Medicine families", lede: "Medicines that share a name stem and a target, in the order they were first approved.", body }),
    mount(root) {
      const form = root.querySelector("#fam-form");
      form.addEventListener("submit", (e) => { e.preventDefault(); const v = form.q.value.trim(); location.hash = "#/ref/families" + (v ? "?q=" + encodeURIComponent(v) : ""); });
      let shown = 30;
      root.querySelector("#more")?.addEventListener("click", (e) => {
        root.querySelector("#fam-list").insertAdjacentHTML("beforeend", list.slice(shown, shown + 30).map((f) => String(card(f))).join("")); shown += 30;
        if (shown >= list.length) e.target.remove();
      });
    },
  };
}

const COMPARE_EXAMPLES = [["semaglutide", "tirzepatide"], ["imatinib", "dasatinib"], ["atorvastatin", "rosuvastatin"], ["lovastatin", "atorvastatin"]];

export async function comparePage(aId, bId) {
  const index = await data.drugIndex();
  const known = new Set(index.map((d) => d.id));
  const examples = COMPARE_EXAMPLES.filter(([a, b]) => known.has(a) && known.has(b));
  const exampleLinks = html`<p>Examples: ${examples.map(([a, b], i) => html`${i ? " · " : ""}<a href="#/ref/compare/${a}/${b}">${index.find((d) => d.id === a).name} and ${index.find((d) => d.id === b).name}</a>`)}</p>`;
  const picker = (label, slot) => html`<form class="filters cmp-pick" data-slot="${slot}"><label>${label} <input type="search" autocomplete="off" aria-label="${label}"></label><ul class="suggest" hidden></ul></form>`;
  const wire = (root, current) => root.querySelectorAll(".cmp-pick").forEach((form) => {
    const slot = form.dataset.slot;
    wireSearch(form.querySelector("input"), form.querySelector("ul"), (d) => slot === "a" ? `#/ref/compare/${d.id}/${current.b || ""}` : `#/ref/compare/${current.a || ""}/${d.id}`);
  });
  if (!aId || !bId || !known.has(aId) || !known.has(bId)) {
    const body = html`<p>Pick two medicines to see their records side by side.</p>${picker("First medicine", "a")}${picker("Second medicine", "b")}
      ${aId && known.has(aId) ? html`<p>First: <b>${index.find((d) => d.id === aId).name}</b></p>` : ""}${bId && known.has(bId) ? html`<p>Second: <b>${index.find((d) => d.id === bId).name}</b></p>` : ""}${exampleLinks}`;
    return { html: page({ trail: [HOME, ["Compare"]], title: "Compare two medicines", body }), mount(root) { wire(root, { a: known.has(aId) ? aId : "", b: known.has(bId) ? bId : "" }); } };
  }
  const [a, b] = await Promise.all([data.drug(aId), data.drug(bId)]);
  const [fa, fb] = await Promise.all([data.familyOf(a.id), data.familyOf(b.id)]);
  const firstDate = (d, place) => { const r = worldTimeline(d).find((x) => x.place === place); return r ? html`${r.yearOnly ? r.date : fmtDate(r.date)} <span class="muted small">(${r.kind})</span>` : html`<span class="muted">not in these records</span>`; };
  const mech = (d) => d.mechanisms.length ? html`${d.mechanisms.slice(0, 2).map((m, i) => html`${i ? html`<br>` : ""}${m.text}${m.target_name ? html` <span class="muted small">(${m.target_name})</span>` : ""}`)}` : html`<span class="muted">none recorded in ChEMBL</span>`;
  const row = (label, f) => [label, f(a), f(b)];
  const rows = [
    row("Type", (d) => d.type),
    row("First approved (earliest year in these records)", (d) => d.first_year || "not recorded"),
    row("How it works (ChEMBL)", mech),
    row("United States", (d) => firstDate(d, "United States")),
    row("European Union (EMA)", (d) => firstDate(d, "European Union")),
    row("Japan (PMDA, since 2004)", (d) => firstDate(d, "Japan")),
    row("Canada (first marketed)", (d) => firstDate(d, "Canada")),
    row("WHO Essential Medicines List", (d) => d.who_eml ? (d.who_eml.listed_alone ? "Yes" : "In a combination") : "No"),
    row("Family", (d) => { const f = d.id === a.id ? fa : fb; return f ? html`<a href="#/ref/families?f=${f.id}">${f.stem} · ${f.target_name}</a>` : html`<span class="muted">none</span>`; }),
    row("Bound structure", (d) => d.binding ? html`<a href="#/ref/drug/${d.id}/binding">PDB ${d.binding.pdb_id.toUpperCase()}</a>` : html`<span class="muted">none found</span>`),
    row("Formula", (d) => (d.properties && d.properties.formula) || ""),
    row("Molecular weight", (d) => (d.properties && d.properties.weight) || ""),
  ];
  const body = html`<p><a href="#/ref/compare/${b.id}/${a.id}">Swap sides</a> · <a href="#/ref/compare">Pick other medicines</a></p>
    <div class="tbl-wrap" tabindex="0" role="region" aria-label="Comparison table"><table class="tbl cmp"><thead><tr><th></th><th><a href="#/ref/drug/${a.id}">${a.name}</a></th><th><a href="#/ref/drug/${b.id}">${b.name}</a></th></tr></thead>
      <tbody>${rows.map(([l, x, y]) => html`<tr><th scope="row">${l}</th><td>${x}</td><td>${y}</td></tr>`)}</tbody></table></div>
    <p class="muted">The regions' dates measure different things (Canada's is the first sale), and records start at different times, so a missing date does not mean it was never approved there.</p>
    ${sourceLine([...a.sources.slice(0, 2), ...b.sources.slice(0, 2)])}${exampleLinks}`;
  return { html: page({ trail: [HOME, ["Compare", "#/ref/compare"], [`${a.name} and ${b.name}`]], title: `${a.name} and ${b.name}`, lede: "Side by side, from the same records as each medicine's page.", body }) };
}
