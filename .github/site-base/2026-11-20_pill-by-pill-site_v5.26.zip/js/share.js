// Sharing and citing a medicine page. No share buttons from social networks are loaded: the links below are plain links that
// open the network's own share page, so nothing is sent anywhere until the reader clicks. Student pages get only "Copy link"
// and the device's own share sheet.
import { html } from "./ui.js";
import { getJSON } from "./data.js";

let siteCfg = null;
export async function site() {
  if (!siteCfg) {
    try { siteCfg = await getJSON("config/site.json"); } catch (e) { siteCfg = {}; }
  }
  return siteCfg;
}

/** The public address of a medicine: a real page (not a #/ route), so search engines and link previews can read it. */
export async function medicineUrl(id) {
  const base = ((await site()).base_url || location.origin).replace(/\/$/, "");
  return `${base}/medicine/${encodeURIComponent(id)}/`;
}

function networks(url, text) {
  const u = encodeURIComponent(url), t = encodeURIComponent(text);
  return [["Email", `mailto:?subject=${t}&body=${t}%0A${u}`], ["X", `https://twitter.com/intent/tweet?url=${u}&text=${t}`],
    ["Facebook", `https://www.facebook.com/sharer/sharer.php?u=${u}`], ["LinkedIn", `https://www.linkedin.com/sharing/share-offsite/?url=${u}`],
    ["Reddit", `https://www.reddit.com/submit?url=${u}&title=${t}`], ["WhatsApp", `https://wa.me/?text=${t}%20${u}`]];
}

/** A share-and-cite panel. simple = student page: copy link and the device share sheet only. */
export function sharePanel(d, url, { simple = false } = {}) {
  const text = `${d.name} on Pill by Pill`;
  const year = new Date().getFullYear(), today = new Date().toISOString().slice(0, 10);
  const cite = `Pill by Pill. (${year}). ${d.name}. Retrieved ${today}, from ${url}`;
  return html`<section class="share-panel" aria-label="Share or cite this page">
    <h2>${simple ? "Share or use in your homework" : "Share or cite"}</h2>
    <p class="share-row"><button type="button" class="btn small" data-share="copy">Copy link</button>
      <button type="button" class="btn small" data-share="native" hidden>Share…</button>
      ${simple ? "" : networks(url, text).map(([name, href]) => html` <a class="share-link" href="${href}" target="_blank" rel="noopener noreferrer">${name}</a>`)}
      <span class="share-status muted small" aria-live="polite"></span></p>
    <p class="cite"><span class="muted small">${simple ? "To cite it:" : "Cite (APA style):"}</span> <span class="cite-text">${cite}</span>
      <button type="button" class="btn small" data-share="cite">Copy citation</button></p>
  </section>`;
}

/** Wire the buttons of a share panel inside root. */
export function mountShare(root, d, url) {
  const panel = root.querySelector(".share-panel");
  if (!panel) return;
  const status = panel.querySelector(".share-status");
  const copy = async (value, done) => {
    try { await navigator.clipboard.writeText(value); status.textContent = done; }
    catch (e) { status.textContent = value; }                       // no clipboard permission: show the text to copy by hand
  };
  panel.querySelector('[data-share="copy"]').addEventListener("click", () => copy(url, "Link copied."));
  panel.querySelector('[data-share="cite"]').addEventListener("click", () => copy(panel.querySelector(".cite-text").textContent, "Citation copied."));
  const native = panel.querySelector('[data-share="native"]');
  if (navigator.share) {
    native.hidden = false;
    native.addEventListener("click", () => navigator.share({ title: `${d.name} · Pill by Pill`, url }).catch(() => {}));
  }
}
