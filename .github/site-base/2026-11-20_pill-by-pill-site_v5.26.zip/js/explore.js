// The Simple environment ("Explore"): story-led pages for students, parents, teachers and history readers.
// Every function returns { html, mount? }. mount(root) wires up anything interactive after the HTML is in the page.
import { html, raw, ext, sourceLine, num, store } from "./ui.js";
import * as data from "./data.js";
import { page, ROLES } from "./layout.js";
import { draw2D, mount3D, atomCounts, sequenceView } from "./molecule.js";
import { mechanismPlain, howTaken, approvedIn, worldTimeline } from "./drugfacts.js";
import { moneyFor } from "./money.js";
import { wireSearch } from "./search.js";
import { mountBinding, schematic } from "./binding.js";
import { renderTopicSimulator, mountTopicSimulator } from "./simulators.js";
import { sharePanel, mountShare, medicineUrl } from "./share.js";

const HOME = ["Home", "#/explore"];
const ELEMENT_NAMES = { C: "carbon", H: "hydrogen", O: "oxygen", N: "nitrogen", S: "sulfur", P: "phosphorus", F: "fluorine", Cl: "chlorine",
  Br: "bromine", I: "iodine", Na: "sodium", K: "potassium", Ca: "calcium", Fe: "iron", Pt: "platinum", Li: "lithium", Mg: "magnesium" };
const SPOTLIGHT = ["aspirin", "caffeine", "ibuprofen", "paclitaxel", "morphine", "metformin", "atorvastatin", "penicillin-g", "artemether", "quinine"];
const typeInfo = async (type) => (await data.howMade()).types[type] || (await data.howMade()).types.Unknown;

function drugCard(d, types) {
  const t = types[data.TYPE_NAMES[d.type]] || types.Unknown;
  return html`<a class="x-card" href="#/explore/medicine/${d.id}" data-drug="${d.id}" data-has-structure="${d.flags & data.FLAG.structure ? 1 : 0}">
    <div class="thumb" aria-hidden="true">${t.icon}</div><b>${d.name}</b>
    <span>${d.brand ? d.brand + " · " : ""}${t.simple_name}${d.year ? " · " + d.year : ""}</span></a>`;
}

/** Draw molecule thumbnails as cards scroll into view, so a page of cards costs nothing until it is looked at. */
function lazyThumbs(root) {
  const io = new IntersectionObserver((entries) => entries.forEach(async (e) => {
    if (!e.isIntersecting) return;
    io.unobserve(e.target);
    try {
      const m = await data.molecule(e.target.dataset.drug);
      if (m.d2.atoms.length <= 70) e.target.querySelector(".thumb").innerHTML = draw2D(m.d2, { maxWidth: 150, maxHeight: 96 });
    } catch (err) { /* no drawing for this one: the icon stays */ }
  }), { rootMargin: "200px" });
  root.querySelectorAll('.x-card[data-has-structure="1"]').forEach((el) => io.observe(el));
}

function searchBox(placeholder) {
  return html`<form class="x-search" role="search" autocomplete="off"><label class="sr" for="x-q">Find a medicine</label>
    <input id="x-q" type="search" placeholder="${placeholder}"><ul id="x-suggest" class="suggest" hidden></ul></form>`;
}
const wireBox = (root) => wireSearch(root.querySelector("#x-q"), root.querySelector("#x-suggest"), (d) => `#/explore/medicine/${d.id}`);

// ------------------------------------------------------------------------------------------------ student home
export async function home() {
  const [st, discoveries, index] = await Promise.all([data.stats(), data.topicRows("discoveries"), data.drugIndex()]);
  const start = Math.floor(Date.now() / 86400000) % discoveries.length;
  const years = Object.keys(st.us_novel_by_year).map(Number).filter((y) => y >= 1940);
  const body = html`
    ${searchBox(`Search ${num(st.total)} medicines…`)}
    <div class="x-two">
      <section class="x-panel" id="today" aria-live="polite"></section>
      <section class="x-panel"><h2>How many new medicines since you were born?</h2>
        <label>I was born in <input id="born" type="number" min="${Math.min(...years)}" max="${Math.max(...years)}" value="${store.get("born") || 2012}" inputmode="numeric"></label>
        <p class="big-number"><span id="since">…</span> brand-new medicines</p><p id="since-note" class="muted"></p>
        <div id="year-chart" class="year-chart" role="img" aria-label="New medicines approved each year"></div>
        ${sourceLine([{ label: "FDA Drugs@FDA: approvals marked New Molecular Entity", url: "https://www.accessdata.fda.gov/scripts/cder/daf/" }], st.drugsfda_data_date)}
      </section>
    </div>
    <section class="x-panel spot"><h2>Molecule of the moment</h2><div id="spot"><p class="muted">Loading a molecule…</p></div></section>`;
  const more = [
    { title: "📖 Stories", text: "Mould, tree bark and lucky accidents.", href: "#/explore/stories" },
    { title: "💊 Medicines A to Z", text: `All ${num(st.total)}, with pictures.`, href: "#/explore/medicines" },
    { title: "⚗️ How medicines are made", text: "By chemists, by cells, by machines.", href: "#/explore/made" },
    { title: "🔬 Zoom in", text: "Eight medicines, from whole body down to atoms.", href: "#/explore/topic/moa" },
    { title: "🔤 Name decoder", text: "What -mab and -statin really mean.", href: "#/explore/topic/stems" },
    { title: "👩‍🔬 Jobs in medicine-making", text: "Who does this for a living?", href: "#/explore/topic/careers" },
    { title: "🏆 Quiz", text: "Ten questions. Can you reach Chief Scientist?", href: "#/explore/quiz" }];
  return {
    html: page({ level: "landing", kicker: "For students and the curious", title: "Every medicine has a story.",
      lede: "Find out where medicines come from, what their molecules look like and how they work.", body, more, moreHeading: "Pick a trail" }),
    mount(root) {
      wireBox(root);
      let n = start;
      const today = root.querySelector("#today");
      const show = () => {
        const d = discoveries[n % discoveries.length];
        today.innerHTML = html`<p class="kicker">Discovery of the day</p><h2>${d.title}</h2><p class="who">${d.year} · ${d.discoverers}</p><p>${d.simple}</p>
          ${sourceLine([{ label: d.source_title, url: d.source_url }])}
          <p><button type="button" class="btn" id="next-disc">Next discovery</button> <a href="#/explore/topic/discoveries">See all ${discoveries.length}</a></p>`;
        today.querySelector("#next-disc").addEventListener("click", () => { n++; show(); });
      };
      show();
      const born = root.querySelector("#born"), max = Math.max(...Object.values(st.us_novel_by_year));
      const update = () => {
        const y = Math.max(Math.min(...years), Math.min(Math.max(...years), parseInt(born.value, 10) || 2012));
        store.set("born", String(y));
        const total = years.filter((k) => k >= y).reduce((s, k) => s + (st.us_novel_by_year[k] || 0), 0);
        root.querySelector("#since").textContent = num(total);
        root.querySelector("#since-note").textContent = `In ${y} itself the FDA approved ${st.us_novel_by_year[y] || 0}. FDA's own yearly count can differ by one or two.`;
        root.querySelector("#year-chart").innerHTML = years.map((k) =>
          `<i class="${k >= y ? "on" : ""}" style="height:${Math.round(100 * (st.us_novel_by_year[k] || 0) / max)}%" title="${k}: ${st.us_novel_by_year[k] || 0}"></i>`).join("");
      };
      born.addEventListener("input", update); update();
      const pool = SPOTLIGHT.filter((id) => index.some((d) => d.id === id));
      const pick = pool[Math.floor(Math.random() * pool.length)];
      let stop;
      if (pick) data.molecule(pick).then((m) => {
        const d = index.find((x) => x.id === pick), spot = root.querySelector("#spot");
        if (!spot || !m.d3) return;
        spot.innerHTML = html`<div class="spot-grid"><div id="spot-3d"></div><div><h3>${d.name}</h3><p>This is a computer model of one ${d.name.toLowerCase()} molecule. Each ball is an atom.</p>
          <p><a class="btn" href="#/explore/medicine/${d.id}">Meet ${d.name}</a></p></div></div>`;
        stop = mount3D(spot.querySelector("#spot-3d"), m.d3);
      });
      return () => stop && stop();
    },
  };
}

// ------------------------------------------------------------------------------------------------ parent / teacher landing
export async function teach() {
  const st = await data.stats();
  const body = html`
    <section class="x-panel"><h2>Ready to use in class or at the kitchen table</h2>
      <ul class="plain">
        <li><a href="#/explore/topic/discoveries"><b>32 discovery stories</b></a>: two short paragraphs each, with the source to read together.</li>
        <li><a href="#/explore/topic/ancient"><b>Ancient healers</b></a>: plants that became modern medicines.</li>
        <li><a href="#/explore/made"><b>How medicines are made</b></a>: chemistry, living cells and machines, in plain words.</li>
        <li><a href="#/explore/topic/stems"><b>Name decoder</b></a>: a word-roots activity using real medicine names.</li>
        <li><a href="#/explore/quiz"><b>Quiz</b></a>: ten questions a round, each answer explained and sourced.</li>
        <li><a href="#/explore/topic/careers"><b>Careers</b></a>: nine jobs with pay and schooling, from US labour statistics.</li>
      </ul></section>
    <section class="x-panel"><h2>Safe for a classroom</h2>
      <ul class="plain"><li>No adverts, no tracking and no sign-up. The site loads nothing from other companies.</li>
        <li>Every fact links to its source, so students can check it.</li>
        <li>It teaches about medicines. It never tells anyone what to take.</li>
        <li>Student pages never show anything for sale. Offers for grown-ups appear only on pages like this one.</li></ul></section>`;
  return { html: page({ level: "landing", trail: [["Start", "#/"], ["For parents and teachers"]], kicker: "For parents and teachers", title: "Teach with Pill by Pill.",
    lede: "Short, sourced pages on how medicines are discovered, made and named.",
    keyFacts: [["Medicines covered", num(st.total)], ["Discovery stories", "32"], ["Sourced data sets", "33"]],
    body, more: [{ title: "Start where students start", text: "The student home page.", href: "#/explore" },
      { title: "The expert side", text: "The same medicines with full data.", href: "#/ref" }], money: await moneyFor("teacher") }) };
}

// ------------------------------------------------------------------------------------------------ history landing
export async function history() {
  const [st, discoveries] = await Promise.all([data.stats(), data.topicRows("discoveries")]);
  const max = Math.max(...Object.values(st.by_decade));
  const body = html`
    <section class="x-panel"><h2>Medicines by the decade they first appeared</h2>
      <div class="decades">${Object.entries(st.by_decade).map(([dec, n]) =>
        html`<a href="#/explore/medicines?decade=${dec}"><i style="height:${Math.round(90 * n / max) + 10}%"></i><b>${dec}s</b><span>${n}</span></a>`)}</div>
      <p class="muted">Earliest approval year recorded in ChEMBL, Drugs@FDA, EMA's table or PMDA's list. Records before the 1940s are thin.</p></section>
    <section class="x-panel"><h2>A short timeline</h2><ol class="timeline">${discoveries.slice(0, 8).map((d) =>
      html`<li><b>${d.year}</b> ${d.title}</li>`)}</ol><p><a class="btn" href="#/explore/topic/discoveries">All ${discoveries.length} discoveries</a></p></section>`;
  const more = [{ title: "🏺 Ancient healers", text: "Six traditions and what came of them.", href: "#/explore/topic/ancient" },
    { title: "⏳ From idea to pharmacy", text: "How long famous medicines took.", href: "#/explore/topic/timelines" },
    { title: "🚫 Taken off the market", text: "Withdrawals and what they taught.", href: "#/explore/topic/withdrawals" },
    { title: "🌍 When countries disagreed", text: "Approved here, refused there.", href: "#/explore/topic/divergences" },
    { title: "🏛️ The regulators", text: "Who decides, and since when.", href: "#/explore/topic/agencies" }];
  return { html: page({ level: "landing", trail: [["Start", "#/"], ["For history readers"]], kicker: "For history readers", title: "Four thousand years of medicine.",
    lede: "From willow bark on clay tablets to gene editing.", body, more, money: await moneyFor("history") }) };
}

// ------------------------------------------------------------------------------------------------ browse
export async function medicines(query) {
  const [index, made] = await Promise.all([data.drugIndex(), data.howMade()]);
  const letter = (query.get("letter") || "").toUpperCase(), type = query.get("type") || "", decade = query.get("decade") || "";
  let list = index;
  if (letter) list = list.filter((d) => d.name[0].toUpperCase() === letter);
  if (type) list = list.filter((d) => d.type === type);
  if (decade) list = list.filter((d) => d.year && Math.floor(d.year / 10) * 10 === Number(decade));
  const link = (over) => {
    const p = new URLSearchParams({ ...(letter && { letter }), ...(type && { type }), ...(decade && { decade }), ...over });
    [...p.keys()].forEach((k) => { if (!p.get(k)) p.delete(k); });
    return "#/explore/medicines" + (p.toString() ? "?" + p : "");
  };
  const types = Object.entries(data.TYPE_NAMES).filter(([code]) => index.some((d) => d.type === code));
  const body = html`
    ${searchBox("Type a medicine name…")}
    <div class="chips-row" aria-label="First letter">${"ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((L) =>
      html`<a class="chip${L === letter ? " on" : ""}" href="${link({ letter: L === letter ? "" : L })}">${L}</a>`)}</div>
    <div class="chips-row" aria-label="Kind of medicine">${types.map(([code, name]) =>
      html`<a class="chip${code === type ? " on" : ""}" href="${link({ type: code === type ? "" : code })}">${made.types[name]?.icon || "💊"} ${made.types[name]?.simple_name || name}</a>`)}</div>
    ${decade ? html`<p>Showing medicines first approved in the ${decade}s. <a href="${link({ decade: "" })}">Show all decades</a></p>` : ""}
    <p class="muted" id="count">${num(list.length)} medicine${list.length === 1 ? "" : "s"}</p>
    <div class="x-cards" id="cards">${list.slice(0, 36).map((d) => drugCard(d, made.types))}</div>
    ${list.length > 36 ? html`<p><button class="btn" id="more" type="button">Show more</button></p>` : ""}`;
  return {
    html: page({ trail: [HOME, ["Medicines"]], title: "Medicines A to Z", lede: "Every medicine in the catalogue. Tap one to see its molecule.", body }),
    mount(root) {
      wireBox(root); lazyThumbs(root);
      let shown = 36;
      root.querySelector("#more")?.addEventListener("click", (e) => {
        const next = list.slice(shown, shown + 36); shown += 36;
        root.querySelector("#cards").insertAdjacentHTML("beforeend", next.map((d) => drugCard(d, made.types)).join(""));
        lazyThumbs(root);
        if (shown >= list.length) e.target.remove();
      });
    },
  };
}

// ------------------------------------------------------------------------------------------------ one medicine
function atomSentence(d2) {
  const counts = Object.entries(atomCounts(d2)).sort((a, b) => b[1] - a[1]);
  const total = counts.reduce((s, [, n]) => s + n, 0);
  return `${total} atoms: ` + counts.map(([el, n]) => `${n} ${ELEMENT_NAMES[el] || el}`).join(", ") + ".";
}

async function picture(d, big) {
  if (d.graphics && d.graphics.drawing) {
    const m = await data.molecule(d.id);
    const large = m.d2.atoms.length > 90;
    return { m, html: html`<figure class="mol-fig"><div class="mol-box">${draw2D(m.d2, big ? { maxWidth: 720, maxHeight: 520, title: d.name } : { title: d.name })}</div>
      <figcaption>${large ? "A big molecule. " : ""}${atomSentence(m.d2)} Lines are bonds; every unlabelled corner is a carbon atom.</figcaption></figure>` };
  }
  if (d.sequence && d.sequence.components.length) {
    const longest = Math.max(...d.sequence.components.map((c) => c.sequence.length));
    return { html: html`<div class="mol-box seq-box"><p>${d.name} is ${d.sequence.components.length > 1 ? `${d.sequence.components.length} chains` : "a chain"} of building blocks${longest > 60 ? `, the longest ${num(longest)} long` : ""}. It is too big to draw atom by atom, so here is the order of the blocks.</p>
      ${sequenceView(d.sequence, { simple: !big })}</div>` };
  }
  if (d.oligo_note || d.biologic_description) {
    const note = d.oligo_note ? `${d.name} is a gene-targeted strand (${d.oligo_note.modality}) aimed at ${d.oligo_note.target}.` : d.biologic_description.text + ".";
    return { html: html`<div class="mol-box none"><p>${note} Our sources do not give its full sequence, so there is no picture.</p></div>` };
  }
  return { html: html`<div class="mol-box none"><p>No picture yet. ${d.graphics && d.graphics.note ? d.graphics.note + "." : "Our sources do not give a structure for this medicine, and we do not draw anything we cannot source."}</p></div>` };
}

export async function medicine(id, sub) {
  const d = await data.drug(id);
  const t = await typeInfo(d.type);
  const trail = [HOME, ["Medicines", "#/explore/medicines"], [d.name, `#/explore/medicine/${d.id}`]];
  const brands = (d.us && d.us.brands.length ? d.us.brands : (d.names.trade || [])).slice(0, 3).map((b) => b[0] + b.slice(1).toLowerCase());
  const shareUrl = await medicineUrl(d.id);
  const structureSource = d.structure ? [{ label: `Structure from ${d.structure.source}`, url: d.structure.source_url },
    ...(d.structure.pubchem_cid ? [{ label: `PubChem CID ${d.structure.pubchem_cid}`, url: `https://pubchem.ncbi.nlm.nih.gov/compound/${d.structure.pubchem_cid}` }] : [])]
    : d.sequence ? [{ label: `Sequence from ${d.sequence.source || "ChEMBL"}`, url: d.sequence.source_url }] : [];

  if (sub === "molecule") {
    const pic = await picture(d, true);
    const body = html`${pic.html}
      ${pic.m && pic.m.d3 ? html`<section class="x-panel"><h2>Turn it around</h2><div id="m3d"></div>
        <p class="muted">A computer-made 3D shape (RDKit). Real molecules wobble and bend; this is one likely pose, not a photograph.</p></section>` : ""}
      ${d.structure ? html`<details class="x-panel"><summary>The chemist's shorthand</summary><p class="mono wrap">${d.structure.smiles}</p>
        <p class="muted">This line of letters is called SMILES. A computer can rebuild the whole molecule from it.</p></details>` : ""}
      ${sourceLine(structureSource, (d.structure || d.sequence || {}).checked)}`;
    return { html: page({ level: "deep", trail: [...trail, ["The molecule"]], kicker: "Deep dive", title: `${d.name}: the molecule`, body,
        more: [{ title: "Chemist's view", text: "Properties, identifiers and cross-checks.", href: `#/ref/drug/${d.id}/structure` }] }),
      mount(root) { const el = root.querySelector("#m3d"); return el ? mount3D(el, pic.m.d3) : undefined; } };
  }

  if (sub === "works") {
    const b = d.binding, site = b ? await data.bindingSite(d.id) : null, m = d.mechanisms[0];
    const body = html`
      ${m ? html`<section class="x-panel"><h2>The idea</h2>${schematic(m, d.name)}<p>${mechanismPlain(m)}</p>${sourceLine(m.refs.map((r) => ({ label: `${r.type} via ChEMBL`, url: r.url })))}</section>` : ""}
      ${b ? html`<section class="x-panel"><h2>The real thing</h2>${b.related ? html`<p id="related-note"><b>A close stand-in.</b> Nobody has published a map of ${d.name} inside the ${b.organism === "Homo sapiens" ? "human" : "usual"} version of its target.
          This map shows it inside the matching protein from a different organism or virus strain (<i>${b.related.organism}</i>). The two come from the same gene, but small details can differ.</p>`
          : html`<p>Scientists froze ${d.name} inside its target and mapped where every atom sits. Watch it slide in and see what it touches.</p>`}
        <div id="bind"></div><p class="muted">Where ${d.name} ends up and what it touches come from a real experiment. The path it flies in on is our drawing.</p>
        ${/modified residues/.test(b.match || "") ? html`<p class="muted">The map matches ${d.name}'s chain of building blocks. Where the medicine carries extra chemical groups, the map may show a plain building block instead.</p>` : ""}
        ${sourceLine([{ label: `Protein Data Bank entry ${b.pdb_id.toUpperCase()}`, url: b.url }], b.checked)}</section>`
        : html`<p class="muted">We did not find a published 3D map of ${d.name} sitting in its target, so we only show the idea, not the real shapes.</p>`}
      ${!m && !b ? html`<p>Our sources do not describe how ${d.name} works.</p>` : ""}`;
    return { html: page({ level: "deep", trail: [...trail, ["How it works"]], kicker: "Deep dive", title: `Watch how ${d.name} works`, body,
        more: [{ title: "Scientist's view", text: "Every contact, with distances.", href: `#/ref/drug/${d.id}/binding` }] }),
      mount(root) { const el = root.querySelector("#bind"); return el ? mountBinding(el, site, b, { simple: true, drugName: d.name }) : undefined; } };
  }

  if (sub === "made") {
    const body = html`<section class="x-panel"><h2>${t.icon} ${t.simple_name === "Other" ? `What kind of medicine ${d.name} is` : `${d.name} is ${/^[aeiou]/i.test(t.simple_name) ? "an" : "a"} ${t.simple_name.toLowerCase()}`}</h2><p>${t.simple}</p>${sourceLine(t.sources)}</section>
      ${d.manufacturing && d.manufacturing.mentions.length ? html`<section class="x-panel"><h2>Clues for this one</h2><p>The factory notes that PubChem keeps for ${d.name} mention: <b>${d.manufacturing.mentions.join("; ")}</b>.</p>
        <p>${ext(d.manufacturing.url, "Read the notes (they are written for chemists)")}</p><p class="muted small">We matched keywords in the notes; we did not rewrite them. Checked ${d.manufacturing.checked}.</p></section>` : ""}
      ${d.peptide_note ? html`<section class="x-panel"><h2>How this one is built</h2><p>${d.peptide_note.chemistry}</p>${sourceLine([{ label: d.peptide_note.source, url: d.peptide_note.source_url }])}</section>` : ""}
      ${d.origin ? html`<section class="x-panel"><h2>Where ${d.name} comes from</h2><p class="who">${d.origin.category}</p><p>${d.origin.simple}</p>${sourceLine(d.origin.sources, d.origin.checked)}</section>` : ""}
      ${d.stories.map((s) => html`<section class="x-panel"><h2>${s.title}</h2>${s.who ? html`<p class="who">${s.who}</p>` : ""}<p>${s.simple}</p>${sourceLine([{ label: s.source, url: s.source_url }])}</section>`)}
      ${!d.stories.length && !d.origin ? html`<p class="muted">We have not written the discovery story of ${d.name} yet. The explanation above is about its whole family of medicines.</p>` : ""}`;
    return { html: page({ level: "deep", trail: [...trail, ["How it's made"]], kicker: "Deep dive", title: `How ${d.name} is made`, body,
      more: [{ title: "All the ways medicines are made", text: "Chemists, cells and machines.", href: "#/explore/made" }] }) };
  }

  const pic = await picture(d, false);
  const uses = d.label_note ? html`<p>${d.label_note.what_for}</p>${sourceLine([{ label: d.label_note.source, url: d.label_note.source_url }])}`
    : d.indications.length ? html`<p>Doctors' words for what it treats:</p><ul class="tags">${d.indications.slice(0, 6).map((i) => html`<li>${i.term}</li>`)}</ul>
        ${sourceLine(d.indications.slice(0, 1).flatMap((i) => i.refs.map((r) => ({ label: `${r.type} via ChEMBL`, url: r.url }))))}`
    : html`<p class="muted">Our sources do not list its uses.</p>`;
  const works = d.mechanisms.length ? html`${d.mechanisms.slice(0, 2).map((m) => html`<p>${mechanismPlain(m)}</p>`)}${sourceLine(d.mechanisms[0].refs.map((r) => ({ label: `${r.type} via ChEMBL`, url: r.url })))}`
    : d.label_note ? html`<p>${d.label_note.how}</p>${sourceLine([{ label: d.label_note.source, url: d.label_note.source_url }])}`
    : html`<p class="muted">Our sources do not describe how it works.</p>`;
  const body = html`
    ${pic.html}${sourceLine(structureSource, (d.structure || d.sequence || {}).checked)}
    <div class="x-two">
      <section class="x-panel"><h2>What it's for</h2>${uses}</section>
      <section class="x-panel"><h2>How it works</h2>${works}
        ${d.stem ? html`<p class="clue">🔤 Name clue: <b>${d.stem.stem}</b> means “${d.stem.meaning}”.</p>` : ""}</section>
    </div>
    ${timelineSimple(d)}
    ${d.who_eml ? html`<p class="clue">⭐ ${d.who_eml.listed_alone ? `${d.name} is on WHO's list of essential medicines: the medicines WHO says everyone should be able to get.` : `${d.name} is on WHO's list of essential medicines as part of a combination medicine.`} ${ext(d.who_eml.entries[0].url, "See WHO's entry")}</p>` : ""}
    ${d.see_also && d.see_also.length ? html`<p class="clue">🔎 Looking for a similar name? This site also has ${d.see_also.map((o, i) => html`${i ? ", " : ""}<a href="#/explore/medicine/${o.id}">${o.name}</a>`)}. Different records sometimes name the same medicine in different ways.</p>` : ""}
    ${d.flags.boxed_warning || d.flags.withdrawn ? html`<p class="careful">⚠️ ${d.flags.withdrawn ? "This medicine has been withdrawn in at least one country. " : ""}${d.flags.boxed_warning ? "In the US it carries the FDA's strongest warning. " : ""}Medicines are only safe when used the way a doctor or pharmacist says.</p>` : ""}
    ${sourceLine(d.sources)}
    ${sharePanel(d, shareUrl, { simple: true })}`;
  const more = [
    (d.graphics && d.graphics.drawing) || d.sequence ? { title: "🔬 The molecule up close", text: d.graphics && d.graphics.model3d ? "Bigger picture, and spin it in 3D." : "A closer look.", href: `#/explore/medicine/${d.id}/molecule` } : null,
    d.mechanisms.length || d.binding ? { title: "🎬 Watch how it works", text: d.binding ? "An animation built from a real experiment." : "A moving picture of the idea.", href: `#/explore/medicine/${d.id}/works` } : null,
    { title: `${t.icon} How it's made`, text: d.stories.length ? "Including its discovery story." : d.origin ? "Including where it comes from." : t.simple_name.toLowerCase() === "other" ? "How medicines like it are made." : `How ${/^[aeiou]/i.test(t.simple_name) ? "an" : "a"} ${t.simple_name.toLowerCase()} is made.`, href: `#/explore/medicine/${d.id}/made` },
    { title: "📚 The full record", text: "Every approval, name and number (In-depth).", href: `#/ref/drug/${d.id}` }];
  return { html: page({ trail, kicker: `${t.icon} ${t.simple_name}`, title: d.name, lede: brands.length ? `Also sold as ${brands.join(", ")}.` : null,
    keyFacts: [["First approved", d.first_year], ["On record in", approvedIn(d)], ["How it's taken", howTaken(d.flags)], ["US makers", d.us ? `${d.us.sponsors} compan${d.us.sponsors === 1 ? "y" : "ies"}` : null]],
    body, more }), mount(root) { mountShare(root, d, shareUrl); } };
}

function timelineSimple(d) {
  const rows = worldTimeline(d);
  if (rows.length < 2) return "";
  return html`<section class="x-panel"><h2>🌍 Around the world</h2><p>Where ${d.name} shows up first, in each place's own records:</p>
    <ol class="world-line">${rows.map((r) => html`<li><b>${r.date.slice(0, 4)}</b><span>${r.flag} ${r.place}</span><small>${r.simple}</small></li>`)}</ol>
    <p class="muted small">Each date comes from that place's own records, and they count different things: Canada's is when it first went on sale. Older medicines may have been approved before these records began; Japan's list starts in 2004.</p>
    ${sourceLine(rows.map((r) => ({ label: r.source, url: r.url })))}</section>`;
}

// ------------------------------------------------------------------------------------------------ stories, topics, how made
const STORY_GROUPS = [["stories", "Discovery stories"], ["safety", "When things went wrong"], ["world", "Around the world"], ["people", "People"], ["chemistry", "Names and families"]];

export async function stories() {
  const list = await data.topics();
  const body = STORY_GROUPS.map(([g, label]) => html`<section><h2>${label}</h2><div class="deeper-grid">${list.filter((t) => t.group === g).map((t) =>
    html`<a class="deep" href="#/explore/topic/${t.key}"><b>${t.title}</b><span>${t.intro}</span><i aria-hidden="true">→</i></a>`)}</div></section>`);
  return { html: page({ trail: [HOME, ["Stories"]], title: "Stories", lede: "Short reads. Every one links to where it came from.", body }) };
}

export async function topic(key, sub) {
  const t = (await data.topics()).find((x) => x.key === key);
  if (!t) throw new Error("No such topic");
  const rows = await data.topicRows(key);
  const all = sub === "all" || rows.length <= 8;
  const shown = all ? rows : rows.slice(0, 6);
  const linked = t.drug_field ? await Promise.all(shown.map((r) => data.findDrugByName(r[t.drug_field]))) : [];
  const body = html`${renderTopicSimulator(key, "explore")}<div class="x-list">${shown.map((r, i) => html`<section class="x-panel">
      <h2>${r[t.title_field]}</h2>${t.sub_fields.length ? html`<p class="who">${t.sub_fields.map((f) => r[f]).filter((v) => v != null && v !== "").join(" · ")}</p>` : ""}
      ${t.simple_field && r[t.simple_field] ? html`<p>${r[t.simple_field]}</p>` : ""}
      ${r.tiers ? html`<ol class="zoom">${Object.values(r.tiers).map((tier) => html`<li><b>${tier.scale.replace(/^Scale:\s*/, "").replace(/\s*\(.*$/, "")}.</b> ${tier.sp}</li>`)}</ol>` : ""}
      ${linked[i] ? html`<p><a href="#/explore/medicine/${linked[i].id}">See the ${linked[i].name} molecule →</a></p>` : ""}
      ${sourceLine([{ label: (t.source_field && r[t.source_field]) || "Source", url: r[t.url_field] }])}</section>`)}</div>`;
  const more = [!all ? { title: `See all ${rows.length}`, text: "The complete list.", href: `#/explore/topic/${key}/all` } : null,
    { title: "The expert table", text: "Every column, sortable (In-depth).", href: `#/ref/topic/${key}` }];
  return { html: page({ level: sub === "all" ? "deep" : "page", trail: [HOME, ["Stories", "#/explore/stories"], [t.title, `#/explore/topic/${key}`], ...(sub === "all" ? [["All"]] : [])],
    title: t.title, lede: t.intro, keyFacts: [["Entries", rows.length]], body, more }),
    mount(root) { mountTopicSimulator(root, key); } };
}

export async function made() {
  const [m, st] = await Promise.all([data.howMade(), data.stats()]);
  const codes = Object.fromEntries(Object.entries(data.TYPE_NAMES).map(([c, n]) => [n, c]));
  const body = Object.entries(m.types).filter(([name]) => st.by_type[name]).map(([name, t]) => html`<section class="x-panel">
    <h2>${t.icon} ${t.simple_name} <span class="muted">· ${num(st.by_type[name])} in the catalogue</span></h2><p>${t.simple}</p>
    <p><a href="#/explore/medicines?type=${codes[name]}">Browse the ${t.count_label} →</a></p>${sourceLine(t.sources)}</section>`);
  return { html: page({ trail: [HOME, ["How they're made"]], title: "How medicines are made", lede: "Some are built by chemists. Some are grown by living cells. Some are written like code.",
    body: html`${body}<p class="muted">${m.note}</p>`, more: [{ title: "🔤 Name decoder", text: "The name often tells you the kind.", href: "#/explore/topic/stems" }] }) };
}

// ------------------------------------------------------------------------------------------------ quiz
const BADGES = [[9, "Chief Scientist"], [7, "Medicine Detective"], [4, "Lab Apprentice"], [0, "Pill Rookie"]];

export async function quizPage() {
  const all = await data.quiz();
  return {
    html: page({ trail: [HOME, ["Quiz"]], title: "Medicine detective quiz", lede: "Ten questions. Every answer comes with its source.",
      body: html`<div id="quiz" class="x-panel" aria-live="polite"></div>` }),
    mount(root) {
      const box = root.querySelector("#quiz");
      const round = [...all].sort(() => Math.random() - 0.5).slice(0, 10);
      let i = 0, score = 0;
      const ask = () => {
        if (i >= round.length) {
          const badge = BADGES.find(([min]) => score >= min)[1];
          const best = Math.max(score, Number(store.get("quizBest") || 0)); store.set("quizBest", String(best));
          box.innerHTML = html`<h2>${score} out of ${round.length}</h2><p class="big-number">${badge}</p><p class="muted">Your best so far: ${best}. Scores stay on this device only.</p>
            <p><button class="btn" id="again" type="button">Play again</button></p>`;
          box.querySelector("#again").addEventListener("click", () => { location.reload(); });
          return;
        }
        const q = round[i];
        const order = q.answers.map((_, k) => k).sort(() => Math.random() - 0.5);      // the right answer is not always first
        box.innerHTML = html`<p class="kicker">Question ${i + 1} of ${round.length}</p><h2>${q.q}</h2>
          <div class="answers">${order.map((k) => html`<button type="button" class="answer" data-k="${k}">${q.answers[k]}</button>`)}</div><div id="why"></div>`;
        box.querySelectorAll(".answer").forEach((b) => b.addEventListener("click", () => {
          const right = Number(b.dataset.k) === q.right;
          if (right) score++;
          box.querySelectorAll(".answer").forEach((x) => { x.disabled = true; x.classList.toggle("right", Number(x.dataset.k) === q.right); });
          if (!right) b.classList.add("wrong");
          box.querySelector("#why").innerHTML = html`<p><b>${right ? "Yes!" : "Not quite."}</b> ${q.why}</p>${sourceLine([{ label: q.source, url: q.url }])}
            <p><button class="btn" id="next" type="button">${i + 1 < round.length ? "Next question" : "See my score"}</button></p>`;
          box.querySelector("#next").addEventListener("click", () => { i++; ask(); });
          box.querySelector("#next").focus();
        }));
      };
      ask();
    },
  };
}

export const roleOf = { "#/explore": "student", "#/explore/teach": "teacher", "#/explore/history": "history" };
export { ROLES };
