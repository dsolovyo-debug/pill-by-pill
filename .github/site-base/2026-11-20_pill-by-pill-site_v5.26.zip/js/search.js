// Type-ahead drug search used by both environments.
import { html, esc } from "./ui.js";
import { searchDrugs, TYPE_NAMES } from "./data.js";

/** Wire an input and a <ul> so that typing lists matches and choosing one opens hrefFor(drug). */
export function wireSearch(input, list, hrefFor) {
  let token = 0;
  const close = () => { list.hidden = true; list.innerHTML = ""; };
  input.addEventListener("input", async () => {
    const mine = ++token;
    const found = await searchDrugs(input.value, 8);
    if (mine !== token) return;                       // a newer keystroke won
    if (!found.length) { close(); return; }
    list.innerHTML = found.map((d) => `<li><a href="${esc(hrefFor(d))}"><b>${esc(d.name)}</b>` +
      `<span>${esc(d.via ? "also called " + d.via : d.brand || TYPE_NAMES[d.type] || "")}${d.year ? " · " + d.year : ""}</span></a></li>`).join("");
    list.hidden = false;
  });
  input.form?.addEventListener("submit", (e) => {
    e.preventDefault();
    const first = list.querySelector("a");
    if (first) location.hash = first.getAttribute("href");
  });
  list.addEventListener("click", close);
  input.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
}
