// Wording helpers that turn catalogue fields into sentences. No facts are added here: only phrasing.
import { html, ext, fmtDate, num } from "./ui.js";

export const ROUTES = { oral: "by mouth", parenteral: "by injection", topical: "on the skin or eyes" };

/** Plain-language meaning of ChEMBL's action types, for the Simple pages. */
const ACTION_WORDS = {
  INHIBITOR: "blocks or slows down", ANTAGONIST: "blocks the signal at", BLOCKER: "blocks", AGONIST: "switches on",
  "PARTIAL AGONIST": "partly switches on", "INVERSE AGONIST": "turns down", ACTIVATOR: "switches on", OPENER: "opens",
  "POSITIVE ALLOSTERIC MODULATOR": "turns up", "NEGATIVE ALLOSTERIC MODULATOR": "turns down", MODULATOR: "adjusts",
  "BINDING AGENT": "sticks to", "CROSS-LINKING AGENT": "ties together strands of", "DISRUPTING AGENT": "breaks up",
  "RELEASING AGENT": "releases", SUBSTRATE: "is used up by", "HYDROLYTIC ENZYME": "cuts up", "PROTEOLYTIC ENZYME": "cuts up",
  "ANTISENSE INHIBITOR": "silences the message for", "RNAI INHIBITOR": "silences the message for", STABILISER: "steadies",
  "CHELATING AGENT": "grabs hold of", "OXIDATIVE ENZYME": "breaks down", "SEQUESTERING AGENT": "soaks up", DEGRADER: "destroys",
  "VACCINE ANTIGEN": "trains the body to recognise", "EXOGENOUS PROTEIN": "replaces a missing protein:", "EXOGENOUS GENE": "delivers a working gene:",
};

/** "HMG-CoA reductase inhibitor" + INHIBITOR -> "It blocks or slows down HMG-CoA reductase." Falls back to quoting the source phrase. */
export function mechanismPlain(m) {
  const verb = ACTION_WORDS[m.action];
  const target = m.text.replace(/\s+(inhibitor|antagonist|blocker|agonist|partial agonist|inverse agonist|activator|opener|modulator|positive allosteric modulator|negative allosteric modulator|binding agent|stabiliser|degrader|substrate|releasing agent|cross-linking agent|disrupting agent|chelating agent|sequestering agent|antisense inhibitor|RNAi inhibitor|hydrolytic enzyme|proteolytic enzyme)$/i, "");
  if (verb && target !== m.text) return `It ${verb} ${target}.`;
  return `Scientists describe it as: ${m.text}.`;
}

export function howTaken(flags) {
  const ways = Object.keys(ROUTES).filter((k) => flags && flags[k]).map((k) => ROUTES[k]);
  return ways.length ? ways.join(", ") : null;
}

/** Where a medicine is recognised: only what the sources actually record. */
export function worldRows(d) {
  const rows = [];
  if (d.us) rows.push(["United States", html`${d.us.applications_total} application${d.us.applications_total === 1 ? "" : "s"} in Drugs@FDA${d.us.first_date ? html`, earliest dated ${fmtDate(d.us.first_date)}` : ""}`, ext(d.us.source_url, "FDA Drugs@FDA")]);
  else rows.push(["United States", "No application found in Drugs@FDA under this name", ""]);
  if (d.eu) rows.push(["European Union", html`${d.eu.status}: ${d.eu.products_total} product${d.eu.products_total === 1 ? "" : "s"} evaluated centrally by EMA${d.eu.first_authorised ? html`, first authorised ${fmtDate(d.eu.first_authorised)}` : ""}`, ext(d.eu.source_url, "EMA medicines table")]);
  else if (d.world && d.world.ema_epar.length) rows.push(["European Union", html`European public assessment report: ${d.world.ema_epar.map((e, i) => html`${i ? ", " : ""}${ext(e.url, e.name)}`)}`, "EMA via ChEMBL"]);
  else rows.push(["European Union", "Not in EMA's table of centrally evaluated medicines. It may still be licensed by individual EU countries, which that table does not cover.", ""]);
  if (d.ca) rows.push(["Canada", html`${d.ca.marketed_now ? `${d.ca.marketed_now} of ${d.ca.products_total} products marketed now` : `${d.ca.products_total} product${d.ca.products_total === 1 ? "" : "s"}, none marketed now (${d.ca.status})`}${d.ca.first_marketed ? `, first marketed ${d.ca.first_marketed_year_only ? "in " + d.ca.first_marketed : fmtDate(d.ca.first_marketed)}` : ""}`, ext(d.ca.source_url, "Health Canada Drug Product Database")]);
  else rows.push(["Canada", "No product found in Health Canada's Drug Product Database under this name", ""]);
  if (d.jp) rows.push(["Japan", d.jp.first_new_ingredient ? html`First approved as a new active ingredient ${fmtDate(d.jp.first_new_ingredient)}; ${d.jp.entries_total} entr${d.jp.entries_total === 1 ? "y" : "ies"} in PMDA's list`
      : html`${d.jp.entries_total} later approval${d.jp.entries_total === 1 ? "" : "s"} or change${d.jp.entries_total === 1 ? "" : "s"} since ${fmtDate(d.jp.first_listed)}; first approved in Japan before April 2004`, ext(d.jp.source_url, "edited from PMDA's list of approved drugs")]);
  else rows.push(["Japan", "Not in PMDA's list of new-drug approvals since April 2004 (older approvals and generics are not in that list)", ""]);
  const n = d.names || {};
  if (n.inn && n.inn.length) rows.push(["World Health Organization", `International Nonproprietary Name: ${n.inn.join(", ")}`, "ChEMBL"]);
  if (n.ban && n.ban.length) rows.push(["United Kingdom", `British Approved Name: ${n.ban.join(", ")}`, "ChEMBL"]);
  if (n.jan && n.jan.length) rows.push(["Japan", `Japanese Accepted Name: ${n.jan.join(", ")}`, "ChEMBL"]);
  if (n.usan && n.usan.length) rows.push(["United States (naming)", `United States Adopted Name: ${n.usan.join(", ")}`, "ChEMBL"]);
  return rows;
}

/** First dates by region, oldest first. Each says what kind of date it is: the four records do not measure the same thing. */
export function worldTimeline(d) {
  const rows = [];
  if (d.us && d.us.first_date) rows.push({ place: "United States", flag: "🇺🇸", date: d.us.first_date, kind: "earliest approval in FDA's records", simple: "approved", url: d.us.source_url, source: "FDA Drugs@FDA" });
  if (d.eu && d.eu.first_authorised) rows.push({ place: "European Union", flag: "🇪🇺", date: d.eu.first_authorised, kind: "first authorised through EMA (central procedure)", simple: "approved", url: d.eu.products[0][8] || d.eu.source_url, source: "EMA" });
  if (d.jp && d.jp.first_new_ingredient) rows.push({ place: "Japan", flag: "🇯🇵", date: d.jp.first_new_ingredient, kind: "approved as a new active ingredient", simple: "approved", url: d.jp.source_url, source: "edited from PMDA's list" });
  if (d.ca && d.ca.first_marketed) rows.push({ place: "Canada", flag: "🇨🇦", date: d.ca.first_marketed, yearOnly: d.ca.first_marketed_year_only, kind: "first marketed (not the approval date)", simple: "first on sale", url: (d.ca.products.find((p) => p[3] && d.ca.first_marketed.startsWith(p[3].slice(0, 4))) || d.ca.products[0])[6], source: "Health Canada" });
  return rows.sort((a, b) => a.date.localeCompare(b.date));
}

/** "US, EU" style summary for the Simple page: only places a record actually shows. */
export function approvedIn(d) {
  const places = [];
  if (d.us && d.us.status !== "Tentative approval") places.push("United States");
  if (d.eu && d.eu.authorised_now) places.push("European Union");
  if (d.ca && d.ca.marketed_now) places.push("Canada");
  if (d.jp) places.push("Japan");
  return places.length > 1 ? places.slice(0, -1).join(", ") + " and " + places.at(-1) : places[0] || null;
}

export const firstYearText = (d) => d.first_year ? String(d.first_year) : "not recorded";

export function usSummary(us) {
  if (!us) return "Not found in the US FDA's Drugs@FDA list";
  const c = us.counts, parts = [];
  if (c.NDA) parts.push(`${num(c.NDA)} brand application${c.NDA === 1 ? "" : "s"} (NDA)`);
  if (c.BLA) parts.push(`${num(c.BLA)} biologic application${c.BLA === 1 ? "" : "s"} (BLA)`);
  if (c.ANDA) parts.push(`${num(c.ANDA)} generic${c.ANDA === 1 ? "" : "s"} (ANDA)`);
  return parts.join(", ");
}
