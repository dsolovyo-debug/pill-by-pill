// Molecule graphics drawn in the browser from mol/<id>.json (layouts computed by RDKit in the build pipeline).
//   draw2D(d2)            skeletal drawing as an SVG string
//   mount3D(el, d3)       drag-to-rotate ball-and-stick model on a canvas (no WebGL, no library)
//   sequenceView(seq)     residue view for peptides, proteins and oligonucleotides
import { html, raw, esc } from "./ui.js";

const ELEMENT_COLOURS = { O: "#d6336c", N: "#3b5bdb", S: "#b7791f", P: "#d9480f", F: "#2b8a3e", Cl: "#2b8a3e", Br: "#a61e4d", I: "#6741d9",
  H: "#adb5bd", C: "#495057" };
const colourOf = (el) => ELEMENT_COLOURS[el] || "#0c8599";
const SUB = { 2: "₂", 3: "₃", 4: "₄" };

/** Skeletal 2D drawing. Carbons are unlabelled corners; other atoms are labelled with their hydrogens and charge. */
export function draw2D(d2, { maxWidth = 460, maxHeight = 340, title = "" } = {}) {
  const xs = d2.atoms.map((a) => a[0]), ys = d2.atoms.map((a) => a[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const pad = 22;
  const scale = Math.min(30, (maxWidth - 2 * pad) / Math.max(maxX - minX, 1), (maxHeight - 2 * pad) / Math.max(maxY - minY, 1));
  const W = Math.round((maxX - minX) * scale + 2 * pad), H = Math.round((maxY - minY) * scale + 2 * pad);
  const pt = (a) => [(a[0] - minX) * scale + pad, (maxY - a[1]) * scale + pad];
  const degree = d2.atoms.map(() => 0);
  d2.bonds.forEach(([a, b]) => { degree[a]++; degree[b]++; });
  const labelled = d2.atoms.map((a, i) => a[2] !== "C" || a[3] !== 0 || degree[i] === 0);
  const font = Math.max(9, Math.min(15, scale * 0.5));
  const gap = font * 0.62;
  const f = (n) => n.toFixed(1);
  let out = "";
  for (const [ia, ib, order, wedge] of d2.bonds) {
    let [x1, y1] = pt(d2.atoms[ia]), [x2, y2] = pt(d2.atoms[ib]);
    const len = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / len, uy = (y2 - y1) / len;
    if (labelled[ia]) { x1 += ux * gap; y1 += uy * gap; }
    if (labelled[ib]) { x2 -= ux * gap; y2 -= uy * gap; }
    const nx = -uy, ny = ux;
    if (wedge === 1) {
      const w = Math.max(2.2, scale * 0.09);
      out += `<polygon class="wedge" points="${f(x1)},${f(y1)} ${f(x2 + nx * w)},${f(y2 + ny * w)} ${f(x2 - nx * w)},${f(y2 - ny * w)}"/>`;
    } else if (wedge === 2) {
      const steps = 6, w = Math.max(2.2, scale * 0.09);
      for (let k = 1; k <= steps; k++) {
        const t = k / steps, cx = x1 + (x2 - x1) * t, cy = y1 + (y2 - y1) * t, h = w * t;
        out += `<line x1="${f(cx + nx * h)}" y1="${f(cy + ny * h)}" x2="${f(cx - nx * h)}" y2="${f(cy - ny * h)}"/>`;
      }
    } else if (order === 1) {
      out += `<line x1="${f(x1)}" y1="${f(y1)}" x2="${f(x2)}" y2="${f(y2)}"/>`;
    } else {
      const o = Math.max(1.6, scale * 0.075);
      const offsets = order === 2 ? [-o, o] : [-1.8 * o, 0, 1.8 * o];
      for (const k of offsets) out += `<line x1="${f(x1 + nx * k)}" y1="${f(y1 + ny * k)}" x2="${f(x2 + nx * k)}" y2="${f(y2 + ny * k)}"/>`;
    }
  }
  d2.atoms.forEach((a, i) => {
    if (!labelled[i]) return;
    const [x, y] = pt(a);
    const [, , el, charge, h] = a;
    // put the hydrogens on the side away from the bonds
    let neighbourX = 0;
    d2.bonds.forEach(([p, q]) => { if (p === i) neighbourX += d2.atoms[q][0] - a[0]; if (q === i) neighbourX += d2.atoms[p][0] - a[0]; });
    const hText = h ? "H" + (SUB[h] || (h > 1 ? h : "")) : "";
    const chargeText = charge ? (Math.abs(charge) > 1 ? Math.abs(charge) : "") + (charge > 0 ? "+" : "−") : "";
    const hLeft = neighbourX > 0.1 && h;
    const label = hLeft ? hText + el : el + hText;
    const anchor = hLeft ? "end" : (h ? "start" : "middle");
    const dx = hLeft ? font * 0.36 * el.length : (h ? -font * 0.36 * el.length : 0);
    out += `<text x="${f(x + dx)}" y="${f(y + font * 0.36)}" text-anchor="${anchor}" font-size="${f(font)}" fill="${colourOf(el)}">${esc(label)}` +
      (chargeText ? `<tspan dy="${f(-font * 0.4)}" font-size="${f(font * 0.75)}">${chargeText}</tspan>` : "") + `</text>`;
  });
  return raw(`<svg class="mol2d" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${esc(title || "Molecule structure")}">${out}</svg>`);
}

/** Count atoms by element from a 2D layout (heavy atoms plus their hydrogens). */
export function atomCounts(d2) {
  const counts = {};
  for (const [, , el, , h] of d2.atoms) {
    counts[el] = (counts[el] || 0) + 1;
    if (h) counts.H = (counts.H || 0) + h;
  }
  return counts;
}

const RADII = { H: 0.26, C: 0.4, N: 0.4, O: 0.4, S: 0.5, P: 0.5, F: 0.36, Cl: 0.48, Br: 0.52, I: 0.58 };

/** Interactive 3D model. Returns a function that stops the animation. */
export function mount3D(container, d3) {
  container.innerHTML = `<canvas class="mol3d" width="560" height="400" tabindex="0" aria-label="3D model. Drag to rotate."></canvas>
    <div class="mol3d-bar"><button type="button" data-act="spin" aria-pressed="true">Spin</button>
    <button type="button" data-act="h" aria-pressed="true">Hydrogens</button>
    <span class="hint">Drag to turn. Arrow keys work too.</span></div>`;
  const canvas = container.querySelector("canvas"), ctx = canvas.getContext("2d");
  const n = d3.atoms.length;
  const centre = [1, 2, 3].map((k) => d3.atoms.reduce((s, a) => s + a[k], 0) / n);
  const atoms = d3.atoms.map((a) => ({ el: a[0], p: [a[1] - centre[0], a[2] - centre[1], a[3] - centre[2]] }));
  const reach = Math.max(...atoms.map((a) => Math.hypot(...a.p))) + 1;
  let yaw = 0.6, pitch = -0.3, spinning = !matchMedia("(prefers-reduced-motion: reduce)").matches, showH = true, frame = 0, dragging = null;

  function drawFrame() {
    const W = canvas.width, H = canvas.height, s = Math.min(W, H) / (2 * reach);
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const proj = atoms.map(({ p: [x, y, z] }) => {
      const x1 = x * cy + z * sy, z1 = -x * sy + z * cy;
      const y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
      const persp = 1 + z2 / (reach * 6);
      return [W / 2 + x1 * s * persp, H / 2 - y1 * s * persp, z2, persp];
    });
    const items = [];
    atoms.forEach((a, i) => { if (showH || a.el !== "H") items.push({ z: proj[i][2], atom: i }); });
    d3.bonds.forEach(([a, b]) => {
      if (!showH && (atoms[a].el === "H" || atoms[b].el === "H")) return;
      items.push({ z: (proj[a][2] + proj[b][2]) / 2 - 0.01, bond: [a, b] });
    });
    items.sort((p, q) => p.z - q.z);
    ctx.clearRect(0, 0, W, H);
    for (const it of items) {
      if (it.bond) {
        const [a, b] = it.bond;
        ctx.strokeStyle = "#868e96"; ctx.lineWidth = Math.max(2, s * 0.14); ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(proj[a][0], proj[a][1]); ctx.lineTo(proj[b][0], proj[b][1]); ctx.stroke();
      } else {
        const a = atoms[it.atom], [x, y, , persp] = proj[it.atom];
        const r = (RADII[a.el] || 0.45) * s * 0.8 * persp;
        const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
        g.addColorStop(0, "#ffffff"); g.addColorStop(0.35, colourOf(a.el)); g.addColorStop(1, colourOf(a.el));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      }
    }
  }
  function loop() { if (spinning && !dragging) yaw += 0.012; drawFrame(); frame = requestAnimationFrame(loop); }
  canvas.addEventListener("pointerdown", (e) => { dragging = [e.clientX, e.clientY]; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    yaw += (e.clientX - dragging[0]) * 0.012; pitch += (e.clientY - dragging[1]) * 0.012;
    dragging = [e.clientX, e.clientY];
  });
  canvas.addEventListener("pointerup", () => { dragging = null; });
  canvas.addEventListener("keydown", (e) => {
    const step = { ArrowLeft: [-0.15, 0], ArrowRight: [0.15, 0], ArrowUp: [0, -0.15], ArrowDown: [0, 0.15] }[e.key];
    if (step) { e.preventDefault(); yaw += step[0]; pitch += step[1]; spinning = false; sync(); }
  });
  const sync = () => {
    container.querySelector('[data-act="spin"]').setAttribute("aria-pressed", String(spinning));
    container.querySelector('[data-act="h"]').setAttribute("aria-pressed", String(showH));
  };
  container.querySelector(".mol3d-bar").addEventListener("click", (e) => {
    const act = e.target.dataset.act;
    if (act === "spin") spinning = !spinning;
    if (act === "h") showH = !showH;
    sync();
  });
  sync(); loop();
  return () => cancelAnimationFrame(frame);
}

const AMINO = { A: "Ala", R: "Arg", N: "Asn", D: "Asp", C: "Cys", Q: "Gln", E: "Glu", G: "Gly", H: "His", I: "Ile", L: "Leu", K: "Lys", M: "Met",
  F: "Phe", P: "Pro", S: "Ser", T: "Thr", W: "Trp", Y: "Tyr", V: "Val" };
const AMINO_GROUP = { A: "np", V: "np", L: "np", I: "np", M: "np", F: "np", W: "np", P: "np", G: "np", S: "po", T: "po", C: "po", Y: "po", N: "po", Q: "po",
  D: "ac", E: "ac", K: "ba", R: "ba", H: "ba" };

/** Sequence view: residue chips for short chains, grouped text for long ones. Shows the sequence exactly as the source records it. */
export function sequenceView(sequence, { simple = false } = {}) {
  const parts = (sequence.components || []).map((c, i) => {
    const seq = c.sequence || "";
    const isNucleic = ["Nucleic Acid", "RNA", "DNA"].includes(c.type);
    if (c.residues) {      // a peptide with modified residues: every residue shown under its own name
      return html`<div class="seq"><h4>Chain ${i + 1} <span class="muted">· ${c.residues.length} residues</span></h4><div class="chips" role="list">${c.residues.map((r, k) =>
        html`<span role="listitem" class="res ${r.length === 1 ? AMINO_GROUP[r] || "" : "mod"}" title="${k + 1}: ${r.length === 1 ? AMINO[r] || r : r + " (modified residue)"}">${r.length === 1 && simple ? AMINO[r] || r : r}</span>`)}</div>
        <p class="muted small">${c.note}.</p></div>`;
    }
    if (isNucleic && seq.length > 150) {
      const groups = seq.match(/.{1,10}/g) || [];
      return html`<div class="seq"><h4>Strand ${i + 1} <span class="muted">· ${seq.length} positions</span></h4><p class="mono">${groups.slice(0, 8).join(" ")} …</p>
        <details><summary>Show all ${seq.length} positions</summary><p class="mono wrap">${groups.join(" ")}</p></details></div>`;
    }
    const plainProtein = /^[A-Z]+$/.test(seq) && !isNucleic;
    const heading = html`<h4>${isNucleic ? "Strand" : "Chain"} ${i + 1}${plainProtein ? html` <span class="muted">· ${seq.length} amino acids</span>` : isNucleic ? html` <span class="muted">· ${seq.length} positions</span>` : ""}</h4>`;
    if (plainProtein && seq.length <= 60) {
      const mods = new Set(c.modified_sites || []);          // 1-based positions FDA's registry lists as modified
      return html`<div class="seq">${heading}<div class="chips" role="list">${[...seq].map((ch, k) =>
        html`<span role="listitem" class="res ${mods.has(k + 1) ? "mod" : AMINO_GROUP[ch] || ""}" title="${k + 1}: ${AMINO[ch] || ch}${mods.has(k + 1) ? " (modified at this position)" : ""}">${simple ? AMINO[ch] || ch : ch}</span>`)}</div>
        ${mods.size ? html`<p class="muted small">Outlined positions (${[...mods].join(", ")}) carry a modification${sequence.modifications ? html`: ${sequence.modifications}` : ""}.</p>` : ""}
        ${sequence.differs_from_chembl && i === 0 ? html`<p class="muted small">This is the sequence in FDA's substance registry. ChEMBL's letter string for this medicine differs from it.</p>` : ""}</div>`;
    }
    if (plainProtein) {
      const groups = seq.match(/.{1,10}/g) || [];
      return html`<div class="seq">${heading}<p class="mono">${groups.slice(0, 6).join(" ")}${groups.length > 6 ? " …" : ""}</p>
        ${groups.length > 6 ? html`<details><summary>Show all ${seq.length} amino acids</summary><p class="mono wrap">${groups.join(" ")}</p></details>` : ""}</div>`;
    }
    const rawTokens = seq.replace(/[()]/g, " ").split(/[-\s]+/).filter(Boolean);
    const tokens = (rawTokens.length === 1 && /^[dACGTU]+$/i.test(rawTokens[0])) ? (rawTokens[0].match(/d?[ACGTU]/gi) || [...rawTokens[0]]) : rawTokens;
    return html`<div class="seq">${heading}<div class="chips" role="list">${tokens.map((t, k) =>
      html`<span role="listitem" class="res nt nt-${(t.match(/[ACGTU]$/i) || ["x"])[0].toUpperCase()}" title="Position ${k + 1} (5'→3')">${t}</span>`)}</div>
      <p class="muted small">Shown as recorded in ${sequence.source || "ChEMBL"}.</p></div>`;
  });
  const legend = html`<p class="legend small"><span class="res np">oily</span> <span class="res po">water-loving</span> <span class="res ac">acidic</span> <span class="res ba">basic</span></p>`;
  return html`${parts}${(sequence.components || []).some((c) => !["Nucleic Acid", "RNA", "DNA"].includes(c.type) && (c.residues || (/^[A-Z]+$/.test(c.sequence || "") && c.sequence.length <= 60))) ? legend : ""}
    ${sequence.chemistry && sequence.chemistry.as_named ? html`<p class="small">FDA's registry lists this as a chemical substance, not as a nucleic acid, so it has no modification codes. Its systematic name, word for word:
      <span class="mono wrap">${sequence.chemistry.as_named}</span></p>` : ""}
    ${sequence.chemistry && !sequence.chemistry.as_named ? html`<p class="small">Modification codes as recorded in GSRS. Sugars: <span class="mono">${sequence.chemistry.sugars || "none recorded"}</span>. Linkages: <span class="mono">${sequence.chemistry.linkages || "none recorded"}</span>.
      An X or N in a strand marks a position that is not a standard nucleotide, such as where a ligand is attached.</p>` : ""}
    ${sequence.helm ? html`<details><summary>HELM notation</summary><p class="mono wrap">${sequence.helm}</p></details>` : ""}`;
}
