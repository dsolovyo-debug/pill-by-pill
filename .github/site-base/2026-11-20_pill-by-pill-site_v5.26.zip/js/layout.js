// The page hierarchy every page follows, in both environments:
//   home  ->  path landing (one per kind of visitor)  ->  topic or medicine page  ->  deep-dive
// page() renders one page in that shape: breadcrumb, title, key facts above the fold, short body, deep-dive links.
import { html } from "./ui.js";

export const ROLES = {
  student:   { env: "explore", path: "#/explore",           name: "Student",                icon: "🎒", line: "Stories, molecules to spin and a quiz." },
  teacher:   { env: "explore", path: "#/explore/teach",     name: "Parent or teacher",      icon: "🍎", line: "Lesson-ready pages and classroom material." },
  history:   { env: "explore", path: "#/explore/history",   name: "History buff",           icon: "🏺", line: "From willow bark to gene editing, decade by decade." },
  clinician: { env: "ref",     path: "#/ref/clinician",     name: "Clinician or pharmacist", icon: "🩺", line: "Labels, interactions, warnings and withdrawals." },
  chemist:   { env: "ref",     path: "#/ref/chemist",       name: "Chemist or researcher",  icon: "🧪", line: "Structures, properties, mechanisms and modalities." },
  industry:  { env: "ref",     path: "#/ref/industry",      name: "Industry and regulatory", icon: "🏛️", line: "Approvals, agencies, pipelines and markets." },
};

export function crumbs(items) {
  return html`<nav class="crumbs" aria-label="You are here"><ol>${items.map(([label, href], i) =>
    html`<li>${href && i < items.length - 1 ? html`<a href="${href}">${label}</a>` : html`<span aria-current="page">${label}</span>`}</li>`)}</ol></nav>`;
}

export function facts(items) {
  const shown = items.filter((f) => f && f[1] != null && f[1] !== "");
  return shown.length ? html`<dl class="facts">${shown.map(([k, v]) => html`<div><dt>${k}</dt><dd>${v}</dd></div>`)}</dl>` : html``;
}

export function deeper(items, heading = "Go deeper") {
  const shown = items.filter(Boolean);
  return shown.length ? html`<section class="deeper" aria-label="${heading}"><h2>${heading}</h2><div class="deeper-grid">${shown.map((d) =>
    html`<a class="deep" href="${d.href}"${d.external ? html` target="_blank" rel="noopener"` : ""}><b>${d.title}</b><span>${d.text}</span><i aria-hidden="true">→</i></a>`)}</div></section>` : html``;
}

/** One page. level is "home", "landing", "page" or "deep" and only affects styling and the tests. */
export function page({ level = "page", trail = [], kicker, title, lede, keyFacts = [], body, more = [], moreHeading, money }) {
  return html`<article class="page level-${level}" data-level="${level}">
    ${trail.length ? crumbs(trail) : ""}
    <header class="page-head">${kicker ? html`<p class="kicker">${kicker}</p>` : ""}<h1>${title}</h1>${lede ? html`<p class="lede">${lede}</p>` : ""}${facts(keyFacts)}</header>
    <div class="page-body">${body}</div>
    ${deeper(more, moreHeading)}
    ${money || ""}
  </article>`;
}

const EXPLORE_NAV = [["#/explore", "Home", "🏠"], ["#/explore/stories", "Stories", "📖"], ["#/explore/medicines", "Medicines", "💊"],
  ["#/explore/made", "How they're made", "⚗️"], ["#/explore/quiz", "Quiz", "🏆"]];
const REF_NAV = [["#/ref", "Overview"], ["#/ref/drugs", "Drug catalogue"], ["#/ref/families", "Medicine families"], ["#/ref/compare", "Compare"], ["#/ref/topics", "Data sets"], ["#/ref/data", "Sources and method"]];

/** Simple environment: big friendly header, bottom bar on phones. */
export function exploreShell(content, current) {
  return html`<div class="shell shell-explore">
    <header class="x-top"><a class="logo" href="#/">Pill <span>by</span> Pill</a>
      <nav class="x-nav" aria-label="Explore">${EXPLORE_NAV.map(([href, label, icon]) =>
        html`<a href="${href}"${current === href ? html` aria-current="page"` : ""}><span aria-hidden="true">${icon}</span> ${label}</a>`)}</nav>
      <a class="door" href="#/ref" title="The reference side, for experts">In-depth →</a></header>
    <main id="main" tabindex="-1">${content}</main>
    <footer class="foot"><p>Pill by Pill is for learning. It does not give medical advice: ask a doctor or pharmacist about your own medicines.</p>
      <p><a href="#/ref/data">Where the facts come from</a> · <a href="#/fund">How this site is funded</a> · <a href="#/privacy">Privacy</a> · <a href="#/share">Share Pill by Pill</a> · <a href="#/">Choose a different path</a></p></footer>
  </div>`;
}

/** In-depth environment: dense top bar with search, side navigation. */
export function refShell(content, current, role) {
  return html`<div class="shell shell-ref">
    <header class="r-top"><a class="logo" href="#/">Pill by Pill <span>Reference</span></a>
      <form class="r-search" role="search" autocomplete="off"><label class="sr" for="r-q">Find a drug</label>
        <input id="r-q" type="search" placeholder="Find a drug: name, brand, code…" aria-controls="r-suggest"><ul id="r-suggest" class="suggest" hidden></ul></form>
      <nav class="r-roles" aria-label="Path">${["clinician", "chemist", "industry"].map((r) =>
        html`<a href="${ROLES[r].path}"${role === r ? html` aria-current="true"` : ""}>${ROLES[r].name}</a>`)}</nav>
      <a class="door" href="#/explore">← Simple</a></header>
    <div class="r-frame"><nav class="r-side" aria-label="Reference">${REF_NAV.map(([href, label]) =>
        html`<a href="${href}"${current === href ? html` aria-current="page"` : ""}>${label}</a>`)}<a href="#/fund">Funding</a></nav>
      <main id="main" tabindex="-1">${content}</main></div>
    <footer class="foot"><p>Reference data for education. Not medical advice and not a substitute for the current label.
      <a href="#/ref/data">Sources, licences and coverage</a> · <a href="#/privacy">Privacy</a> · <a href="#/share">Share Pill by Pill</a></p></footer>
  </div>`;
}
