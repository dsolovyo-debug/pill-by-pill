// "How the drug meets its target" graphics.
//   mountBinding(el, site, info, opts)   looping animation of an experimental binding site (bind/<id>.json from the pipeline):
//                                        the drug moves into the pocket and the measured contacts appear one by one.
//                                        The final pose and the contacts are from the deposited structure; the fly-in path is illustration.
//   schematic(mechanism, drugName)       symbolic animation for any drug with a ChEMBL mechanism (no real shapes).
import { html, raw, esc } from "./ui.js";

const CPK = { O: "#e03131", N: "#3b5bdb", S: "#e8a500", P: "#e8590c", F: "#2f9e44", CL: "#2f9e44", BR: "#a61e4d", I: "#6741d9", ZN: "#7048e8", MG: "#7048e8", FE: "#c94a1a", MN: "#7048e8", CA: "#7048e8" };
const KIND = { polar: { colour: "#1c7ed6", dash: [5, 4], word: "polar contact", simple: "a spot where they pull on each other" },
  nonpolar: { colour: "#e8590c", dash: [1.5, 4], word: "non-polar contact", simple: "a spot where they fit snugly" },
  metal: { colour: "#7048e8", dash: [], word: "metal contact", simple: "a spot where it grips a metal atom" },
  covalent: { colour: "#c92a2a", dash: [], word: "covalent bond", simple: "the spot where it is chemically joined to the protein" } };
const LOOP_SECONDS = 16;
const ease = (t) => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));

export function mountBinding(container, site, info, { simple = false, drugName = "The drug" } = {}) {
  container.innerHTML = `<canvas class="bind3d" width="680" height="460" tabindex="0" aria-label="Animation: ${esc(drugName)} entering its binding pocket. Drag to rotate."></canvas>
    <p class="bind-caption" aria-live="off"></p>
    <div class="mol3d-bar"><button type="button" data-act="play" aria-pressed="true">Play</button><button type="button" data-act="restart">Restart</button>
      <button type="button" data-act="end">Show all contacts</button><button type="button" data-act="save" hidden>Save as video</button>
      <span class="hint">${site.covalent ? `<i class="key covalent"></i> covalent bond ` : ""}<i class="key polar"></i> polar <i class="key nonpolar"></i> non-polar <i class="key metal"></i> metal · drag to turn</span></div>`;
  const canvas = container.querySelector("canvas"), ctx = canvas.getContext("2d"), caption = container.querySelector(".bind-caption");
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const all = [...site.residues.flatMap((r) => r.atoms), ...site.ligand.atoms];
  const isProtein = site.kind === "protein";                       // antibody or protein medicine: "ligand" is its interface residues
  let recording = null;
  const reach = Math.max(...all.map((a) => Math.hypot(a[1], a[2], a[3])), 6) + 1.5;
  const n = site.contacts.length;
  let yaw = 0.5, pitch = -0.25, playing = !reduced, progress = reduced ? 1 : 0, last = performance.now(), frame = 0, drag = null;

  function project(x, y, z, W, H, s) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const x1 = x * cy + z * sy, z1 = -x * sy + z * cy, y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
    const k = 1 + z2 / (reach * 6);
    return [W / 2 + x1 * s * k, H / 2 - y1 * s * k, z2, k];
  }

  function placeLabel(placed, labelText, ax, ay, W, H, preferUp = true) {
    const w = Math.ceil(ctx.measureText(labelText).width) + 8;
    const half = w / 2;
    const lx = Math.max(half + 6, Math.min(W - half - 6, ax));
    const base = preferUp ? ay - 8 : ay + 14;
    const offsets = [0, -15, 15, -30, 30, -45, 45, -60, 60, -75, 75];
    let ly = Math.max(16, Math.min(H - 22, base));
    for (const dy of offsets) {
      const cand = Math.max(16, Math.min(H - 22, base + (preferUp ? dy : -dy)));
      if (!placed.some(([px, py, pw]) => Math.abs(lx - px) < (w + pw) / 2 && Math.abs(cand - py) < 14)) {
        ly = cand;
        break;
      }
    }
    placed.push([lx, ly, w]);
    return [lx, ly];
  }

  function draw() {
    const W = canvas.width, H = canvas.height, s = Math.min(W, H) / (2 * reach);
    const arrive = ease((progress - 0.10) / 0.28);                    // 0 = far outside, 1 = in its deposited position
    const off = site.approach.map((c) => c * 22 * (1 - arrive));
    const shown = progress < 0.42 ? 0 : Math.min(n, Math.floor((progress - 0.42) / (0.44 / Math.max(n, 1))) + 1);
    const items = [];
    site.residues.forEach((r, ri) => {
      const active = site.contacts.slice(0, shown).some((c) => c[1] === ri);
      const P = r.atoms.map((a) => project(a[1], a[2], a[3], W, H, s));
      r.bonds.forEach(([i, j]) => items.push({ z: (P[i][2] + P[j][2]) / 2, line: [P[i], P[j]], colour: active ? "#748ffc" : "#c5cbe0", width: 3 }));
      r.atoms.forEach((a, i) => { if (a[0] !== "C") items.push({ z: P[i][2] + 0.01, dot: P[i], colour: CPK[a[0].toUpperCase()] || "#868e96", r: 0.22, alpha: active ? 1 : 0.45 }); });
      r._label = { at: P[r.anchor], active };
    });
    const L = site.ligand.atoms.map((a) => project(a[1] + off[0], a[2] + off[1], a[3] + off[2], W, H, s));
    site.ligand.bonds.forEach(([i, j]) => items.push({ z: (L[i][2] + L[j][2]) / 2, line: [L[i], L[j]], colour: "#f08c00", width: 5 }));
    site.ligand.atoms.forEach((a, i) => items.push({ z: L[i][2] + 0.01, dot: L[i], colour: a[0] === "C" ? "#f59f00" : CPK[a[0].toUpperCase()] || "#0c8599", r: 0.34, alpha: 1 }));
    items.sort((p, q) => p.z - q.z);
    ctx.clearRect(0, 0, W, H);
    if (recording) { ctx.fillStyle = "#f3f5fa"; ctx.fillRect(0, 0, W, H); }       // a saved video needs its own background
    for (const it of items) {
      if (it.line) { ctx.globalAlpha = 1; ctx.strokeStyle = it.colour; ctx.lineWidth = it.width; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(it.line[0][0], it.line[0][1]); ctx.lineTo(it.line[1][0], it.line[1][1]); ctx.stroke(); }
      else { ctx.globalAlpha = it.alpha; ctx.fillStyle = it.colour; ctx.beginPath(); ctx.arc(it.dot[0], it.dot[1], it.r * s * it.dot[3], 0, 7); ctx.fill(); }
    }
    ctx.globalAlpha = 1;
    site.contacts.slice(0, shown).forEach(([li, ri, ai, kind], k) => {
      const a = L[li], r = site.residues[ri], p = project(r.atoms[ai][1], r.atoms[ai][2], r.atoms[ai][3], W, H, s);
      ctx.strokeStyle = KIND[kind].colour; ctx.lineWidth = k === shown - 1 && progress < 0.88 ? 4 : 2.5; ctx.setLineDash(KIND[kind].dash);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(p[0], p[1]); ctx.stroke(); ctx.setLineDash([]);
    });
    ctx.font = "700 13px 'Atkinson Hyperlegible', system-ui, sans-serif"; ctx.textAlign = "center";
    const placed = [];
    const crowded = isProtein && (site.residues.length + site.ligand.labels.length > 16);
    // Place active target residues first so their labels stay closest to their anchors
    [...site.residues].sort((a, b) => (b._label.active - a._label.active) || (a._label.at[1] - b._label.at[1])).forEach((r) => {
      if (crowded && shown > 0 && progress < 0.88 && !r._label.active) return;
      const [lx, ly] = placeLabel(placed, r.label, r._label.at[0], r._label.at[1], W, H, false);
      ctx.fillStyle = r._label.active ? "#1b2440" : "#8a93ab";
      ctx.fillText(r.label, lx, ly);
    });
    if (isProtein) {                                                       // name the medicine's own residues too
      const activeGroups = new Set(site.contacts.slice(0, shown).map(([li]) => site.ligand.owner[li]));
      ctx.fillStyle = "#b35c00";
      site.ligand.labels.forEach((name, g) => {
        if (crowded && shown > 0 && progress < 0.88 && !activeGroups.has(g)) return;
        const pts = L.filter((_, i) => site.ligand.owner[i] === g);
        if (!pts.length) return;
        const ax = pts.reduce((s, p) => s + p[0], 0) / pts.length;
        const ay = Math.min(...pts.map((p) => p[1]));
        const [lx, ly] = placeLabel(placed, name, ax, ay, W, H, true);
        ctx.fillText(name, lx, ly);
      });
    }
    const line = text(shown, arrive);
    caption.textContent = line;
    if (recording) { ctx.fillStyle = "#1b2440"; ctx.textAlign = "left"; ctx.fillText(line.slice(0, 96), 14, H - 14); ctx.textAlign = "center"; }
  }

  function text(shown, arrive) {
    const shownTarget = info.related ? `${info.related.protein} (${info.related.organism}; stand-in for ${info.target})` : info.target;
    if (progress < 0.10) return isProtein ? (simple ? `This is the patch of ${shownTarget} that ${drugName} grabs. Each labelled cluster is one building block.` : `Interface on ${shownTarget}: ${site.residues.length} target residues contacted by ${site.ligand.labels.length} residues of ${drugName}.`)
      : simple ? `This is a pocket in ${shownTarget}. Each labelled cluster is one of its building blocks.` : `Binding site in ${shownTarget}: ${site.residues.length} residues within 4 Å of the ligand.`;
    if (arrive < 1) return simple ? `${drugName} ${isProtein ? "moves in and lands on its target" : "slides into the pocket"}. (The route it takes here is our drawing; where it ends up is real.)` : `${isProtein ? "Interface residues" : "Ligand"} moving to the deposited position. The path is illustrative; only the final pose is experimental.`;
    if (shown && progress < 0.88) {
      const [li, ri, , kind, d] = site.contacts[shown - 1], r = site.residues[ri];
      const from = isProtein ? site.ligand.labels[site.ligand.owner[li]] : `ligand ${site.ligand.atoms[li][0]}`;
      return simple ? `${shown} of ${n}: near ${r.label}, ${KIND[kind].simple}.` : `${shown} of ${n}: ${KIND[kind].word}, ${from} to ${r.label}, ${d.toFixed(2)} Å.`;
    }
    if (site.covalent) return simple ? `${drugName} is chemically joined to ${site.covalent.protein_residue}, so it stays put. ${n - 1} more close contacts are shown.`
      : `Covalent bond to ${site.covalent.protein_residue} (${site.covalent.protein_atom}${site.covalent.distance ? `, ${site.covalent.distance.toFixed(2)} Å` : ""}) plus ${info.polar} polar, ${info.nonpolar} non-polar and ${info.metal} metal contacts (distance criteria, not energies).`;
    return simple ? `${n} close contacts keep ${drugName} in the pocket.` : `${info.polar} polar, ${info.nonpolar} non-polar and ${info.metal} metal contacts shown (distance criteria, not energies).`;
  }

  function loop(now) {
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (playing && !drag) {
      progress += dt / LOOP_SECONDS; yaw += dt * 0.18;
      if (progress >= 1.12) { if (recording) recording.stop(); progress = 0; }
    }
    draw(); frame = requestAnimationFrame(loop);
  }
  const sync = () => container.querySelector('[data-act="play"]').setAttribute("aria-pressed", String(playing));
  container.querySelector(".mol3d-bar").addEventListener("click", (e) => {
    const act = e.target.dataset.act;
    if (act === "play") playing = !playing;
    if (act === "restart") { progress = 0; playing = true; }
    if (act === "end") { progress = 1; playing = false; }
    if (act === "save") saveVideo(e.target);
    sync();
  });
  canvas.addEventListener("pointerdown", (e) => { drag = [e.clientX, e.clientY]; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointermove", (e) => { if (!drag) return; yaw += (e.clientX - drag[0]) * 0.012; pitch += (e.clientY - drag[1]) * 0.012; drag = [e.clientX, e.clientY]; });
  canvas.addEventListener("pointerup", () => { drag = null; });
  canvas.addEventListener("keydown", (e) => { const step = { ArrowLeft: [-0.15, 0], ArrowRight: [0.15, 0], ArrowUp: [0, -0.15], ArrowDown: [0, 0.15] }[e.key];
    if (step) { e.preventDefault(); yaw += step[0]; pitch += step[1]; } });
  // Save one loop as a video file, made in the browser (nothing is uploaded). Offered only where the browser can record a canvas.
  const mime = window.MediaRecorder && canvas.captureStream && ["video/webm;codecs=vp9", "video/webm", "video/mp4"].find((m) => MediaRecorder.isTypeSupported(m));
  const saveButton = container.querySelector('[data-act="save"]');
  if (mime) saveButton.hidden = false;
  function saveVideo(button) {
    if (recording) return;
    const chunks = [];
    recording = new MediaRecorder(canvas.captureStream(30), { mimeType: mime });
    recording.ondataavailable = (ev) => { if (ev.data.size) chunks.push(ev.data); };
    recording.onstop = () => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob(chunks, { type: mime }));
      a.download = `${drugName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-binding.${mime.includes("mp4") ? "mp4" : "webm"}`;
      a.click(); URL.revokeObjectURL(a.href);
      recording = null; button.textContent = "Save as video"; container.dataset.saved = String(chunks.length);
    };
    button.textContent = "Recording one loop…";
    progress = 0; playing = true; sync(); recording.start();
  }
  sync(); frame = requestAnimationFrame(loop);
  return () => { cancelAnimationFrame(frame); if (recording) recording.stop(); };
}

// ---------------------------------------------------------------------------------------------------- schematic animations
const FAMILIES = {
  block: { actions: ["INHIBITOR", "ANTAGONIST", "BLOCKER", "NEGATIVE ALLOSTERIC MODULATOR", "INVERSE AGONIST", "ALLOSTERIC ANTAGONIST", "NEGATIVE MODULATOR"],
    result: "signal off", line: "The medicine sits on its target, so the target's usual partner cannot get in and the signal stops." },
  activate: { actions: ["AGONIST", "PARTIAL AGONIST", "ACTIVATOR", "OPENER", "POSITIVE ALLOSTERIC MODULATOR", "POSITIVE MODULATOR"],
    result: "signal on", line: "The medicine sits on its target and switches it on, as the body's own messenger would." },
  bind: { actions: ["BINDING AGENT", "SEQUESTERING AGENT", "CHELATING AGENT", "CROSS-LINKING AGENT", "DISRUPTING AGENT", "DEGRADER"],
    result: "caught", line: "The medicine grabs its target and holds on, so the target can no longer do its job." },
  silence: { actions: ["ANTISENSE INHIBITOR", "RNAI INHIBITOR"], result: "message silenced", line: "The medicine pairs with a genetic message, and the message is not turned into protein." },
  cut: { actions: ["HYDROLYTIC ENZYME", "PROTEOLYTIC ENZYME", "OXIDATIVE ENZYME"], result: "broken down", line: "The medicine is an enzyme: it breaks its target apart." },
  replace: { actions: ["EXOGENOUS PROTEIN", "EXOGENOUS GENE"], result: "job restored", line: "The medicine supplies something the body is missing." },
  generic: { actions: [], result: "acts here", line: "The medicine acts on its target." },
};
export const familyOf = (action) => Object.keys(FAMILIES).find((f) => FAMILIES[f].actions.includes(action)) || "generic";
const clip = (s, n) => (s && s.length > n ? s.slice(0, n - 1) + "…" : s || "");

/** Symbolic picture of a mechanism. Shapes are symbols, never the real molecules; the animation is CSS (see base.css, .sch-*). */
export function schematic(m, drugName) {
  const fam = familyOf(m.action), F = FAMILIES[fam], target = clip(m.target_name || m.text, 44), drug = clip(drugName, 18);
  const targetShape = fam === "silence" || fam === "cut"
    ? `<g class="t-strand"><path class="strand left" d="M150 120 q20 -22 40 0 t40 0 t40 0"/><path class="strand right" d="M270 120 q20 -22 40 0 t40 0 t40 0"/></g>`
    : fam === "bind" ? `<circle class="t-free" cx="300" cy="118" r="26"/>`
    : fam === "replace" ? `<rect class="t-missing" x="225" y="88" width="120" height="60" rx="18"/>`
    : `<path class="t-body" d="M180 100 h70 v34 h60 v-34 h70 a14 14 0 0 1 14 14 v60 a14 14 0 0 1 -14 14 h-200 a14 14 0 0 1 -14 -14 v-60 a14 14 0 0 1 14 -14z"/>`;
  const drugShape = fam === "silence" ? `<path class="d-strand" d="M230 104 q20 -22 40 0 t40 0"/>`
    : fam === "replace" ? `<rect class="d-pill" x="225" y="88" width="120" height="60" rx="18"/>` : `<rect class="d-pill" x="252" y="98" width="56" height="34" rx="12"/>`;
  const extras = fam === "block" ? `<circle class="partner" cx="280" cy="50" r="14"/><g class="signal off"><path d="M250 200 v22 M280 200 v22 M310 200 v22"/></g>`
    : fam === "activate" ? `<g class="signal on"><path d="M250 200 v22 M280 200 v22 M310 200 v22"/></g>` : "";
  return html`<figure class="sch-fig"><svg class="sch sch-${fam}" viewBox="0 0 560 250" role="img" aria-label="Schematic: ${F.line}">
      ${raw(targetShape)}${raw(extras)}<g class="drug">${raw(drugShape)}</g>
      <text class="lbl d" x="280" y="26">${drug}</text><text class="lbl t" x="280" y="244">${target}</text><text class="lbl r" x="470" y="124">${F.result}</text></svg>
    <figcaption><b>Schematic.</b> ${F.line} Shapes are symbols, not the real molecules.</figcaption></figure>`;
}
